import React, { useEffect, useMemo, useState } from 'react';

// v0.8.5 Trophy Room Event Name Fix

const STORAGE_KEY = 'simple-dart-league-v0-1';
const PLAYER_ID = 'player';

const LEAGUES = [
  { name: 'Pub League', shortName: 'Pub', minOffset: -5, maxOffset: 2, levelText: 'Local pub standard', prizes: [100, 70, 50, 30, 10, 10, 10, 10, 10, 10] },
  { name: 'Town League', shortName: 'Town', minOffset: 1, maxOffset: 7, levelText: 'Town-level regulars', prizes: [250, 175, 125, 75, 25, 25, 25, 25, 25, 25] },
  { name: 'County League', shortName: 'County', minOffset: 6, maxOffset: 12, levelText: 'County contenders', prizes: [500, 350, 250, 150, 50, 50, 50, 50, 50, 50] },
  { name: 'National League', shortName: 'National', minOffset: 11, maxOffset: 18, levelText: 'National circuit', prizes: [1000, 700, 500, 300, 100, 100, 100, 100, 100, 100] },
  { name: 'Elite League', shortName: 'Elite', minOffset: 17, maxOffset: 26, levelText: 'Elite stage', prizes: [2500, 1750, 1250, 750, 250, 250, 250, 250, 250, 250] },
];

const QUICK_SCORE_VALUES = [26, 41, 45, 60, 81, 85, 100, 121, 140, 180];

const QUICK_BOT_LEVELS: QuickBotLevel[] = ['Beginner', 'Easy', 'Normal', 'Challenging', 'Hard', 'Pro'];


const BOT_FIRST_NAMES = [
  'Mick', 'Alan', 'Steve', 'Tom', 'Danny', 'Pete', 'Rob', 'Gary', 'Chris', 'Lee',
  'Shaun', 'Terry', 'Glen', 'Mark', 'Ryan', 'Neil', 'Barry', 'Andy', 'Dean', 'Paul',
  'Luke', 'Darren', 'Wayne', 'Colin', 'Jamie', 'Simon', 'Keith', 'Kev', 'Martin', 'Scott',
  'Nico', 'Jon', 'Alex', 'Harry', 'Ben', 'Nathan', 'Karl', 'Dylan', 'Owen', 'Josh',
  'Vincent', 'Ray', 'Lewis', 'Connor', 'Brad', 'Jack', 'Mike', 'Ronnie', 'Kirk', 'Tony',
];

const BOT_LAST_NAMES = [
  'Porter', 'Briggs', 'Mason', 'Holt', 'Walker', 'Turner', 'Mills', 'Nolan', 'Reed', 'Fletcher',
  'Barker', 'Stone', 'Cooper', 'Dawson', 'Hughes', 'Webb', 'Marsh', 'Ellis', 'Frost', 'Clarke',
  'Walsh', 'Bennett', 'Hunter', 'Carter', 'Cross', 'Wells', 'Sharp', 'Parker', 'Knight', 'Ford',
  'Wright', 'Barlow', 'Green', 'Hardy', 'Brooks', 'West', 'Payne', 'Cole', 'Howe', 'Grant',
  'King', 'Price', 'Smith', 'Taylor', 'Lewis', 'Adams', 'Wood', 'Harris', 'Hill', 'Moore',
];

const LEAGUE_BOT_NAMES = [
  [
    'Mick Porter', 'Alan Briggs', 'Steve Mason', 'Tom Holt', 'Danny Walker',
    'Pete Turner', 'Rob Mills', 'Gary Nolan', 'Chris Reed', 'Lee Fletcher',
  ],
  [
    'Shaun Barker', 'Terry Stone', 'Glen Cooper', 'Mark Dawson', 'Ryan Hughes',
    'Neil Webb', 'Barry Marsh', 'Andy Ellis', 'Dean Frost', 'Paul Clarke',
  ],
  [
    'Luke Walsh', 'Darren Bennett', 'Wayne Hunter', 'Colin Carter', 'Jamie Cross',
    'Simon Wells', 'Keith Sharp', 'Kev Parker', 'Martin Knight', 'Scott Ford',
  ],
  [
    'Nico Wright', 'Jon Barlow', 'Alex Green', 'Harry Hardy', 'Ben Brooks',
    'Nathan West', 'Karl Payne', 'Dylan Cole', 'Owen Howe', 'Josh Grant',
  ],
  [
    'Vincent King', 'Ray Price', 'Lewis Smith', 'Connor Taylor', 'Brad Lewis',
    'Jack Adams', 'Mike Wood', 'Ronnie Harris', 'Kirk Hill', 'Tony Moore',
  ],
];

type Screen =
  | 'main'
  | 'league'
  | 'leagueTable'
  | 'leagueEvents'
  | 'eventDetail'
  | 'eventRecap'
  | 'match'
  | 'postMatch'
  | 'seasonSummary'
  | 'quickSetup'
  | 'stats'
  | 'matchHistory'
  | 'trophyRoom';

type MatchContext = 'league' | 'quick' | 'event';
type QuickBotLevel = 'Beginner' | 'Easy' | 'Normal' | 'Challenging' | 'Hard' | 'Pro';
type EventDifficulty = 'Easy' | 'Balanced' | 'Hard';
type EventRound = 'round32' | 'round16' | 'quarter' | 'semi' | 'final';
type EventFieldSize = 4 | 8 | 16 | 32;
type EventStatus = 'available' | 'completed';
type EventPlacement = 'Winner' | 'Runner-up' | 'Semi-final' | 'Quarter-final' | 'Round of 16' | 'Round of 32';


type Profile = {
  name: string;
  startingAverage: number;
  targetAverage: number;
};

type Bot = {
  id: string;
  name: string;
  average: number;
  leagueIndex: number;
};

type TableRow = {
  id: string;
  name: string;
  isPlayer: boolean;
  average: number;
  played: number;
  wins: number;
  losses: number;
  legsFor: number;
  legsAgainst: number;
  points: number;
};

type FixtureResult = {
  winnerId: string;
  loserId: string;
  winnerLegs: number;
  loserLegs: number;
};

type Fixture = {
  id: string;
  round: number;
  homeId: string;
  awayId: string;
  played: boolean;
  result?: FixtureResult;
};

type EventOpponent = {
  round: EventRound;
  name: string;
  average: number;
};

type EventParticipant = {
  id: string;
  name: string;
  average: number;
  seed: number;
  isPlayer?: boolean;
};

type SeasonEvent = {
  id: string;
  seasonNumber: number;
  leagueIndex: number;
  name: string;
  difficulty: EventDifficulty;
  fieldSize: EventFieldSize;
  startingScore: number;
  legsToWin: number;
  winnerPrize: number;
  runnerUpPrize: number;
  venue?: string;
  venueTier?: string;
  theme?: string;
  participants?: EventParticipant[];
  status: EventStatus;
  currentRound: EventRound;
  currentRoundIndex: number;
  opponents: EventOpponent[];
  semiOpponentName?: string;
  semiOpponentAverage?: number;
  finalOpponentName?: string;
  finalOpponentAverage?: number;
  placement?: EventPlacement;
  prizeWon?: number;
};

type EventHistoryItem = {
  id: string;
  seasonNumber: number;
  leagueName: string;
  eventName: string;
  difficulty: EventDifficulty;
  fieldSize?: EventFieldSize;
  legsToWin?: number;
  placement: EventPlacement;
  prizeWon: number;
};

type EventRecap = {
  eventId: string;
  eventName: string;
  leagueName: string;
  venue: string;
  venueTier: string;
  theme: string;
  difficulty: EventDifficulty;
  fieldSize: EventFieldSize;
  legsToWin: number;
  placement: EventPlacement;
  prizeWon: number;
  playerWon: boolean;
  round: EventRound;
  opponentName: string;
  playerAverage: number;
  opponentAverage: number;
  playerLegs: number;
  opponentLegs: number;
};

type StatsBundle = {
  matches: number;
  wins: number;
  losses: number;
  legsWon: number;
  legsLost: number;
  dartsThrown: number;
  scoredTotal: number;
  bestMatchAverage: number;
  highestScore: number;
  highestCheckout: number;
  checkoutAttempts: number;
  checkoutHits: number;
  total180s: number;
  prizeMoney: number;
};

type LeagueStats = StatsBundle & {
  seasonsCompleted: number;
  promotions: number;
  relegations: number;
  leagueTitles: number;
  bestPosition: number | null;
  highestLeagueIndex: number;
};

type SeasonHistoryItem = {
  seasonNumber: number;
  leagueName: string;
  position: number;
  wins: number;
  losses: number;
  points: number;
  legDifference: number;
  prizeMoney: number;
  movement: 'Promoted' | 'Relegated' | 'Stayed';
};

type GameState = {
  profile: Profile | null;
  currentLeagueIndex: number;
  seasonNumber: number;
  botPools: Bot[][];
  table: TableRow[];
  fixtures: Fixture[];
  overallStats: StatsBundle;
  leagueStats: LeagueStats;
  seasonHistory: SeasonHistoryItem[];
  seasonEvents: SeasonEvent[];
  eventHistory: EventHistoryItem[];
  matchHistory: MatchHistoryItem[];
};

type ActiveMatch = {
  context: MatchContext;
  opponentId?: string;
  opponentName: string;
  opponentAverage: number;
  startingScore: number;
  legsToWin: number;
  fixtureId?: string;
  round?: number;
  eventId?: string;
  eventRound?: EventRound;
};

type MatchStats = {
  dartsThrown: number;
  scoredTotal: number;
  highestScore: number;
  highestCheckout: number;
  checkoutAttempts: number;
  checkoutHits: number;
  total180s: number;
};

type BotMatchStats = {
  dartsThrown: number;
  scoredTotal: number;
};

type MatchSnapshot = {
  playerScore: number;
  botScore: number;
  playerLegs: number;
  botLegs: number;
  stats: MatchStats;
  botStats: BotMatchStats;
  lastMessage: string;
};

type MatchPlayState = MatchSnapshot & {
  history: MatchSnapshot[];
};

type CompletedMatch = {
  context: MatchContext;
  fixtureId?: string;
  round?: number;
  eventId?: string;
  eventRound?: EventRound;
  opponentId?: string;
  opponentName: string;
  playerName: string;
  playerWon: boolean;
  playerLegs: number;
  opponentLegs: number;
  playerAverage: number;
  opponentAverage: number;
  startingScore: number;
  legsToWin: number;
  highestScore: number;
  highestCheckout: number;
  checkoutAttempts: number;
  checkoutHits: number;
  total180s: number;
  dartsThrown: number;
  scoredTotal: number;
  createdAt: string;
};

type MatchHistoryItem = {
  id: string;
  context: MatchContext;
  createdAt: string;
  seasonNumber: number;
  leagueName?: string;
  eventName?: string;
  roundLabel?: string;
  opponentName: string;
  playerWon: boolean;
  playerLegs: number;
  opponentLegs: number;
  playerAverage: number;
  opponentAverage: number;
  startingScore: number;
  legsToWin: number;
  highestScore: number;
  highestCheckout: number;
  checkoutAttempts: number;
  checkoutHits: number;
  total180s: number;
  prizeMoney: number;
};

const emptyStats = (): StatsBundle => ({
  matches: 0,
  wins: 0,
  losses: 0,
  legsWon: 0,
  legsLost: 0,
  dartsThrown: 0,
  scoredTotal: 0,
  bestMatchAverage: 0,
  highestScore: 0,
  highestCheckout: 0,
  checkoutAttempts: 0,
  checkoutHits: 0,
  total180s: 0,
  prizeMoney: 0,
});

const emptyLeagueStats = (): LeagueStats => ({
  ...emptyStats(),
  seasonsCompleted: 0,
  promotions: 0,
  relegations: 0,
  leagueTitles: 0,
  bestPosition: null,
  highestLeagueIndex: 0,
});

const createEmptyGameState = (): GameState => ({
  profile: null,
  currentLeagueIndex: 0,
  seasonNumber: 1,
  botPools: [],
  table: [],
  fixtures: [],
  overallStats: emptyStats(),
  leagueStats: emptyLeagueStats(),
  seasonHistory: [],
  seasonEvents: [],
  eventHistory: [],
  matchHistory: [],
});

function clamp(value: number, min: number, max: number) {
  return Math.max(min, Math.min(max, value));
}

function round1(value: number) {
  return Math.round(value * 10) / 10;
}

function normalizeGameState(value: Partial<GameState> | null | undefined): GameState {
  const empty = createEmptyGameState();
  if (!value || typeof value !== 'object') return empty;

  const currentLeagueIndex = typeof value.currentLeagueIndex === 'number'
    ? clamp(value.currentLeagueIndex, 0, LEAGUES.length - 1)
    : empty.currentLeagueIndex;
  const seasonNumber = typeof value.seasonNumber === 'number' && value.seasonNumber > 0
    ? Math.floor(value.seasonNumber)
    : empty.seasonNumber;
  const baseLeagueStats = {
    ...emptyLeagueStats(),
    ...(value.leagueStats || {}),
  };

  return {
    ...empty,
    profile: value.profile || null,
    currentLeagueIndex,
    seasonNumber,
    botPools: Array.isArray(value.botPools) ? value.botPools as Bot[][] : empty.botPools,
    table: Array.isArray(value.table) ? value.table as TableRow[] : empty.table,
    fixtures: Array.isArray(value.fixtures) ? value.fixtures as Fixture[] : empty.fixtures,
    overallStats: {
      ...emptyStats(),
      ...(value.overallStats || {}),
    },
    leagueStats: {
      ...baseLeagueStats,
      highestLeagueIndex: clamp(baseLeagueStats.highestLeagueIndex ?? currentLeagueIndex, 0, LEAGUES.length - 1),
    },
    seasonHistory: Array.isArray(value.seasonHistory) ? value.seasonHistory as SeasonHistoryItem[] : empty.seasonHistory,
    seasonEvents: Array.isArray(value.seasonEvents) ? (value.seasonEvents as SeasonEvent[]).map((event, index) => applyNamingPolishToEvent(event, index)) : empty.seasonEvents,
    eventHistory: Array.isArray(value.eventHistory) ? (value.eventHistory as EventHistoryItem[]).map((item) => ({ ...item, eventName: getPolishedEventNameFromId(item.id, item.leagueName, item.eventName) || item.eventName })) : empty.eventHistory,
    matchHistory: Array.isArray(value.matchHistory) ? value.matchHistory as MatchHistoryItem[] : empty.matchHistory,
  };
}

function randomBetween(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function shuffle<T>(items: T[]) {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function createBotPools(startingAverage: number): Bot[][] {
  let nameIndex = 0;
  return LEAGUES.map((league, leagueIndex) => {
    const rangeMin = startingAverage + league.minOffset;
    const rangeMax = startingAverage + league.maxOffset;
    const range = Math.max(1, rangeMax - rangeMin);
    return Array.from({ length: 10 }).map((_, botIndex) => {
      const themedName = LEAGUE_BOT_NAMES[leagueIndex]?.[botIndex];
      const first = BOT_FIRST_NAMES[(nameIndex + botIndex) % BOT_FIRST_NAMES.length];
      const last = BOT_LAST_NAMES[(nameIndex * 3 + botIndex) % BOT_LAST_NAMES.length];
      const progression = botIndex / 9;
      const noise = randomBetween(-0.8, 0.8);
      const average = round1(clamp(rangeMin + range * progression + noise, 18, 95));
      return {
        id: `L${leagueIndex}-B${botIndex}`,
        name: themedName || `${first} ${last}`,
        average,
        leagueIndex,
      };
    });
  }).map((pool) => {
    nameIndex += 7;
    return shuffle(pool);
  });
}

function createInitialTable(profile: Profile, leagueIndex: number, botPools: Bot[][]): TableRow[] {
  const leagueBots = botPools[leagueIndex] || [];
  const activeBots = leagueBots.slice(0, 9);
  const playerRow: TableRow = {
    id: PLAYER_ID,
    name: profile.name,
    isPlayer: true,
    average: profile.startingAverage,
    played: 0,
    wins: 0,
    losses: 0,
    legsFor: 0,
    legsAgainst: 0,
    points: 0,
  };

  const botRows: TableRow[] = activeBots.map((bot) => ({
    id: bot.id,
    name: bot.name,
    isPlayer: false,
    average: bot.average,
    played: 0,
    wins: 0,
    losses: 0,
    legsFor: 0,
    legsAgainst: 0,
    points: 0,
  }));

  return [playerRow, ...botRows];
}

function generateFixtures(playerIds: string[], seasonNumber: number): Fixture[] {
  const teams = [...playerIds];
  const fixtures: Fixture[] = [];
  const rounds = teams.length - 1;
  const half = teams.length / 2;
  let rotation = [...teams];

  for (let round = 1; round <= rounds; round += 1) {
    for (let i = 0; i < half; i += 1) {
      const a = rotation[i];
      const b = rotation[rotation.length - 1 - i];
      const swap = round % 2 === 0;
      fixtures.push({
        id: `S${seasonNumber}-R${round}-M${i + 1}`,
        round,
        homeId: swap ? b : a,
        awayId: swap ? a : b,
        played: false,
      });
    }
    rotation = [rotation[0], rotation[rotation.length - 1], ...rotation.slice(1, rotation.length - 1)];
  }

  return fixtures;
}

function createSeason(profile: Profile, leagueIndex: number, seasonNumber: number, botPools: Bot[][]) {
  const table = createInitialTable(profile, leagueIndex, botPools);
  const fixtures = generateFixtures(table.map((row) => row.id), seasonNumber);
  return { table, fixtures };
}

function makeEventOpponentName(seed: number, difficulty: EventDifficulty) {
  const first = BOT_FIRST_NAMES[(seed * 5 + difficulty.length) % BOT_FIRST_NAMES.length];
  const last = BOT_LAST_NAMES[(seed * 7 + difficulty.length * 3) % BOT_LAST_NAMES.length];
  return `${first} ${last}`;
}

const EVENT_THEME_CLASSES = ['red', 'gold', 'green', 'blue', 'purple', 'orange'];

const EVENT_VENUES = [
  [
    'The Red Lion, Stoke',
    'The Oche Tap, Blackpool',
    'The White Hart, Wigan',
    'The Railway Arms, Leeds',
    'The Crown & Anchor, Sheffield',
    'The Dog & Duck, Wolverhampton',
    'The Fox & Hounds, Bolton',
    'The King’s Arms, Barnsley',
    'The Anchor Bar, Plymouth',
    'The Swan Inn, Norwich',
  ],
  [
    'Blackpool Social Club',
    'Leeds Working Men’s Club',
    'Sheffield Darts Hall',
    'Stoke Victoria Club',
    'Wolverhampton Civic Rooms',
    'Manchester Sports Bar',
    'Bristol Oche Club',
    'Nottingham Market Hall',
    'Coventry Community Club',
    'Preston Players Lounge',
  ],
  [
    'Yorkshire Sports Pavilion',
    'Lancashire Darts Hall',
    'Essex Arena Lounge',
    'Kent Civic Hall',
    'Surrey Sports Centre',
    'Devon Players Hall',
    'Hampshire Darts Rooms',
    'Norfolk County Hall',
    'Merseyside Social Arena',
    'Staffordshire Oche Hall',
  ],
  [
    'Blackpool Winter Hall',
    'Wolverhampton Grand Hall',
    'Manchester Central Stage',
    'Leeds Premier Arena',
    'Sheffield City Arena',
    'Birmingham Arena Hall',
    'Liverpool Exhibition Hall',
    'Newcastle Northern Arena',
    'London Docklands Stage',
    'Nottingham National Hall',
  ],
  [
    'Blackpool Winter Arena',
    'London World Stage',
    'Manchester Grand Arena',
    'Sheffield Premier Hall',
    'Wolverhampton Elite Stage',
    'Birmingham International Arena',
    'Liverpool Grand Prix Hall',
    'Newcastle Arena Stage',
    'Nottingham Finals Hall',
    'Leeds Championship Stage',
  ],
];

const EVENT_NAME_POOLS = [
  [
    'Stoke Oche Open',
    'Blackpool Social Club Trophy',
    'Leeds Friday Night Cup',
    'Sheffield Pub Players Championship',
    'Wolverhampton Darts Classic',
    'Bolton Challenge Cup',
    'Rotherham Oche Cup',
    'Barnsley Players Trophy',
    'Leicester Lane Open',
    'Wigan Winter Championship',
  ],
  [
    'Manchester Masters',
    'Bristol Players Championship',
    'Nottingham Grand Prix',
    'Coventry Matchplay',
    'Norwich Open',
    'Plymouth Challenge Trophy',
    'Southampton Classic',
    'Derby Players Cup',
    'Preston Masters',
    'Hull Championship',
  ],
  [
    'Yorkshire Open',
    'Lancashire Trophy',
    'Essex Matchplay',
    'Kent Grand Prix',
    'Surrey Darts Classic',
    'Devon Open',
    'Hampshire Players Championship',
    'Norfolk Masters',
    'Staffordshire Challenge Cup',
    'Merseyside Championship',
  ],
  [
    'Midlands Masters',
    'Northern Open',
    'Southern Classic',
    'Blackpool Matchplay',
    'Manchester Grand Prix',
    'Leeds Championship',
    'Sheffield Masters',
    'Wolverhampton Finals',
    'London Players Championship',
    'Birmingham Open',
  ],
  [
    'Blackpool Winter Championship',
    'Wolverhampton Grand Slam',
    'London World Stage Open',
    'Manchester Premier Masters',
    'Sheffield Elite Matchplay',
    'Leeds Arena Trophy',
    'Birmingham International Cup',
    'Liverpool Grand Prix',
    'Newcastle Masters',
    'Nottingham Finals',
  ],
];

function getEventName(leagueIndex: number, eventIndex: number) {
  const names = EVENT_NAME_POOLS[leagueIndex] || EVENT_NAME_POOLS[0];
  return names[eventIndex % names.length];
}

function getEventVenue(leagueIndex: number, eventIndex: number) {
  const venues = EVENT_VENUES[leagueIndex] || EVENT_VENUES[0];
  return venues[eventIndex % venues.length];
}

function getEventVenueTier(leagueIndex: number) {
  if (leagueIndex <= 0) return 'Pub / back-room venue';
  if (leagueIndex === 1) return 'Town club venue';
  if (leagueIndex === 2) return 'County darts venue';
  if (leagueIndex === 3) return 'National stage venue';
  return 'Major arena venue';
}

function getEventIndexFromId(id?: string) {
  // Supports both live event ids like EV-S1-L0-3 and history ids like EV-S1-L0-3-winner.
  const match = String(id || '').match(/-L\d+-(\d+)(?:-|$)/);
  return match ? Number(match[1]) : 0;
}

function applyNamingPolishToEvent(event: SeasonEvent, index?: number): SeasonEvent {
  const eventIndex = typeof index === 'number' ? index : getEventIndexFromId(event.id);
  return {
    ...event,
    name: getEventName(event.leagueIndex, eventIndex),
    venue: getEventVenue(event.leagueIndex, eventIndex),
    venueTier: getEventVenueTier(event.leagueIndex),
  };
}

function getPolishedEventNameFromId(eventId: string | undefined, leagueName: string | undefined, fallback: string | undefined) {
  const eventIndex = getEventIndexFromId(eventId);
  const leagueIndex = LEAGUES.findIndex((league) => league.name === leagueName);
  if (leagueIndex >= 0) return getEventName(leagueIndex, eventIndex);
  return fallback;
}

function getEventTheme(index: number, difficulty: EventDifficulty) {
  const baseIndex = difficulty === 'Easy' ? index : difficulty === 'Balanced' ? index + 1 : index + 2;
  return EVENT_THEME_CLASSES[baseIndex % EVENT_THEME_CLASSES.length];
}

function createEventParticipants(
  profile: Profile,
  eventName: string,
  fieldSize: EventFieldSize,
  difficulty: EventDifficulty,
  baseAverage: number,
  seed: number,
): EventParticipant[] {
  const difficultyOffset = difficulty === 'Easy' ? -2.5 : difficulty === 'Balanced' ? 0 : 3.5;
  const fieldOffset = fieldSize === 4 ? -1 : fieldSize === 8 ? 0 : fieldSize === 16 ? 1.2 : 2.2;
  const participants: EventParticipant[] = [{
    id: `${eventName.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-player`,
    name: profile.name,
    average: round1(baseAverage),
    seed: 1,
    isPlayer: true,
  }];

  for (let index = 1; index < fieldSize; index += 1) {
    const spread = randomBetween(-3.4, 3.4);
    const seedBoost = (index / fieldSize) * (difficulty === 'Hard' ? 3.2 : difficulty === 'Balanced' ? 2 : 1.2);
    participants.push({
      id: `${eventName.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-bot-${index}`,
      name: makeEventOpponentName(seed + index * 13, difficulty),
      average: round1(clamp(baseAverage + difficultyOffset + fieldOffset + seedBoost + spread, 18, 105)),
      seed: index + 1,
    });
  }

  return participants.sort((a, b) => a.seed - b.seed);
}

function getEventParticipants(event: SeasonEvent, profile: Profile | null, referenceAverage: number): EventParticipant[] {
  if (Array.isArray(event.participants) && event.participants.length >= event.fieldSize) {
    return event.participants;
  }

  const fieldSize = event.fieldSize || 4;
  const playerName = profile?.name || 'You';
  const participants: EventParticipant[] = [{
    id: `${event.id}-player`,
    name: playerName,
    average: round1(referenceAverage),
    seed: 1,
    isPlayer: true,
  }];

  const allOpponents = event.opponents?.length ? event.opponents : generateEventOpponents(fieldSize, event.difficulty, referenceAverage, event.seasonNumber * 101 + event.leagueIndex * 17);
  for (let index = 1; index < fieldSize; index += 1) {
    const stored = allOpponents[(index - 1) % allOpponents.length];
    participants.push({
      id: `${event.id}-participant-${index}`,
      name: stored?.name || makeEventOpponentName(index + event.seasonNumber, event.difficulty),
      average: round1(clamp((stored?.average || referenceAverage) + randomBetween(-2.2, 2.2), 18, 105)),
      seed: index + 1,
    });
  }

  return participants;
}

function getEventBracketRounds(event: SeasonEvent, participants: EventParticipant[]) {
  const rounds = getEventRounds(event.fieldSize || 4);
  return rounds.map((round, roundIndex) => {
    const matchesInRound = Math.max(1, (event.fieldSize || 4) / Math.pow(2, roundIndex + 1));
    return {
      round,
      label: getRoundLabel(round),
      matches: Array.from({ length: matchesInRound }, (_, matchIndex) => {
        if (roundIndex === 0) {
          const playerA = participants[matchIndex * 2];
          const playerB = participants[matchIndex * 2 + 1];
          return {
            id: `${round}-${matchIndex}`,
            playerA: playerA?.name || 'TBD',
            playerB: playerB?.name || 'TBD',
            isPlayerPath: Boolean(playerA?.isPlayer || playerB?.isPlayer),
          };
        }

        const currentIndex = getEventCurrentRoundIndex(event);
        const isPlayerPath = matchIndex === 0;
        const opponent = isPlayerPath && roundIndex >= currentIndex ? getEventOpponent({ ...event, currentRoundIndex: roundIndex }) : null;
        return {
          id: `${round}-${matchIndex}`,
          playerA: isPlayerPath ? (roundIndex < currentIndex ? 'You' : 'You') : `Winner M${matchIndex * 2 + 1}`,
          playerB: isPlayerPath ? (opponent?.name || `Winner M${matchIndex * 2 + 2}`) : `Winner M${matchIndex * 2 + 2}`,
          isPlayerPath,
        };
      }),
    };
  });
}

function getEventDetailMeta(event: SeasonEvent, index: number) {
  return {
    theme: event.theme || getEventTheme(index, event.difficulty),
    venue: event.venue || getEventVenue(event.leagueIndex, index),
    venueTier: event.venueTier || getEventVenueTier(event.leagueIndex),
  };
}

const EVENT_ROUNDS_BY_SIZE: Record<EventFieldSize, EventRound[]> = {
  4: ['semi', 'final'],
  8: ['quarter', 'semi', 'final'],
  16: ['round16', 'quarter', 'semi', 'final'],
  32: ['round32', 'round16', 'quarter', 'semi', 'final'],
};

function getEventRounds(fieldSize: EventFieldSize): EventRound[] {
  return EVENT_ROUNDS_BY_SIZE[fieldSize] || EVENT_ROUNDS_BY_SIZE[4];
}

function getRoundLabel(round: EventRound) {
  if (round === 'round32') return 'Round of 32';
  if (round === 'round16') return 'Round of 16';
  if (round === 'quarter') return 'Quarter-final';
  if (round === 'semi') return 'Semi-final';
  return 'Final';
}

function getPlacementForRoundLoss(round: EventRound): EventPlacement {
  if (round === 'round32') return 'Round of 32';
  if (round === 'round16') return 'Round of 16';
  if (round === 'quarter') return 'Quarter-final';
  if (round === 'semi') return 'Semi-final';
  return 'Runner-up';
}

function getEventCurrentRound(event: SeasonEvent): EventRound {
  const fieldSize = event.fieldSize || 4;
  const rounds = getEventRounds(fieldSize);
  if (Number.isInteger(event.currentRoundIndex) && event.currentRoundIndex >= 0 && event.currentRoundIndex < rounds.length) {
    return rounds[event.currentRoundIndex];
  }
  if (event.currentRound && rounds.includes(event.currentRound)) return event.currentRound;
  return rounds[0];
}

function getEventCurrentRoundIndex(event: SeasonEvent): number {
  const fieldSize = event.fieldSize || 4;
  const rounds = getEventRounds(fieldSize);
  if (Number.isInteger(event.currentRoundIndex) && event.currentRoundIndex >= 0 && event.currentRoundIndex < rounds.length) {
    return event.currentRoundIndex;
  }
  const index = rounds.indexOf(event.currentRound);
  return index >= 0 ? index : 0;
}

function getNextEventRound(event: SeasonEvent): EventRound | null {
  const fieldSize = event.fieldSize || 4;
  const rounds = getEventRounds(fieldSize);
  const nextIndex = getEventCurrentRoundIndex(event) + 1;
  return rounds[nextIndex] || null;
}

function getEventOpponent(event: SeasonEvent): EventOpponent {
  const round = getEventCurrentRound(event);
  const storedOpponent = event.opponents?.find((opponent) => opponent.round === round);
  if (storedOpponent) return storedOpponent;

  if (round === 'final' && event.finalOpponentName && typeof event.finalOpponentAverage === 'number') {
    return { round, name: event.finalOpponentName, average: event.finalOpponentAverage };
  }
  if (event.semiOpponentName && typeof event.semiOpponentAverage === 'number') {
    return { round, name: event.semiOpponentName, average: event.semiOpponentAverage };
  }

  return {
    round,
    name: makeEventOpponentName(event.seasonNumber + event.leagueIndex + getEventCurrentRoundIndex(event) + 1, event.difficulty),
    average: round1(clamp(event.opponents?.[0]?.average || 40, 18, 100)),
  };
}

function getRecentMatchAverage(matchHistory: MatchHistoryItem[] = [], limit = 5) {
  const recent = matchHistory
    .filter((item) => typeof item.playerAverage === 'number' && item.playerAverage > 0)
    .slice(0, limit);
  if (recent.length === 0) return 0;
  return round1(recent.reduce((sum, item) => sum + item.playerAverage, 0) / recent.length);
}

function getAdaptiveCurrentLevel(
  profile: Profile,
  overallStats?: StatsBundle,
  leagueStats?: LeagueStats,
  matchHistory: MatchHistoryItem[] = [],
) {
  const startingAverage = profile.startingAverage;
  const targetAverage = profile.targetAverage;
  const recentAverage = getRecentMatchAverage(matchHistory, 5);
  const leagueAverage = leagueStats ? calculateAverage(leagueStats.scoredTotal, leagueStats.dartsThrown) : 0;
  const overallAverage = overallStats ? calculateAverage(overallStats.scoredTotal, overallStats.dartsThrown) : 0;
  const bestAverage = overallStats?.bestMatchAverage || leagueStats?.bestMatchAverage || 0;
  const anchorAverage = recentAverage || leagueAverage || overallAverage || startingAverage;
  const cappedBestAverage = bestAverage > 0 ? Math.min(bestAverage, anchorAverage + 8) : 0;

  const weightedValues = [
    { value: recentAverage, weight: 0.45 },
    { value: leagueAverage, weight: 0.25 },
    { value: overallAverage, weight: 0.20 },
    { value: cappedBestAverage, weight: 0.10 },
  ].filter((entry) => entry.value > 0);

  const rawLevel = weightedValues.length > 0
    ? weightedValues.reduce((sum, entry) => sum + entry.value * entry.weight, 0) / weightedValues.reduce((sum, entry) => sum + entry.weight, 0)
    : startingAverage;

  const currentLevel = round1(clamp(rawLevel, Math.max(18, startingAverage - 8), Math.min(105, targetAverage + 18)));
  const progress = targetAverage > startingAverage
    ? clamp(((currentLevel - startingAverage) / (targetAverage - startingAverage)) * 100, 0, 100)
    : 0;

  return {
    currentLevel,
    recentAverage,
    leagueAverage: round1(leagueAverage),
    overallAverage: round1(overallAverage),
    bestAverage: round1(bestAverage),
    progress: Math.round(progress),
  };
}

function getPlayerReferenceAverage(
  profile: Profile,
  stats?: StatsBundle,
  leagueStats?: LeagueStats,
  matchHistory: MatchHistoryItem[] = [],
) {
  return getAdaptiveCurrentLevel(profile, stats, leagueStats, matchHistory).currentLevel;
}

function generateEventOpponents(
  fieldSize: EventFieldSize,
  difficulty: EventDifficulty,
  baseAverage: number,
  seed: number,
): EventOpponent[] {
  const rounds = getEventRounds(fieldSize);
  const difficultyOffset = difficulty === 'Easy' ? -3 : difficulty === 'Balanced' ? 0 : 3;
  const fieldOffset = fieldSize === 4 ? -1 : fieldSize === 8 ? 0 : fieldSize === 16 ? 1 : 2;
  return rounds.map((round, index) => {
    const progressBoost = index * (difficulty === 'Hard' ? 1.1 : difficulty === 'Balanced' ? 0.8 : 0.55);
    const average = round1(clamp(baseAverage + difficultyOffset + fieldOffset + progressBoost + randomBetween(-1.4, 1.4), 18, 105));
    return {
      round,
      name: makeEventOpponentName(seed + index * 11, difficulty),
      average,
    };
  });
}

function createSeasonEvents(profile: Profile, leagueIndex: number, seasonNumber: number, referenceAverage?: number): SeasonEvent[] {
  const league = LEAGUES[leagueIndex] || LEAGUES[0];
  const baseAverage = round1(clamp(referenceAverage || profile.startingAverage, 18, 105));
  const prizeScale = Math.max(1, leagueIndex + 1);
  const templates: Array<{
    difficulty: EventDifficulty;
    fieldSize: EventFieldSize;
    legsToWin: number;
    winnerPrize: number;
    runnerUpPrize: number;
  }> = [
    { difficulty: 'Easy', fieldSize: 4, legsToWin: 2, winnerPrize: 30 * prizeScale, runnerUpPrize: 12 * prizeScale },
    { difficulty: 'Easy', fieldSize: 4, legsToWin: 2, winnerPrize: 40 * prizeScale, runnerUpPrize: 16 * prizeScale },
    { difficulty: 'Easy', fieldSize: 8, legsToWin: 2, winnerPrize: 55 * prizeScale, runnerUpPrize: 22 * prizeScale },
    { difficulty: 'Balanced', fieldSize: 8, legsToWin: 3, winnerPrize: 75 * prizeScale, runnerUpPrize: 30 * prizeScale },
    { difficulty: 'Balanced', fieldSize: 8, legsToWin: 3, winnerPrize: 90 * prizeScale, runnerUpPrize: 36 * prizeScale },
    { difficulty: 'Balanced', fieldSize: 16, legsToWin: 3, winnerPrize: 120 * prizeScale, runnerUpPrize: 48 * prizeScale },
    { difficulty: 'Hard', fieldSize: 16, legsToWin: 3, winnerPrize: 150 * prizeScale, runnerUpPrize: 60 * prizeScale },
    { difficulty: 'Hard', fieldSize: 16, legsToWin: 5, winnerPrize: 190 * prizeScale, runnerUpPrize: 76 * prizeScale },
    { difficulty: 'Hard', fieldSize: 32, legsToWin: 5, winnerPrize: 250 * prizeScale, runnerUpPrize: 100 * prizeScale },
    { difficulty: 'Hard', fieldSize: 32, legsToWin: 5, winnerPrize: 320 * prizeScale, runnerUpPrize: 128 * prizeScale },
  ];

  return templates.map((event, index) => {
    const opponents = generateEventOpponents(event.fieldSize, event.difficulty, baseAverage, seasonNumber * 101 + leagueIndex * 17 + index * 9);
    const rounds = getEventRounds(event.fieldSize);
    return {
      id: `EV-S${seasonNumber}-L${leagueIndex}-${index}`,
      seasonNumber,
      leagueIndex,
      name: getEventName(leagueIndex, index),
      difficulty: event.difficulty,
      fieldSize: event.fieldSize,
      startingScore: 501,
      legsToWin: event.legsToWin,
      winnerPrize: Math.round(event.winnerPrize),
      runnerUpPrize: Math.round(event.runnerUpPrize),
      venue: getEventVenue(leagueIndex, index),
      venueTier: getEventVenueTier(leagueIndex),
      theme: getEventTheme(index, event.difficulty),
      participants: createEventParticipants(profile, getEventName(leagueIndex, index), event.fieldSize, event.difficulty, baseAverage, seasonNumber * 203 + leagueIndex * 31 + index * 19),
      status: 'available',
      currentRound: rounds[0],
      currentRoundIndex: 0,
      opponents,
    };
  });
}

function getEventDifficultyDetail(event: SeasonEvent, referenceAverage: number) {
  const opponent = getEventOpponent(event);
  const insight = getOpponentInsight(opponent.average, referenceAverage);
  return { ...insight, opponentAverage: opponent.average };
}

function getRemainingEventRounds(event: SeasonEvent) {
  const rounds = getEventRounds(event.fieldSize || 4);
  const index = getEventCurrentRoundIndex(event);
  return Math.max(0, rounds.length - index);
}

function getCompletedLeagueRounds(fixtures: Fixture[]) {
  return fixtures.filter((fixture) => fixture.played && (fixture.homeId === PLAYER_ID || fixture.awayId === PLAYER_ID)).length;
}

function getUnlockedEventCount(fixtures: Fixture[], totalEvents: number) {
  if (totalEvents <= 0) return 0;
  return clamp(getCompletedLeagueRounds(fixtures) + 1, 1, totalEvents);
}

function isEventUnlocked(index: number, fixtures: Fixture[], totalEvents: number) {
  return index < getUnlockedEventCount(fixtures, totalEvents);
}

function getEventUnlockLabel(index: number) {
  if (index === 0) return 'Available from season start';
  return `Unlocks after league round ${index}`;
}

function sortTable(table: TableRow[]) {
  return [...table].sort((a, b) => {
    const pointDiff = b.points - a.points;
    if (pointDiff !== 0) return pointDiff;
    const legDiff = b.legsFor - b.legsAgainst - (a.legsFor - a.legsAgainst);
    if (legDiff !== 0) return legDiff;
    const winsDiff = b.wins - a.wins;
    if (winsDiff !== 0) return winsDiff;
    return a.name.localeCompare(b.name);
  });
}

function getPlayerPosition(table: TableRow[]) {
  const sorted = sortTable(table);
  return sorted.findIndex((row) => row.id === PLAYER_ID) + 1;
}

function getLeagueAverageRange(profile: Profile | null, leagueIndex: number) {
  const league = LEAGUES[leagueIndex] || LEAGUES[0];
  const base = profile?.startingAverage || 40;
  return {
    min: round1(clamp(base + league.minOffset, 18, 95)),
    max: round1(clamp(base + league.maxOffset, 18, 95)),
  };
}

function getLeagueAverageText(profile: Profile | null, leagueIndex: number) {
  const range = getLeagueAverageRange(profile, leagueIndex);
  return `${range.min}–${range.max} avg`;
}

function getOpponentInsight(opponentAverage: number, referenceAverage: number) {
  const diff = round1(opponentAverage - referenceAverage);
  if (diff <= -5) {
    return { label: 'Below your level', shortLabel: 'Favourable', className: 'easy', detail: `${Math.abs(diff)} avg below your start level` };
  }
  if (diff <= -1.5) {
    return { label: 'Slightly below you', shortLabel: 'Manageable', className: 'easy', detail: `${Math.abs(diff)} avg below your start level` };
  }
  if (diff < 2) {
    return { label: 'Around your level', shortLabel: 'Balanced', className: 'balanced', detail: `Within ${Math.abs(diff).toFixed(1)} avg of your start level` };
  }
  if (diff < 6) {
    return { label: 'Slightly stronger', shortLabel: 'Test', className: 'test', detail: `${diff} avg above your start level` };
  }
  if (diff < 11) {
    return { label: 'Danger match', shortLabel: 'Hard', className: 'hard', detail: `${diff} avg above your start level` };
  }
  return { label: 'Major step up', shortLabel: 'Very hard', className: 'elite', detail: `${diff} avg above your start level` };
}

function getBotLevelLabel(row: TableRow, referenceAverage: number) {
  if (row.isPlayer) return 'You';
  return getOpponentInsight(row.average, referenceAverage).shortLabel;
}

function updateTableWithResult(table: TableRow[], winnerId: string, loserId: string, winnerLegs: number, loserLegs: number) {
  return table.map((row) => {
    if (row.id === winnerId) {
      return {
        ...row,
        played: row.played + 1,
        wins: row.wins + 1,
        legsFor: row.legsFor + winnerLegs,
        legsAgainst: row.legsAgainst + loserLegs,
        points: row.points + 2,
      };
    }
    if (row.id === loserId) {
      return {
        ...row,
        played: row.played + 1,
        losses: row.losses + 1,
        legsFor: row.legsFor + loserLegs,
        legsAgainst: row.legsAgainst + winnerLegs,
      };
    }
    return row;
  });
}

function simulateBotLeagueMatch(home: TableRow, away: TableRow): FixtureResult {
  const avgDiff = home.average - away.average;
  const homeWinChance = clamp(0.5 + avgDiff * 0.025, 0.2, 0.8);
  const homeWins = Math.random() < homeWinChance;
  const winner = homeWins ? home : away;
  const loser = homeWins ? away : home;
  const strengthGap = Math.abs(home.average - away.average);
  let loserLegs = 1;
  const roll = Math.random();
  if (strengthGap > 8 && roll < 0.55) loserLegs = 0;
  else if (strengthGap > 4 && roll < 0.45) loserLegs = 0;
  else if (roll < 0.3) loserLegs = 0;

  return {
    winnerId: winner.id,
    loserId: loser.id,
    winnerLegs: 2,
    loserLegs,
  };
}

function getNextPlayerFixture(fixtures: Fixture[]) {
  return fixtures.find((fixture) => !fixture.played && (fixture.homeId === PLAYER_ID || fixture.awayId === PLAYER_ID));
}

function possibleCheckout(score: number) {
  if (score < 2 || score > 170) return false;
  return ![169, 168, 166, 165, 163, 162, 159].includes(score);
}

type DartOption = {
  label: string;
  value: number;
  isDouble?: boolean;
};

const doubleOptions: DartOption[] = [
  ...Array.from({ length: 20 }, (_, index) => {
    const number = index + 1;
    return { label: `D${number}`, value: number * 2, isDouble: true };
  }),
  { label: 'Bull', value: 50, isDouble: true },
];

const checkoutFirstDartOptions: DartOption[] = [
  ...[20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10].map((number) => ({ label: `T${number}`, value: number * 3 })),
  { label: '25', value: 25 },
  ...Array.from({ length: 20 }, (_, index) => 20 - index).map((number) => ({ label: `S${number}`, value: number })),
  ...[9, 8, 7, 6, 5, 4, 3, 2, 1].map((number) => ({ label: `T${number}`, value: number * 3 })),
];

function getDoubleLabel(value: number) {
  return doubleOptions.find((option) => option.value === value)?.label ?? null;
}

function getCheckoutRoute(score: number) {
  if (!possibleCheckout(score)) return null;

  const singleDartDouble = getDoubleLabel(score);
  if (singleDartDouble) return singleDartDouble;

  for (const first of checkoutFirstDartOptions) {
    const remaining = score - first.value;
    const doubleLabel = getDoubleLabel(remaining);
    if (doubleLabel) return `${first.label} → ${doubleLabel}`;
  }

  for (const first of checkoutFirstDartOptions) {
    for (const second of checkoutFirstDartOptions) {
      const remaining = score - first.value - second.value;
      const doubleLabel = getDoubleLabel(remaining);
      if (doubleLabel) return `${first.label} → ${second.label} → ${doubleLabel}`;
    }
  }

  return null;
}

function calculateAverage(scoredTotal: number, dartsThrown: number) {
  if (dartsThrown <= 0) return 0;
  return round1((scoredTotal / dartsThrown) * 3);
}

function formatPercent(part: number, total: number) {
  if (total <= 0) return '0%';
  return `${Math.round((part / total) * 100)}%`;
}

function updateStatsBundle(stats: StatsBundle, result: CompletedMatch, prizeMoney = 0): StatsBundle {
  return {
    ...stats,
    matches: stats.matches + 1,
    wins: stats.wins + (result.playerWon ? 1 : 0),
    losses: stats.losses + (result.playerWon ? 0 : 1),
    legsWon: stats.legsWon + result.playerLegs,
    legsLost: stats.legsLost + result.opponentLegs,
    dartsThrown: stats.dartsThrown + result.dartsThrown,
    scoredTotal: stats.scoredTotal + result.scoredTotal,
    bestMatchAverage: Math.max(stats.bestMatchAverage, result.playerAverage),
    highestScore: Math.max(stats.highestScore, result.highestScore),
    highestCheckout: Math.max(stats.highestCheckout, result.highestCheckout),
    checkoutAttempts: stats.checkoutAttempts + result.checkoutAttempts,
    checkoutHits: stats.checkoutHits + result.checkoutHits,
    total180s: stats.total180s + result.total180s,
    prizeMoney: stats.prizeMoney + prizeMoney,
  };
}


function createMatchHistoryItem(
  result: CompletedMatch,
  seasonNumber: number,
  options: {
    leagueName?: string;
    eventName?: string;
    roundLabel?: string;
    prizeMoney?: number;
  } = {}
): MatchHistoryItem {
  return {
    id: `${result.context}-${result.createdAt}-${result.opponentName}`,
    context: result.context,
    createdAt: result.createdAt,
    seasonNumber,
    leagueName: options.leagueName,
    eventName: options.eventName,
    roundLabel: options.roundLabel,
    opponentName: result.opponentName,
    playerWon: result.playerWon,
    playerLegs: result.playerLegs,
    opponentLegs: result.opponentLegs,
    playerAverage: result.playerAverage,
    opponentAverage: result.opponentAverage,
    startingScore: result.startingScore,
    legsToWin: result.legsToWin,
    highestScore: result.highestScore,
    highestCheckout: result.highestCheckout,
    checkoutAttempts: result.checkoutAttempts,
    checkoutHits: result.checkoutHits,
    total180s: result.total180s,
    prizeMoney: options.prizeMoney ?? 0,
  };
}

function appendMatchHistory(history: MatchHistoryItem[], item: MatchHistoryItem) {
  return [item, ...history].slice(0, 100);
}

function getMatchHistoryContextLabel(item: MatchHistoryItem) {
  if (item.context === 'league') return item.leagueName ? `League · ${item.leagueName}` : 'League Match';
  if (item.context === 'event') return item.eventName ? `Event · ${item.eventName}` : 'Event Match';
  return 'Quick Match';
}

function getLeaguePrize(leagueIndex: number, position: number) {
  const league = LEAGUES[leagueIndex];
  return league.prizes[position - 1] ?? 0;
}

function getQuickBotAverage(level: QuickBotLevel, baseAverage: number) {
  const modifiers: Record<QuickBotLevel, number> = {
    Beginner: -12,
    Easy: -7,
    Normal: 0,
    Challenging: 5,
    Hard: 10,
    Pro: 16,
  };

  return round1(clamp(baseAverage + modifiers[level], 20, 95));
}

function isPlayerMatchFixture(fixture: Fixture) {
  return fixture.homeId === PLAYER_ID || fixture.awayId === PLAYER_ID;
}

function getBotCheckoutChance(botAverage: number, remaining: number) {
  if (!possibleCheckout(remaining)) return 0;

  // The bot should still miss doubles, but it should not feel stuck on D1/D2 for many turns.
  // Lower finishes are therefore more decisive, while big checkouts remain difficult.
  if (remaining <= 10) return clamp(0.68 + (botAverage - 40) * 0.008, 0.52, 0.9);
  if (remaining <= 40) return clamp(0.52 + (botAverage - 40) * 0.007, 0.36, 0.82);
  if (remaining <= 80) return clamp(0.36 + (botAverage - 40) * 0.006, 0.22, 0.68);
  if (remaining <= 120) return clamp(0.24 + (botAverage - 40) * 0.005, 0.12, 0.52);
  return clamp(0.14 + (botAverage - 40) * 0.004, 0.06, 0.34);
}

function simulateBotVisit(botAverage: number, remaining: number) {
  const checkoutChance = getBotCheckoutChance(botAverage, remaining);
  if (checkoutChance > 0 && Math.random() < checkoutChance) {
    return { score: remaining, checkout: true };
  }

  const noise = randomBetween(-22, 22);
  let score = Math.round(clamp(botAverage + noise, 0, 180));

  if (score > remaining || remaining - score === 1) {
    const safeMax = Math.max(0, Math.min(remaining - 2, 120));
    score = Math.round(clamp(randomBetween(0, safeMax), 0, safeMax));
  }

  if (score === 179) score = 180;
  return { score, checkout: false };
}

function cloneSnapshot(state: MatchPlayState): MatchSnapshot {
  return {
    playerScore: state.playerScore,
    botScore: state.botScore,
    playerLegs: state.playerLegs,
    botLegs: state.botLegs,
    stats: { ...state.stats },
    botStats: { ...state.botStats },
    lastMessage: state.lastMessage,
  };
}

function App() {
  const [gameState, setGameState] = useState<GameState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return normalizeGameState(JSON.parse(saved) as Partial<GameState>);
    } catch {
      // Ignore broken local data and start fresh.
    }
    return createEmptyGameState();
  });

  const [screen, setScreen] = useState<Screen>('main');
  const [setupName, setSetupName] = useState('');
  const [setupAverage, setSetupAverage] = useState('40');
  const [setupTarget, setSetupTarget] = useState('50');
  const [activeMatch, setActiveMatch] = useState<ActiveMatch | null>(null);
  const [matchState, setMatchState] = useState<MatchPlayState | null>(null);
  const [scoreInput, setScoreInput] = useState('');
  const [pendingResult, setPendingResult] = useState<CompletedMatch | null>(null);
  const [statsTab, setStatsTab] = useState<'overall' | 'league'>('overall');
  const [quickStartingScore, setQuickStartingScore] = useState('501');
  const [quickLegsToWin, setQuickLegsToWin] = useState('3');
  const [quickBotLevel, setQuickBotLevel] = useState<QuickBotLevel>('Normal');
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [lastEventRecap, setLastEventRecap] = useState<EventRecap | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(gameState));
  }, [gameState]);

  useEffect(() => {
    setGameState((prev) => {
      if (!prev.profile || prev.seasonEvents.length >= 10) return prev;
      const referenceAverage = getPlayerReferenceAverage(prev.profile, prev.overallStats, prev.leagueStats, prev.matchHistory);
      return {
        ...prev,
        seasonEvents: createSeasonEvents(prev.profile, prev.currentLeagueIndex, prev.seasonNumber, referenceAverage),
      };
    });
  }, []);

  const sortedTable = useMemo(() => sortTable(gameState.table), [gameState.table]);
  const playerPosition = useMemo(() => getPlayerPosition(gameState.table), [gameState.table]);
  const nextFixture = useMemo(() => getNextPlayerFixture(gameState.fixtures), [gameState.fixtures]);
  const currentLeague = LEAGUES[gameState.currentLeagueIndex] || LEAGUES[0];

  function startLeagueProfile() {
    const startingAverage = Number(setupAverage);
    const targetAverage = Number(setupTarget);
    const name = setupName.trim() || 'Player';

    if (!Number.isFinite(startingAverage) || startingAverage < 15 || startingAverage > 100) {
      alert('Starting average must be between 15 and 100.');
      return;
    }
    if (!Number.isFinite(targetAverage) || targetAverage < 15 || targetAverage > 120) {
      alert('Target average must be between 15 and 120.');
      return;
    }
    if (targetAverage <= startingAverage) {
      alert('Target average must be higher than your starting average.');
      return;
    }

    const profile: Profile = {
      name,
      startingAverage: round1(startingAverage),
      targetAverage: round1(targetAverage),
    };
    const botPools = createBotPools(profile.startingAverage);
    const season = createSeason(profile, 0, 1, botPools);
    const seasonEvents = createSeasonEvents(profile, 0, 1, profile.startingAverage);
    setGameState({
      ...createEmptyGameState(),
      profile,
      currentLeagueIndex: 0,
      seasonNumber: 1,
      botPools,
      table: season.table,
      fixtures: season.fixtures,
      seasonEvents,
      leagueStats: {
        ...emptyLeagueStats(),
        highestLeagueIndex: 0,
      },
    });
    setScreen('league');
  }

  function startMatch(match: ActiveMatch) {
    setActiveMatch(match);
    const startingScore = match.startingScore || 501;
    const legsToWin = match.legsToWin || 3;
    setMatchState({
      playerScore: startingScore,
      botScore: startingScore,
      playerLegs: 0,
      botLegs: 0,
      stats: {
        dartsThrown: 0,
        scoredTotal: 0,
        highestScore: 0,
        highestCheckout: 0,
        checkoutAttempts: 0,
        checkoutHits: 0,
        total180s: 0,
      },
      botStats: {
        dartsThrown: 0,
        scoredTotal: 0,
      },
      lastMessage: `Start ${startingScore}. First to ${legsToWin} legs. Enter your visit score.`,
      history: [],
    });
    setScoreInput('');
    setScreen('match');
  }

  function startLeagueMatch() {
    if (!nextFixture || !gameState.profile) return;
    const opponentId = nextFixture.homeId === PLAYER_ID ? nextFixture.awayId : nextFixture.homeId;
    const opponent = gameState.table.find((row) => row.id === opponentId);
    if (!opponent) return;
    startMatch({
      context: 'league',
      opponentId,
      opponentName: opponent.name,
      opponentAverage: opponent.average,
      startingScore: 501,
      legsToWin: 2,
      fixtureId: nextFixture.id,
      round: nextFixture.round,
    });
  }

  function startQuickMatch() {
    const startingScore = Number(quickStartingScore);
    const legsToWin = Number(quickLegsToWin);

    if (!Number.isInteger(startingScore) || startingScore < 101 || startingScore > 1001) {
      alert('Start score must be a whole number between 101 and 1001.');
      return;
    }
    if (!Number.isInteger(legsToWin) || legsToWin < 1 || legsToWin > 15) {
      alert('Legs must be a whole number between 1 and 15.');
      return;
    }

    const currentLevelInfo = gameState.profile ? getAdaptiveCurrentLevel(gameState.profile, gameState.overallStats, gameState.leagueStats, gameState.matchHistory) : null;
    const base = currentLevelInfo?.currentLevel || gameState.profile?.startingAverage || 40;
    const opponentAverage = getQuickBotAverage(quickBotLevel, base);
    startMatch({
      context: 'quick',
      opponentName: `${quickBotLevel} Bot`,
      opponentAverage,
      startingScore: Math.round(startingScore),
      legsToWin,
    });
  }



  function startEventMatch(event: SeasonEvent) {
    if (!gameState.profile) return;
    const liveEvent = gameState.seasonEvents.find((item) => item.id === event.id);
    const liveEventIndex = gameState.seasonEvents.findIndex((item) => item.id === event.id);
    const unlocked = liveEventIndex >= 0 && isEventUnlocked(liveEventIndex, gameState.fixtures, gameState.seasonEvents.length);
    if (!liveEvent || liveEvent.status === 'completed' || !unlocked) return;
    const opponent = getEventOpponent(liveEvent);
    setSelectedEventId(liveEvent.id);
    startMatch({
      context: 'event',
      eventId: liveEvent.id,
      eventRound: getEventCurrentRound(liveEvent),
      opponentName: opponent.name,
      opponentAverage: opponent.average,
      startingScore: liveEvent.startingScore,
      legsToWin: liveEvent.legsToWin,
    });
  }

  function finishMatch(nextState: MatchPlayState, playerWon: boolean) {
    if (!activeMatch) return;
    const playerName = gameState.profile?.name || 'Player';
    const result: CompletedMatch = {
      context: activeMatch.context,
      fixtureId: activeMatch.fixtureId,
      round: activeMatch.round,
      eventId: activeMatch.eventId,
      eventRound: activeMatch.eventRound,
      opponentId: activeMatch.opponentId,
      opponentName: activeMatch.opponentName,
      playerName,
      playerWon,
      playerLegs: nextState.playerLegs,
      opponentLegs: nextState.botLegs,
      playerAverage: calculateAverage(nextState.stats.scoredTotal, nextState.stats.dartsThrown),
      opponentAverage: calculateAverage(nextState.botStats.scoredTotal, nextState.botStats.dartsThrown),
      startingScore: activeMatch.startingScore,
      legsToWin: activeMatch.legsToWin,
      highestScore: nextState.stats.highestScore,
      highestCheckout: nextState.stats.highestCheckout,
      checkoutAttempts: nextState.stats.checkoutAttempts,
      checkoutHits: nextState.stats.checkoutHits,
      total180s: nextState.stats.total180s,
      dartsThrown: nextState.stats.dartsThrown,
      scoredTotal: nextState.stats.scoredTotal,
      createdAt: new Date().toISOString(),
    };
    setPendingResult(result);
    setScreen('postMatch');
  }

  function awardLeg(state: MatchPlayState, winner: 'player' | 'bot'): MatchPlayState {
    const next: MatchPlayState = {
      ...state,
      playerLegs: state.playerLegs + (winner === 'player' ? 1 : 0),
      botLegs: state.botLegs + (winner === 'bot' ? 1 : 0),
      lastMessage: winner === 'player' ? 'You won the leg.' : `${activeMatch?.opponentName || 'Bot'} won the leg.`,
    };

    const legsToWin = activeMatch?.legsToWin || 3;
    if (next.playerLegs >= legsToWin || next.botLegs >= legsToWin) {
      finishMatch(next, next.playerLegs >= legsToWin);
      return next;
    }

    const startingScore = activeMatch?.startingScore || 501;
    return {
      ...next,
      playerScore: startingScore,
      botScore: startingScore,
      lastMessage: `${next.lastMessage} New leg starts.`,
    };
  }

  function runBotTurn(stateAfterPlayer: MatchPlayState): MatchPlayState {
    if (!activeMatch) return stateAfterPlayer;
    const visit = simulateBotVisit(activeMatch.opponentAverage, stateAfterPlayer.botScore);
    const botDarts = stateAfterPlayer.botStats.dartsThrown + 3;
    const botScored = stateAfterPlayer.botStats.scoredTotal + visit.score;

    if (visit.checkout && visit.score === stateAfterPlayer.botScore) {
      const checkedOutState: MatchPlayState = {
        ...stateAfterPlayer,
        botScore: 0,
        botStats: {
          dartsThrown: botDarts,
          scoredTotal: botScored,
        },
        lastMessage: `${activeMatch.opponentName} checked out ${visit.score}.`,
      };
      return awardLeg(checkedOutState, 'bot');
    }

    return {
      ...stateAfterPlayer,
      botScore: stateAfterPlayer.botScore - visit.score,
      botStats: {
        dartsThrown: botDarts,
        scoredTotal: botScored,
      },
      lastMessage: `${activeMatch.opponentName} scored ${visit.score}. Your turn.`,
    };
  }

  function submitScore(forceCheckout = false, directScore?: number) {
    if (!matchState) return;
    const score = directScore ?? Number(scoreInput);
    if (!Number.isFinite(score) || score < 0 || score > 180) {
      setMatchState({ ...matchState, lastMessage: 'Enter a valid score between 0 and 180.' });
      return;
    }

    if (forceCheckout && score !== matchState.playerScore) {
      setMatchState({ ...matchState, lastMessage: 'Checkout must equal your remaining score.' });
      return;
    }

    if (score === matchState.playerScore && !possibleCheckout(matchState.playerScore)) {
      setMatchState({ ...matchState, lastMessage: `${matchState.playerScore} is not a possible checkout.` });
      return;
    }

    const snapshot = cloneSnapshot(matchState);
    const isFinishingRange = possibleCheckout(matchState.playerScore);
    const bust = score > matchState.playerScore || matchState.playerScore - score === 1;
    const checkout = score === matchState.playerScore;

    const updatedStats: MatchStats = {
      ...matchState.stats,
      dartsThrown: matchState.stats.dartsThrown + 3,
      scoredTotal: matchState.stats.scoredTotal + (bust ? 0 : score),
      highestScore: Math.max(matchState.stats.highestScore, bust ? 0 : score),
      checkoutAttempts: matchState.stats.checkoutAttempts + (isFinishingRange ? 1 : 0),
      checkoutHits: matchState.stats.checkoutHits + (checkout ? 1 : 0),
      highestCheckout: checkout ? Math.max(matchState.stats.highestCheckout, matchState.playerScore) : matchState.stats.highestCheckout,
      total180s: matchState.stats.total180s + (score === 180 ? 1 : 0),
    };

    let nextState: MatchPlayState = {
      ...matchState,
      stats: updatedStats,
      history: [...matchState.history, snapshot],
    };

    if (bust) {
      nextState = {
        ...nextState,
        lastMessage: `Bust. ${activeMatch?.opponentName || 'Bot'} throws next.`,
      };
      nextState = runBotTurn(nextState);
      setMatchState(nextState);
      setScoreInput('');
      return;
    }

    if (checkout) {
      nextState = {
        ...nextState,
        playerScore: 0,
        lastMessage: `Checkout ${matchState.playerScore}.`,
      };
      nextState = awardLeg(nextState, 'player');
      setMatchState(nextState);
      setScoreInput('');
      return;
    }

    nextState = {
      ...nextState,
      playerScore: matchState.playerScore - score,
      lastMessage: `You scored ${score}.`,
    };
    nextState = runBotTurn(nextState);
    setMatchState(nextState);
    setScoreInput('');
  }

  function attemptCheckout() {
    if (!matchState || !possibleCheckout(matchState.playerScore)) return;
    submitScore(true, matchState.playerScore);
  }

  function manualBust() {
    if (!matchState) return;
    const snapshot = cloneSnapshot(matchState);
    const nextState: MatchPlayState = {
      ...matchState,
      stats: {
        ...matchState.stats,
        dartsThrown: matchState.stats.dartsThrown + 3,
        checkoutAttempts: matchState.stats.checkoutAttempts + (possibleCheckout(matchState.playerScore) ? 1 : 0),
      },
      history: [...matchState.history, snapshot],
      lastMessage: 'Manual bust.',
    };
    setMatchState(runBotTurn(nextState));
    setScoreInput('');
  }

  function undoVisit() {
    if (!matchState || matchState.history.length === 0) return;
    const previous = matchState.history[matchState.history.length - 1];
    setMatchState({ ...previous, history: matchState.history.slice(0, -1) });
    setScoreInput('');
  }

  function appendScoreDigit(digit: string) {
    setScoreInput((current) => {
      const next = `${current}${digit}`.replace(/^0+(?=\d)/, '');
      return next.length > 3 ? current : next;
    });
  }

  function setQuickScore(score: number) {
    submitScore(false, score);
  }

  function confirmPostMatchResult() {
    if (!pendingResult) return;

    if (pendingResult.context === 'quick') {
      setGameState((prev) => ({
        ...prev,
        overallStats: updateStatsBundle(prev.overallStats, pendingResult),
        matchHistory: appendMatchHistory(prev.matchHistory, createMatchHistoryItem(pendingResult, prev.seasonNumber, {
          roundLabel: `501 · FT${pendingResult.legsToWin}`,
        })),
      }));
      setPendingResult(null);
      setActiveMatch(null);
      setMatchState(null);
      setScreen('main');
      return;
    }

    if (pendingResult.context === 'event') {
      if (!pendingResult.eventId || !pendingResult.eventRound) return;

      const currentEvent = gameState.seasonEvents.find((event) => event.id === pendingResult.eventId);
      const currentEventIndex = Math.max(0, gameState.seasonEvents.findIndex((event) => event.id === pendingResult.eventId));
      const currentRound = currentEvent ? getEventCurrentRound(currentEvent) : pendingResult.eventRound;
      const nextRound = currentEvent ? getNextEventRound(currentEvent) : null;
      const shouldShowEventRecap = !!currentEvent && (!pendingResult.playerWon || !nextRound);
      const placementForRecap: EventPlacement = pendingResult.playerWon ? 'Winner' : getPlacementForRoundLoss(currentRound);
      const prizeForRecap = currentEvent
        ? placementForRecap === 'Winner'
          ? currentEvent.winnerPrize
          : placementForRecap === 'Runner-up'
            ? currentEvent.runnerUpPrize
            : 0
        : 0;
      const metaForRecap = currentEvent ? getEventDetailMeta(currentEvent, currentEventIndex) : null;
      const nextEventRecap: EventRecap | null = currentEvent && metaForRecap && shouldShowEventRecap
        ? {
            eventId: currentEvent.id,
            eventName: currentEvent.name,
            leagueName: LEAGUES[currentEvent.leagueIndex]?.name || 'League',
            venue: metaForRecap.venue,
            venueTier: metaForRecap.venueTier,
            theme: metaForRecap.theme,
            difficulty: currentEvent.difficulty,
            fieldSize: currentEvent.fieldSize || 4,
            legsToWin: currentEvent.legsToWin,
            placement: placementForRecap,
            prizeWon: prizeForRecap,
            playerWon: pendingResult.playerWon,
            round: currentRound,
            opponentName: pendingResult.opponentName,
            playerAverage: pendingResult.playerAverage,
            opponentAverage: pendingResult.opponentAverage,
            playerLegs: pendingResult.playerLegs,
            opponentLegs: pendingResult.opponentLegs,
          }
        : null;

      setGameState((prev) => {
        let prizeWon = 0;
        let completedHistory: EventHistoryItem | null = null;
        const updatedEvents = prev.seasonEvents.map((event) => {
          if (event.id !== pendingResult.eventId) return event;

          const liveRound = getEventCurrentRound(event);
          const liveNextRound = getNextEventRound(event);
          const currentRoundIndex = getEventCurrentRoundIndex(event);

          if (pendingResult.playerWon && liveNextRound) {
            return {
              ...event,
              currentRound: liveNextRound,
              currentRoundIndex: currentRoundIndex + 1,
            };
          }

          const placement: EventPlacement = pendingResult.playerWon ? 'Winner' : getPlacementForRoundLoss(liveRound);
          prizeWon = placement === 'Winner'
            ? event.winnerPrize
            : placement === 'Runner-up'
              ? event.runnerUpPrize
              : 0;

          completedHistory = {
            id: `${event.id}-${placement.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
            seasonNumber: event.seasonNumber,
            leagueName: LEAGUES[event.leagueIndex]?.name || 'League',
            eventName: event.name,
            difficulty: event.difficulty,
            fieldSize: event.fieldSize,
            legsToWin: event.legsToWin,
            placement,
            prizeWon,
          };

          return {
            ...event,
            status: 'completed' as EventStatus,
            placement,
            prizeWon,
          };
        });

        const overallStats = updateStatsBundle(prev.overallStats, pendingResult);
        const matchHistoryItem = createMatchHistoryItem(pendingResult, prev.seasonNumber, {
          leagueName: currentEvent ? LEAGUES[currentEvent.leagueIndex]?.name : currentLeague.name,
          eventName: currentEvent?.name,
          roundLabel: currentEvent ? getRoundLabel(currentRound) : pendingResult.eventRound,
          prizeMoney: prizeWon,
        });
        return {
          ...prev,
          seasonEvents: updatedEvents,
          eventHistory: completedHistory && !prev.eventHistory.some((item) => item.id === completedHistory?.id)
            ? [...prev.eventHistory, completedHistory]
            : prev.eventHistory,
          matchHistory: appendMatchHistory(prev.matchHistory, matchHistoryItem),
          overallStats: {
            ...overallStats,
            prizeMoney: overallStats.prizeMoney + prizeWon,
          },
        };
      });
      setSelectedEventId(pendingResult.eventId);
      setLastEventRecap(nextEventRecap);
      setPendingResult(null);
      setActiveMatch(null);
      setMatchState(null);
      setScreen(shouldShowEventRecap ? 'eventRecap' : 'eventDetail');
      return;
    }

    if (!pendingResult.fixtureId || !pendingResult.opponentId) return;

    let table = [...gameState.table];
    let fixtures = gameState.fixtures.map((fixture) => ({ ...fixture }));
    const playerWinnerId = pendingResult.playerWon ? PLAYER_ID : pendingResult.opponentId;
    const playerLoserId = pendingResult.playerWon ? pendingResult.opponentId : PLAYER_ID;
    const winnerLegs = pendingResult.playerWon ? pendingResult.playerLegs : pendingResult.opponentLegs;
    const loserLegs = pendingResult.playerWon ? pendingResult.opponentLegs : pendingResult.playerLegs;

    table = updateTableWithResult(table, playerWinnerId, playerLoserId, winnerLegs, loserLegs);
    fixtures = fixtures.map((fixture) => {
      if (fixture.id !== pendingResult.fixtureId) return fixture;
      return {
        ...fixture,
        played: true,
        result: {
          winnerId: playerWinnerId,
          loserId: playerLoserId,
          winnerLegs,
          loserLegs,
        },
      };
    });

    const round = pendingResult.round;
    if (round) {
      const roundFixtures = fixtures.filter((fixture) => fixture.round === round && !fixture.played && !isPlayerMatchFixture(fixture));
      roundFixtures.forEach((fixture) => {
        const home = table.find((row) => row.id === fixture.homeId);
        const away = table.find((row) => row.id === fixture.awayId);
        if (!home || !away) return;
        const sim = simulateBotLeagueMatch(home, away);
        table = updateTableWithResult(table, sim.winnerId, sim.loserId, sim.winnerLegs, sim.loserLegs);
        fixtures = fixtures.map((item) => item.id === fixture.id ? { ...item, played: true, result: sim } : item);
      });
    }

    const nextState: GameState = {
      ...gameState,
      table,
      fixtures,
      overallStats: updateStatsBundle(gameState.overallStats, pendingResult),
      leagueStats: updateStatsBundle(gameState.leagueStats, pendingResult) as LeagueStats,
      matchHistory: appendMatchHistory(gameState.matchHistory, createMatchHistoryItem(pendingResult, gameState.seasonNumber, {
        leagueName: currentLeague.name,
        roundLabel: pendingResult.round ? `Round ${pendingResult.round}` : undefined,
      })),
    };

    const shouldShowSeasonSummary = !getNextPlayerFixture(nextState.fixtures);
    setGameState(nextState);
    setPendingResult(null);
    setActiveMatch(null);
    setMatchState(null);
    setScreen(shouldShowSeasonSummary ? 'seasonSummary' : 'league');
  }

  function startNextSeason() {
    if (!gameState.profile) return;
    const position = getPlayerPosition(gameState.table);
    const playerRow = gameState.table.find((row) => row.id === PLAYER_ID);
    const prizeMoney = getLeaguePrize(gameState.currentLeagueIndex, position);
    let nextLeagueIndex = gameState.currentLeagueIndex;
    let movement: SeasonHistoryItem['movement'] = 'Stayed';

    if (position <= 2 && gameState.currentLeagueIndex < LEAGUES.length - 1) {
      nextLeagueIndex += 1;
      movement = 'Promoted';
    } else if (position >= 9 && gameState.currentLeagueIndex > 0) {
      nextLeagueIndex -= 1;
      movement = 'Relegated';
    }

    const nextSeasonNumber = gameState.seasonNumber + 1;
    const season = createSeason(gameState.profile, nextLeagueIndex, nextSeasonNumber, gameState.botPools);
    const eventReferenceAverage = getPlayerReferenceAverage(gameState.profile, gameState.overallStats, gameState.leagueStats, gameState.matchHistory);
    const seasonEvents = createSeasonEvents(gameState.profile, nextLeagueIndex, nextSeasonNumber, eventReferenceAverage);

    setGameState((prev) => {
      const baseLeagueStats = prev.leagueStats;
      return {
        ...prev,
        currentLeagueIndex: nextLeagueIndex,
        seasonNumber: nextSeasonNumber,
        table: season.table,
        fixtures: season.fixtures,
        seasonEvents,
        overallStats: {
          ...prev.overallStats,
          prizeMoney: prev.overallStats.prizeMoney + prizeMoney,
        },
        leagueStats: {
          ...baseLeagueStats,
          prizeMoney: baseLeagueStats.prizeMoney + prizeMoney,
          seasonsCompleted: baseLeagueStats.seasonsCompleted + 1,
          promotions: baseLeagueStats.promotions + (movement === 'Promoted' ? 1 : 0),
          relegations: baseLeagueStats.relegations + (movement === 'Relegated' ? 1 : 0),
          leagueTitles: baseLeagueStats.leagueTitles + (position === 1 ? 1 : 0),
          bestPosition: baseLeagueStats.bestPosition === null ? position : Math.min(baseLeagueStats.bestPosition, position),
          highestLeagueIndex: Math.max(baseLeagueStats.highestLeagueIndex, nextLeagueIndex),
        },
        seasonHistory: [
          ...prev.seasonHistory,
          {
            seasonNumber: prev.seasonNumber,
            leagueName: LEAGUES[prev.currentLeagueIndex].name,
            position,
            wins: playerRow?.wins || 0,
            losses: playerRow?.losses || 0,
            points: playerRow?.points || 0,
            legDifference: (playerRow?.legsFor || 0) - (playerRow?.legsAgainst || 0),
            prizeMoney,
            movement,
          },
        ],
      };
    });
    setScreen('league');
  }

  function resetAllData() {
    const confirmed = window.confirm('Reset all local app data? This cannot be undone.');
    if (!confirmed) return;
    localStorage.removeItem(STORAGE_KEY);
    setGameState(createEmptyGameState());
    setScreen('main');
  }


  function abandonActiveMatch() {
    const returnScreen = activeMatch?.context === 'league' ? 'league' : activeMatch?.context === 'event' ? 'eventDetail' : 'main';
    const confirmed = window.confirm('Exit this match? Current match progress will be lost and nothing will be saved.');
    if (!confirmed) return;
    setActiveMatch(null);
    setMatchState(null);
    setPendingResult(null);
    setScoreInput('');
    setScreen(returnScreen);
  }

  function renderMainMenu() {
    const hasProfile = Boolean(gameState.profile);
    const playerRow = gameState.table.find((row) => row.id === PLAYER_ID);
    const completedLeagueRounds = gameState.fixtures.filter((fixture) => fixture.played && isPlayerMatchFixture(fixture)).length;
    const nextOpponent = nextFixture
      ? gameState.table.find((row) => row.id === (nextFixture.homeId === PLAYER_ID ? nextFixture.awayId : nextFixture.homeId))
      : null;
    const overallAverage = calculateAverage(gameState.overallStats.scoredTotal, gameState.overallStats.dartsThrown);
    const targetProgress = gameState.profile
      ? clamp(
          ((overallAverage - gameState.profile.startingAverage) / Math.max(1, gameState.profile.targetAverage - gameState.profile.startingAverage)) * 100,
          0,
          100
        )
      : 0;
    const playerRecord = playerRow ? `${playerRow.wins}-${playerRow.losses}` : '0-0';
    const nextMatchText = nextOpponent ? `Round ${nextFixture?.round} · ${nextOpponent.name}` : hasProfile ? 'Season summary ready' : 'Create your profile';

    return (
      <main className="page main-page main-polish-page">
        <section className="home-hero-panel">
          <div className="home-hero-copy">
            <div className="home-kicker-row">
              <span className="home-version-pill">v0.8.6</span>
              <span className="home-save-dot">Local save</span>
            </div>
            <h1>Dart League</h1>
            <p>Play your league season first. Use quick matches, events and stats as support around the main career loop.</p>
          </div>

          <div className="home-hero-badge">
            <span>Current</span>
            <strong>{hasProfile ? currentLeague.shortName : 'Start'}</strong>
            <small>{hasProfile ? `Season ${gameState.seasonNumber}` : 'League Mode'}</small>
          </div>
        </section>

        <section className="home-status-card">
          <div className="home-status-main">
            <span>{hasProfile ? 'Next up' : 'Ready to start'}</span>
            <strong>{nextMatchText}</strong>
            <small>{hasProfile ? `${completedLeagueRounds}/9 league rounds played` : 'Set your starting average and target average.'}</small>
          </div>
          <button className="home-primary-action" onClick={() => setScreen('league')}>
            {hasProfile ? 'Continue League' : 'Start League'}
          </button>
        </section>

        {hasProfile && (
          <section className="home-progress-card">
            <div className="home-progress-header">
              <div>
                <span>Development target</span>
                <strong>{gameState.profile?.startingAverage} → {gameState.profile?.targetAverage} avg</strong>
              </div>
              <b>{Math.round(targetProgress)}%</b>
            </div>
            <div className="home-progress-track"><i style={{ width: `${targetProgress}%` }} /></div>
            <div className="home-mini-stats">
              <div><span>Position</span><strong>#{playerPosition || '-'}</strong></div>
              <div><span>Record</span><strong>{playerRecord}</strong></div>
              <div><span>Average</span><strong>{overallAverage.toFixed(1)}</strong></div>
              <div><span>Money</span><strong>£{gameState.overallStats.prizeMoney}</strong></div>
            </div>
          </section>
        )}

        <section className="home-menu-stack" aria-label="Main menu">
          <button className="home-menu-card home-menu-card-league" onClick={() => setScreen('league')}>
            <div className="home-menu-icon">🏆</div>
            <div>
              <span>League Mode</span>
              <small>Play your season and chase promotion.</small>
            </div>
            <b>Open</b>
          </button>

          <button className="home-menu-card" onClick={() => setScreen('quickSetup')}>
            <div className="home-menu-icon">🎯</div>
            <div>
              <span>Quick Match</span>
              <small>Set up points, legs and bot difficulty.</small>
            </div>
            <b>Play</b>
          </button>

          <button className="home-menu-card" onClick={() => setScreen('stats')}>
            <div className="home-menu-icon">📊</div>
            <div>
              <span>Stats</span>
              <small>Overall and League Mode performance.</small>
            </div>
            <b>View</b>
          </button>
        </section>
      </main>
    );
  }

  function renderLeagueSetup() {
    return (
      <main className="page">
        <button className="ghost-button" onClick={() => setScreen('main')}>← Main Menu</button>
        <section className="card">
          <p className="eyebrow">First League Setup</p>
          <h2>Create your league profile</h2>
          <p className="muted">Bots are generated from your starting average and become harder through the 5 leagues. Your target average must be higher than your starting average.</p>

          <label className="field-label">Player name</label>
          <input className="input" value={setupName} onChange={(event) => setSetupName(event.target.value)} placeholder="Your name" />

          <label className="field-label">Starting average</label>
          <input className="input" type="number" value={setupAverage} onChange={(event) => setSetupAverage(event.target.value)} />

          <label className="field-label">Target average</label>
          <input className="input" type="number" value={setupTarget} onChange={(event) => setSetupTarget(event.target.value)} />

          <button className="primary-button full" onClick={startLeagueProfile}>Start League Career</button>
        </section>
      </main>
    );
  }

  function renderLeagueOverview() {
    if (!gameState.profile) return renderLeagueSetup();
    const nextOpponent = nextFixture
      ? gameState.table.find((row) => row.id === (nextFixture.homeId === PLAYER_ID ? nextFixture.awayId : nextFixture.homeId))
      : null;
    const playerRow = gameState.table.find((row) => row.id === PLAYER_ID);
    const completedRounds = gameState.fixtures.filter((fixture) => fixture.played && (fixture.homeId === PLAYER_ID || fixture.awayId === PLAYER_ID)).length;
    const seasonProgress = Math.round((completedRounds / 9) * 100);
    const legDifference = playerRow ? playerRow.legsFor - playerRow.legsAgainst : 0;
    const positionLabel = playerPosition ? `#${playerPosition}` : '-';
    const zoneLabel = playerPosition <= 2
      ? 'Promotion race'
      : playerPosition >= 9 && gameState.currentLeagueIndex > 0
        ? 'Relegation danger'
        : playerPosition >= 9
          ? 'Rebuild zone'
          : 'Safe mid-table';
    const zoneClass = playerPosition <= 2 ? 'promotion' : playerPosition >= 9 ? 'danger' : 'safe';
    const leagueAverageText = getLeagueAverageText(gameState.profile, gameState.currentLeagueIndex);
    const currentLevelInfo = getAdaptiveCurrentLevel(gameState.profile, gameState.overallStats, gameState.leagueStats, gameState.matchHistory);
    const nextOpponentInsight = nextOpponent
      ? getOpponentInsight(nextOpponent.average, currentLevelInfo.currentLevel)
      : null;

    return (
      <main className="page league-polish-page">
        <button className="ghost-button" onClick={() => setScreen('main')}>← Main Menu</button>

        <section className="league-dashboard-hero">
          <div className="league-hero-copy">
            <p className="eyebrow">League Mode</p>
            <h2>{currentLeague.name}</h2>
            <p>Season {gameState.seasonNumber} · {gameState.profile.name} · {currentLeague.levelText}</p>
          </div>
          <div className={`league-zone-badge ${zoneClass}`}>
            <span>{zoneLabel}</span>
            <strong>{positionLabel}</strong>
          </div>
        </section>

        <section className="league-focus-grid">
          <div className="league-focus-card primary">
            <span>Position</span>
            <strong>{positionLabel}</strong>
            <small>{playerRow?.points || 0} pts · {legDifference >= 0 ? `+${legDifference}` : legDifference} legs</small>
          </div>
          <div className="league-focus-card">
            <span>Season</span>
            <strong>{completedRounds}/9</strong>
            <small>{seasonProgress}% complete</small>
          </div>
          <div className="league-focus-card adaptive-level-card">
            <span>Current level</span>
            <strong>{currentLevelInfo.currentLevel} avg</strong>
            <small>Recent {currentLevelInfo.recentAverage || '-'} · Overall {currentLevelInfo.overallAverage || '-'}</small>
          </div>
          <div className="league-focus-card">
            <span>Target avg</span>
            <strong>{gameState.profile.startingAverage} → {gameState.profile.targetAverage}</strong>
            <small>{currentLevelInfo.progress}% to target · bots: {leagueAverageText}</small>
          </div>
        </section>

        <section className="league-progress-card">
          <div>
            <span>Season progress</span>
            <strong>{completedRounds} of 9 rounds played</strong>
          </div>
          <div className="progress-track"><i style={{ width: `${seasonProgress}%` }} /></div>
        </section>

        <section className="league-next-card core-next-action-card">
          {nextFixture && nextOpponent ? (
            <>
              <div className="section-row-header">
                <div>
                  <p className="eyebrow">Next action</p>
                  <h3>Play Next League Match</h3>
                </div>
                <span className="round-pill">League Round {nextFixture.round} · FT2</span>
              </div>

              <div className="next-match-versus">
                <div>
                  <span>You</span>
                  <strong>{gameState.profile.name}</strong>
                  <small>Current level {currentLevelInfo.currentLevel} avg</small>
                </div>
                <b>VS</b>
                <div>
                  <span>Opponent</span>
                  <strong>{nextOpponent.name}</strong>
                  <small>{nextOpponent.average} avg</small>
                </div>
              </div>

              {nextOpponentInsight && (
                <div className={`opponent-scout-card ${nextOpponentInsight.className}`}>
                  <div>
                    <span>Opponent level</span>
                    <strong>{nextOpponentInsight.label}</strong>
                    <small>{nextOpponentInsight.detail}</small>
                  </div>
                  <b>{nextOpponentInsight.shortLabel}</b>
                </div>
              )}

              <button className="primary-button full next-action-main-button" onClick={startLeagueMatch}>Play Next League Match</button>
              <div className="next-action-benefits">
                <span>Updates table</span>
                <span>Unlocks next event</span>
                <span>Moves season forward</span>
              </div>
              <p className="core-action-note">This is the main career action. Events, trophies and history are secondary.</p>
            </>
          ) : (
            <>
              <div className="section-row-header">
                <div>
                  <p className="eyebrow">Season complete</p>
                  <h3>All 9 league rounds are finished</h3>
                </div>
                <span className="round-pill done">Done</span>
              </div>
              <p className="muted">Review your final position, prize money and promotion/relegation result.</p>
              <button className="primary-button full" onClick={() => setScreen('seasonSummary')}>View Season Summary</button>
            </>
          )}
        </section>

        <section className="league-tools-panel">
          <div className="section-row-header compact">
            <div>
              <p className="eyebrow">Secondary actions</p>
              <h3>League tools</h3>
            </div>
            <span className="round-pill">After match</span>
          </div>
          <div className="league-action-grid tightened-tools-grid next-action-tools-grid">
            <button className="secondary-button tool-secondary" onClick={() => setScreen('leagueEvents')}>
              <span>Optional Events</span>
              <small>Side cups · unlocked through league progress</small>
            </button>
            <button className="secondary-button tool-secondary" onClick={() => setScreen('leagueTable')}>
              <span>League Table</span>
              <small>Position, points and zones</small>
            </button>
            <button className="secondary-button tool-secondary" onClick={() => setScreen('trophyRoom')}>
              <span>Trophy Room</span>
              <small>League podiums and event cups</small>
            </button>
            <button className="secondary-button tool-secondary" onClick={() => setScreen('matchHistory')}>
              <span>Match History</span>
              <small>Recent confirmed results</small>
            </button>
            <button className="secondary-button tool-secondary subtle-tool" onClick={() => setScreen('stats')}>
              <span>League Stats</span>
              <small>Performance and progress</small>
            </button>
          </div>
        </section>
      </main>
    );
  }


  function renderLeagueEvents() {
    if (!gameState.profile) return renderLeagueSetup();
    const referenceAverage = getPlayerReferenceAverage(gameState.profile, gameState.overallStats, gameState.leagueStats, gameState.matchHistory);
    const completedEvents = gameState.seasonEvents.filter((event) => event.status === 'completed').length;
    const completedLeagueRounds = getCompletedLeagueRounds(gameState.fixtures);
    const unlockedEventCount = getUnlockedEventCount(gameState.fixtures, gameState.seasonEvents.length);
    const prizeAvailable = gameState.seasonEvents
      .filter((event, index) => event.status !== 'completed' && isEventUnlocked(index, gameState.fixtures, gameState.seasonEvents.length))
      .reduce((sum, event) => sum + event.winnerPrize, 0);

    return (
      <main className="page wide-page league-events-page compact-events-page">
        <button className="ghost-button" onClick={() => setScreen('league')}>← League Mode</button>

        <section className="events-hero-card compact-events-hero">
          <div>
            <p className="eyebrow">Optional Events</p>
            <h2>{currentLeague.shortName} event board</h2>
            <p>Side cups unlock gradually as your league season progresses, so the league remains the main path.</p>
          </div>
          <div className="events-hero-summary">
            <span>Current level</span>
            <strong>{referenceAverage}</strong>
            <small>Event bots scale from this</small>
          </div>
        </section>

        <section className="events-compact-summary">
          <div>
            <span>Unlocked events</span>
            <strong>{unlockedEventCount}/{gameState.seasonEvents.length}</strong>
          </div>
          <div>
            <span>League rounds played</span>
            <strong>{completedLeagueRounds}/9</strong>
          </div>
          <div>
            <span>Available prize pool</span>
            <strong>£{prizeAvailable}</strong>
          </div>
          <div>
            <span>Venues</span>
            <strong>{getEventVenueTier(gameState.currentLeagueIndex)}</strong>
          </div>
        </section>

        <section className="event-flow-note">
          <strong>Side event rules</strong>
          <span>One new event unlocks after each completed league round. Events are optional and save to Overall Stats, prize money and Event Cabinet only. League Table, promotion and relegation stay unchanged.</span>
        </section>

        <section className="event-compact-list">
          {gameState.seasonEvents.map((event, index) => {
            const detail = getEventDifficultyDetail(event, referenceAverage);
            const currentRound = getEventCurrentRound(event);
            const isCompleted = event.status === 'completed';
            const isUnlocked = isEventUnlocked(index, gameState.fixtures, gameState.seasonEvents.length);
            const meta = getEventDetailMeta(event, index);
            return (
              <button
                key={event.id}
                type="button"
                className={`event-compact-row theme-${meta.theme} ${isCompleted ? 'completed' : ''} ${!isUnlocked ? 'locked' : ''}`}
                onClick={() => {
                  setSelectedEventId(event.id);
                  setScreen('eventDetail');
                }}
              >
                <div className="event-compact-main">
                  <span className={`event-difficulty ${event.difficulty.toLowerCase()}`}>{isUnlocked ? event.difficulty : 'Locked'}</span>
                  <strong>{event.name}</strong>
                  <small>{meta.venue} · {event.fieldSize || 4} players · 501 FT{event.legsToWin}</small>
                </div>
                <div className="event-compact-side">
                  <span>{isCompleted ? event.placement : isUnlocked ? getRoundLabel(currentRound) : `Event ${index + 1}`}</span>
                  <strong>{isCompleted ? `£${event.prizeWon || 0}` : isUnlocked ? `${detail.opponentAverage} avg` : 'Locked'}</strong>
                  <small>{isCompleted ? 'Completed' : isUnlocked ? detail.shortLabel : getEventUnlockLabel(index)}</small>
                </div>
              </button>
            );
          })}
        </section>

        {gameState.eventHistory.length > 0 && (
          <section className="events-history-panel compact-events-history">
            <div className="section-row-header">
              <div>
                <p className="eyebrow">Event History</p>
                <h3>Recent event results</h3>
              </div>
            </div>
            <div className="event-history-list">
              {[...gameState.eventHistory].reverse().slice(0, 5).map((event) => (
                <div key={event.id} className="event-history-row">
                  <div>
                    <strong>{event.eventName}</strong>
                    <span>Season {event.seasonNumber} · {event.leagueName} · {event.fieldSize || 4} players · FT{event.legsToWin || 2} · {event.placement}</span>
                  </div>
                  <small>£{event.prizeWon}</small>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>
    );
  }

  function renderEventDetail() {
    if (!gameState.profile) return renderLeagueSetup();
    const event = gameState.seasonEvents.find((item) => item.id === selectedEventId) || gameState.seasonEvents[0];
    if (!event) {
      return (
        <main className="page wide-page">
          <button className="ghost-button" onClick={() => setScreen('leagueEvents')}>← Events</button>
          <section className="card">
            <h2>No event selected</h2>
            <p className="muted">Go back to the event board and choose a tournament.</p>
          </section>
        </main>
      );
    }

    const eventIndex = Math.max(0, gameState.seasonEvents.findIndex((item) => item.id === event.id));
    const isUnlocked = isEventUnlocked(eventIndex, gameState.fixtures, gameState.seasonEvents.length);
    const completedLeagueRounds = getCompletedLeagueRounds(gameState.fixtures);
    const referenceAverage = getPlayerReferenceAverage(gameState.profile, gameState.overallStats, gameState.leagueStats, gameState.matchHistory);
    const participants = getEventParticipants(event, gameState.profile, referenceAverage);
    const currentRound = getEventCurrentRound(event);
    const currentRoundIndex = getEventCurrentRoundIndex(event);
    const rounds = getEventRounds(event.fieldSize || 4);
    const bracketRounds = getEventBracketRounds(event, participants);
    const opponent = getEventOpponent(event);
    const detail = getEventDifficultyDetail(event, referenceAverage);
    const isCompleted = event.status === 'completed';
    const meta = getEventDetailMeta(event, eventIndex);
    const progress = Math.round(((currentRoundIndex + (isCompleted ? 1 : 0)) / rounds.length) * 100);

    return (
      <main className={`page wide-page event-detail-page theme-${meta.theme}`}>
        <button className="ghost-button" onClick={() => setScreen('leagueEvents')}>← Events</button>

        <section className={`event-detail-hero theme-${meta.theme}`}>
          <div>
            <p className="eyebrow">League Event</p>
            <h2>{event.name}</h2>
            <p>{meta.venue} · {meta.venueTier}</p>
            <div className="event-detail-chip-row">
              <span>{event.fieldSize || 4} players</span>
              <span>501 · FT{event.legsToWin}</span>
              <span>{event.difficulty}</span>
            </div>
          </div>
          <div className="event-venue-badge">
            <span>Venue</span>
            <strong>{meta.venue}</strong>
            <small>{meta.venueTier}</small>
          </div>
        </section>

        <section className="event-detail-status-card">
          <div className="section-row-header compact">
            <div>
              <p className="eyebrow">{isCompleted ? 'Result' : 'Next Match'}</p>
              <h3>{isCompleted ? event.placement : getRoundLabel(currentRound)}</h3>
            </div>
            <span className={`round-pill ${isCompleted ? 'green' : ''}`}>{isCompleted ? `£${event.prizeWon || 0}` : `${opponent.average} avg`}</span>
          </div>
          <div className="event-detail-progress">
            <span style={{ width: `${clamp(progress, 6, 100)}%` }} />
          </div>
          <div className="event-next-opponent-card">
            <div>
              <span>{isCompleted ? 'Tournament finished' : 'Opponent'}</span>
              <strong>{isCompleted ? `${event.placement}` : opponent.name}</strong>
              <small>{isCompleted ? `Prize won £${event.prizeWon || 0}` : `${detail.label} · ${detail.detail}`}</small>
            </div>
            <div>
              <span>Winner prize</span>
              <strong>£{event.winnerPrize}</strong>
              <small>Runner-up £{event.runnerUpPrize}</small>
            </div>
          </div>
          {!isUnlocked && !isCompleted && (
            <div className="event-lock-notice">
              <strong>Locked for now</strong>
              <span>{getEventUnlockLabel(eventIndex)}. You have completed {completedLeagueRounds}/9 league rounds this season.</span>
            </div>
          )}
          {isCompleted ? (
            <button className="secondary-button full" disabled>Event Completed</button>
          ) : (
            <button className="primary-button full" onClick={() => startEventMatch(event)} disabled={!isUnlocked}>
              {isUnlocked ? `Play ${getRoundLabel(currentRound)}` : 'Complete league rounds to unlock'}
            </button>
          )}
        </section>

        <section className="event-detail-grid">
          <div className="event-detail-panel">
            <div className="section-row-header compact">
              <div>
                <p className="eyebrow">Field</p>
                <h3>Participants</h3>
              </div>
              <span className="round-pill">{participants.length}</span>
            </div>
            <div className="event-participant-list">
              {participants.map((participant) => (
                <div key={participant.id} className={`event-participant-row ${participant.isPlayer ? 'you' : ''}`}>
                  <span>#{participant.seed}</span>
                  <strong>{participant.name}</strong>
                  <small>{participant.average} avg</small>
                </div>
              ))}
            </div>
          </div>

          <div className="event-detail-panel compact-bracket-panel">
            <div className="section-row-header compact">
              <div>
                <p className="eyebrow">Tournament Path</p>
                <h3>Your Route</h3>
              </div>
              <span className="round-pill">{getRoundLabel(currentRound)}</span>
            </div>
            <div className="event-compact-bracket">
              {bracketRounds.map((round, roundIndex) => {
                const playerPathMatch = round.matches.find((match) => match.isPlayerPath) || round.matches[0];
                const otherMatches = Math.max(0, round.matches.length - 1);
                return (
                  <div key={round.round} className={`event-compact-round ${roundIndex === currentRoundIndex ? 'active' : ''} ${roundIndex < currentRoundIndex ? 'passed' : ''}`}>
                    <div className="compact-round-head">
                      <div>
                        <strong>{round.label}</strong>
                        <small>{round.matches.length} match{round.matches.length === 1 ? '' : 'es'}</small>
                      </div>
                      <span>{roundIndex < currentRoundIndex ? 'Done' : roundIndex === currentRoundIndex ? 'Now' : 'Next'}</span>
                    </div>
                    {playerPathMatch && (
                      <div className={`compact-player-path ${playerPathMatch.isPlayerPath ? 'highlight' : ''}`}>
                        <span>{playerPathMatch.playerA}</span>
                        <em>vs</em>
                        <span>{playerPathMatch.playerB}</span>
                      </div>
                    )}
                    {otherMatches > 0 && (
                      <div className="compact-bracket-note">
                        + {otherMatches} other match{otherMatches === 1 ? '' : 'es'} simulated in this round
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </main>
    );
  }

  function renderLeagueTable() {
    const playerRow = gameState.table.find((row) => row.id === PLAYER_ID);
    const completedRounds = gameState.fixtures.filter((fixture) => fixture.played && (fixture.homeId === PLAYER_ID || fixture.awayId === PLAYER_ID)).length;
    const referenceAverage = gameState.profile?.startingAverage || 40;
    const leagueAverageText = getLeagueAverageText(gameState.profile, gameState.currentLeagueIndex);
    const playerLegDiff = playerRow ? playerRow.legsFor - playerRow.legsAgainst : 0;
    const playerPoints = playerRow?.points || 0;
    const playerPrizePreview = currentLeague.prizes[Math.max(0, (playerPosition || 1) - 1)] || 0;
    const promotionCutoff = sortedTable[1]?.points ?? 0;
    const dangerCutoff = sortedTable[8]?.points ?? 0;
    const promotionStatus = playerPosition <= 2
      ? 'Currently in the promotion places'
      : `${Math.max(0, promotionCutoff - playerPoints + 2)} pts to reach top 2`;
    const safetyStatus = gameState.currentLeagueIndex === 0
      ? 'No relegation from Pub League'
      : playerPosition >= 9
        ? 'Currently in the bottom 2'
        : `${Math.max(0, playerPoints - dangerCutoff)} pts above bottom 2`;

    return (
      <main className="page wide-page league-polish-page">
        <button className="ghost-button" onClick={() => setScreen('league')}>← League Mode</button>
        <section className="league-table-shell league-table-polish-shell">
          <div className="section-row-header table-title-row league-table-polish-title">
            <div>
              <p className="eyebrow">{currentLeague.name} · Season {gameState.seasonNumber}</p>
              <h2>League Table</h2>
              <p className="muted compact-muted">Top 2 go up. Bottom 2 go down, unless you are already in Pub League.</p>
            </div>
            <div className="mini-table-summary season-round-pill">
              <span>{completedRounds}/9</span>
              <small>rounds</small>
            </div>
          </div>

          <div className="league-table-player-dashboard">
            <div className="player-position-card">
              <span>Your position</span>
              <strong>#{playerPosition || '-'}</strong>
              <small>{playerRow?.wins || 0}W · {playerRow?.losses || 0}L · {playerPoints} pts</small>
            </div>
            <div className="table-mini-metric">
              <span>Leg +/-</span>
              <strong>{playerLegDiff >= 0 ? `+${playerLegDiff}` : playerLegDiff}</strong>
            </div>
            <div className="table-mini-metric prize">
              <span>Prize now</span>
              <strong>£{playerPrizePreview}</strong>
            </div>
            <div className="table-mini-metric range">
              <span>Bot range</span>
              <strong>{leagueAverageText}</strong>
            </div>
          </div>

          <div className="league-table-race-strip">
            <div className="race-card promotion">
              <span>Promotion race</span>
              <strong>{promotionStatus}</strong>
            </div>
            <div className={`race-card ${gameState.currentLeagueIndex === 0 ? 'safe' : playerPosition >= 9 ? 'danger' : 'safe'}`}>
              <span>{gameState.currentLeagueIndex === 0 ? 'Safety' : 'Relegation watch'}</span>
              <strong>{safetyStatus}</strong>
            </div>
          </div>

          <div className="league-zone-legend polished-zone-legend">
            <span><i className="legend-dot promote" />Promotion zone</span>
            <span><i className="legend-dot neutral" />Safe zone</span>
            <span><i className="legend-dot danger" />{gameState.currentLeagueIndex === 0 ? 'Rebuild zone' : 'Relegation zone'}</span>
            <span><i className="legend-dot player" />You</span>
          </div>

          <div className="league-table-card-list" aria-label="League table cards">
            {sortedTable.map((row, index) => {
              const zone = index < 2 ? 'promotion' : index >= sortedTable.length - 2 ? 'danger' : 'safe';
              const legDiff = row.legsFor - row.legsAgainst;
              const insight = getOpponentInsight(row.average, referenceAverage);
              return (
                <article key={row.id} className={`league-row-card ${zone} ${row.isPlayer ? 'is-player' : ''}`}>
                  <div className="league-row-rank-block">
                    <span>#{index + 1}</span>
                    <small>{zone === 'promotion' ? 'UP' : zone === 'danger' ? (gameState.currentLeagueIndex === 0 ? 'SAFE' : 'DOWN') : 'MID'}</small>
                  </div>
                  <div className="league-row-main">
                    <strong>{row.name}</strong>
                    <small>{row.isPlayer ? 'You' : insight.shortLabel} · {row.average} avg</small>
                  </div>
                  <div className="league-row-record">
                    <strong>{row.points}</strong>
                    <small>{row.wins}-{row.losses} · {legDiff >= 0 ? `+${legDiff}` : legDiff}</small>
                  </div>
                </article>
              );
            })}
          </div>

          <div className="table-wrap polished-league-table-wrap league-table-desktop-wrap">
            <table className="polished-league-table upgraded-league-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Player</th>
                  <th>Level</th>
                  <th>Avg</th>
                  <th>P</th>
                  <th>W</th>
                  <th>L</th>
                  <th>Legs</th>
                  <th>+/-</th>
                  <th>Pts</th>
                </tr>
              </thead>
              <tbody>
                {sortedTable.map((row, index) => {
                  const legDiff = row.legsFor - row.legsAgainst;
                  const zone = index < 2 ? 'promotion-row' : index >= sortedTable.length - 2 ? 'relegation-row' : 'safe-row';
                  const insight = getOpponentInsight(row.average, referenceAverage);
                  return (
                    <tr key={row.id} className={`${row.isPlayer ? 'player-row' : ''} ${zone}`}>
                      <td><span className="table-rank">{index + 1}</span></td>
                      <td>
                        <div className="table-player-cell">
                          <strong>{row.name}</strong>
                          <small>{row.isPlayer ? 'Your career' : `${currentLeague.shortName} opponent`}</small>
                        </div>
                      </td>
                      <td><span className={`table-level-badge ${row.isPlayer ? 'player' : insight.className}`}>{getBotLevelLabel(row, referenceAverage)}</span></td>
                      <td><span className={`avg-level-pill ${row.isPlayer ? 'player' : insight.className}`}>{row.average}</span></td>
                      <td>{row.played}</td>
                      <td>{row.wins}</td>
                      <td>{row.losses}</td>
                      <td>{row.legsFor}-{row.legsAgainst}</td>
                      <td><span className={legDiff >= 0 ? 'positive-diff' : 'negative-diff'}>{legDiff >= 0 ? `+${legDiff}` : legDiff}</span></td>
                      <td><strong className="points-total">{row.points}</strong></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    );
  }



  function renderMatch() {
    if (!activeMatch || !matchState) return null;
    const playerName = gameState.profile?.name || 'Player';
    const playerAverage = calculateAverage(matchState.stats.scoredTotal, matchState.stats.dartsThrown);
    const botAverage = calculateAverage(matchState.botStats.scoredTotal, matchState.botStats.dartsThrown);
    const buttons = ['1','2','3','4','5','6','7','8','9'];
    const checkoutRoute = getCheckoutRoute(matchState.playerScore);
    const showCheckoutGuide = matchState.playerScore < 180;
    const canCheckoutNow = Boolean(checkoutRoute);
    const manualScoreValue = scoreInput === '' ? null : Number(scoreInput);
    const manualScoreValid = manualScoreValue !== null && Number.isFinite(manualScoreValue) && manualScoreValue >= 0 && manualScoreValue <= 180;
    const manualWouldBust = manualScoreValid ? manualScoreValue > matchState.playerScore || matchState.playerScore - manualScoreValue === 1 : false;
    const manualRemaining = manualScoreValid && !manualWouldBust ? matchState.playerScore - manualScoreValue : null;
    const canSubmitManual = scoreInput.length > 0 && manualScoreValid;
    const playerCheckoutLabel = showCheckoutGuide
      ? checkoutRoute || 'Set up finish'
      : 'Not in range yet';
    const contextLabel = activeMatch.context === 'league' ? 'League Match' : activeMatch.context === 'event' ? 'Event Match' : 'Quick Match';

    return (
      <main className="match-page pro-match-page polished-match-page">
        <section className="match-command-bar">
          <div className="match-command-left">
            <span className="match-context-pill">{contextLabel}</span>
            <div>
              <h2>{activeMatch.startingScore} · First to {activeMatch.legsToWin}</h2>
              <p>{playerName} vs {activeMatch.opponentName}</p>
            </div>
          </div>
          <button className="match-exit-button" onClick={abandonActiveMatch}>Exit</button>
        </section>

        <section className="match-stage-card">
          <div className="score-hero-row">
            <div className="score-hero-player active">
              <div className="score-hero-topline">
                <span>{playerName}</span>
                <small><i className="throw-dot" /> Throwing</small>
              </div>
              <strong>{matchState.playerScore}</strong>
              <div className="score-hero-meta">
                <span>Avg {playerAverage}</span>
                <span>Need {matchState.playerScore}</span>
              </div>
              <div className="leg-dots" aria-label={`Your legs ${matchState.playerLegs} of ${activeMatch.legsToWin}`}>
                {Array.from({ length: activeMatch.legsToWin }).map((_, index) => (
                  <i key={index} className={index < matchState.playerLegs ? 'filled' : ''} />
                ))}
              </div>
            </div>

            <div className="score-divider">
              <span>VS</span>
              <strong>{matchState.playerLegs}-{matchState.botLegs}</strong>
              <small>legs</small>
            </div>

            <div className="score-hero-player">
              <div className="score-hero-topline">
                <span>{activeMatch.opponentName}</span>
                <small>Bot</small>
              </div>
              <strong>{matchState.botScore}</strong>
              <div className="score-hero-meta">
                <span>Avg {botAverage}</span>
                <span>Level {activeMatch.opponentAverage}</span>
              </div>
              <div className="leg-dots" aria-label={`Bot legs ${matchState.botLegs} of ${activeMatch.legsToWin}`}>
                {Array.from({ length: activeMatch.legsToWin }).map((_, index) => (
                  <i key={index} className={index < matchState.botLegs ? 'filled bot' : ''} />
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="play-control-panel">
          <div className={canCheckoutNow ? 'require-major available' : 'require-major'}>
            <span>You require</span>
            <strong>{matchState.playerScore}</strong>
            <small>{canCheckoutNow ? 'Checkout available' : showCheckoutGuide ? 'No direct checkout' : 'Not in range yet'}</small>
          </div>

          <div className="route-chip">
            <span>Route</span>
            <strong>{playerCheckoutLabel}</strong>
          </div>

          <div className="visit-panel">
            <div>
              <span>Visit score</span>
              <strong>{scoreInput || '0'}</strong>
            </div>
            <small className={manualWouldBust ? 'danger-text' : ''}>
              {scoreInput.length === 0
                ? `Leaves ${matchState.playerScore}`
                : manualWouldBust
                  ? 'Bust'
                  : `Leaves ${manualRemaining}`}
            </small>
          </div>
        </section>

        <section className="match-feedback-strip">
          <span>Last update</span>
          <p>{matchState.lastMessage}</p>
        </section>

        <section className="pro-keypad-card polished-keypad-card">
          <div className="keypad-section-title">
            <span>Quick score</span>
            <small>Tap to score instantly</small>
          </div>
          <div className="pro-quick-row polished-quick-row">
            {QUICK_SCORE_VALUES.map((score) => (
              <button key={score} onClick={() => setQuickScore(score)}>{score}</button>
            ))}
          </div>

          <div className="keypad-section-title manual-title">
            <span>Manual score</span>
            <small>Enter a custom visit</small>
          </div>
          <section className="pro-keypad-grid polished-number-grid">
            {buttons.map((button) => (
              <button key={button} className="pro-number-key" onClick={() => appendScoreDigit(button)}>{button}</button>
            ))}
            <button className="pro-soft-key" onClick={() => setScoreInput('')}>Clear</button>
            <button className="pro-number-key" onClick={() => appendScoreDigit('0')}>0</button>
            <button className={canSubmitManual ? 'pro-enter-key' : 'pro-enter-key disabled'} disabled={!canSubmitManual} onClick={() => submitScore(false)}>Enter</button>
          </section>

          <section className="pro-action-grid polished-action-grid">
            <button className={matchState.history.length > 0 ? 'pro-soft-action' : 'pro-soft-action disabled'} disabled={matchState.history.length === 0} onClick={undoVisit}>Undo</button>
            <button className="pro-danger-action" onClick={manualBust}>Bust</button>
            <button className={canCheckoutNow ? 'pro-checkout-action' : 'pro-checkout-action disabled'} disabled={!canCheckoutNow} onClick={attemptCheckout}>Checkout</button>
          </section>
        </section>
      </main>
    );
  }

  function renderEventRecap() {
    const recap = lastEventRecap;
    if (!recap) {
      return (
        <main className="page wide-page event-recap-page">
          <button className="ghost-button" onClick={() => setScreen('leagueEvents')}>← Events</button>
          <section className="card">
            <h2>No event recap available</h2>
            <p className="muted">Finish an event match to view the event ending screen.</p>
          </section>
        </main>
      );
    }

    const isWinner = recap.placement === 'Winner';
    const isRunnerUp = recap.placement === 'Runner-up';
    const resultTitle = isWinner ? 'EVENT WON' : isRunnerUp ? 'RUNNER-UP' : 'KNOCKED OUT';
    const resultText = isWinner
      ? `You won ${recap.eventName} and added a cup to the Event Cabinet.`
      : isRunnerUp
        ? `You reached the final of ${recap.eventName}.`
        : `Your ${recap.eventName} run ended in the ${recap.placement}.`;

    return (
      <main className={`page wide-page event-recap-page theme-${recap.theme}`}>
        <section className={`event-recap-hero ${isWinner ? 'winner' : 'exit'} theme-${recap.theme}`}>
          <p className="eyebrow">Event Complete</p>
          <h2>{resultTitle}</h2>
          <p>{resultText}</p>
          <div className="event-recap-chip-row">
            <span>{recap.leagueName}</span>
            <span>{recap.fieldSize} players</span>
            <span>501 · FT{recap.legsToWin}</span>
            <span>{recap.difficulty}</span>
          </div>
        </section>

        <section className="event-recap-grid">
          <div className="event-recap-card big-result">
            <span>Final event result</span>
            <strong>{recap.placement}</strong>
            <small>{getRoundLabel(recap.round)} · {recap.playerLegs}-{recap.opponentLegs} vs {recap.opponentName}</small>
          </div>
          <div className="event-recap-card">
            <span>Prize money</span>
            <strong>£{recap.prizeWon}</strong>
            <small>{isWinner ? 'Winner prize claimed' : isRunnerUp ? 'Runner-up prize claimed' : 'No prize this time'}</small>
          </div>
          <div className="event-recap-card">
            <span>Venue</span>
            <strong>{recap.venue}</strong>
            <small>{recap.venueTier}</small>
          </div>
          <div className="event-recap-card">
            <span>Match averages</span>
            <strong>{recap.playerAverage} / {recap.opponentAverage}</strong>
            <small>You / opponent</small>
          </div>
        </section>

        <section className="event-recap-actions card">
          <h3>What next?</h3>
          <p className="muted">This event result has been saved to Overall Stats, prize money and Event Cabinet where relevant. League Table and promotion/relegation are unchanged.</p>
          <div className="event-recap-button-row">
            <button className="primary-button" onClick={() => setScreen('leagueEvents')}>Back to Events</button>
            <button className="secondary-button" onClick={() => setScreen('eventDetail')}>View Event</button>
            {isWinner && <button className="secondary-button" onClick={() => setScreen('trophyRoom')}>Event Cabinet</button>}
          </div>
        </section>
      </main>
    );
  }

  function renderPostMatch() {
    if (!pendingResult) return null;

    const checkoutText = pendingResult.checkoutAttempts > 0
      ? `${pendingResult.checkoutHits}/${pendingResult.checkoutAttempts} (${formatPercent(pendingResult.checkoutHits, pendingResult.checkoutAttempts)})`
      : '0/0 (0%)';
    const avgDifference = round1(pendingResult.playerAverage - pendingResult.opponentAverage);
    const contextLabel = pendingResult.context === 'league' ? 'League Mode' : pendingResult.context === 'event' ? 'League Event' : 'Quick Match';
    const confirmNote = pendingResult.context === 'league'
      ? `Confirming will save this result and simulate the other matches in round ${pendingResult.round ?? '-'}.`
      : pendingResult.context === 'event'
        ? 'Confirming will save this event result to Overall Stats and update your tournament path.'
        : 'Confirming will save this result to Overall Stats only.';
    const performanceNote = pendingResult.playerWon
      ? 'Result is ready to save. Your stats will update after confirmation.'
      : 'Result is ready to save. Use the numbers below to see where the match was lost.';

    return (
      <main className="page">
        <section className={`card result-card post-match-card ${pendingResult.playerWon ? 'won' : 'lost'}`}>
          <div className="result-hero">
            <p className="eyebrow">Post-Match Stats</p>
            <h2>{pendingResult.playerWon ? 'Match Won' : 'Match Lost'}</h2>
            <p>{contextLabel} · {pendingResult.startingScore} · First to {pendingResult.legsToWin} legs</p>
          </div>

          <div className="scoreline-panel">
            <div className={`result-player-card ${pendingResult.playerWon ? 'winner' : ''}`}>
              <span>{pendingResult.playerName}</span>
              <strong>{pendingResult.playerLegs}</strong>
              <small>{pendingResult.playerAverage} avg</small>
            </div>
            <div className="score-divider">vs</div>
            <div className={`result-player-card ${!pendingResult.playerWon ? 'winner' : ''}`}>
              <span>{pendingResult.opponentName}</span>
              <strong>{pendingResult.opponentLegs}</strong>
              <small>{pendingResult.opponentAverage} avg</small>
            </div>
          </div>

          <section className="match-note">
            <strong>{performanceNote}</strong>
            <span>{confirmNote}</span>
          </section>

          <div className="highlight-grid">
            <div className="highlight-stat">
              <span>Average difference</span>
              <strong>{avgDifference > 0 ? `+${avgDifference}` : avgDifference}</strong>
            </div>
            <div className="highlight-stat">
              <span>Checkout</span>
              <strong>{checkoutText}</strong>
            </div>
            <div className="highlight-stat">
              <span>Highest score</span>
              <strong>{pendingResult.highestScore}</strong>
            </div>
          </div>

          <div className="stat-grid post-stat-grid">
            <Stat label="Player avg" value={pendingResult.playerAverage} />
            <Stat label="Opponent avg" value={pendingResult.opponentAverage} />
            <Stat label="Darts thrown" value={pendingResult.dartsThrown} />
            <Stat label="Scored total" value={pendingResult.scoredTotal} />
            <Stat label="Highest checkout" value={pendingResult.highestCheckout} />
            <Stat label="180s" value={pendingResult.total180s} />
            <Stat label="Legs won" value={pendingResult.playerLegs} />
            <Stat label="Legs lost" value={pendingResult.opponentLegs} />
            <Stat label="Context" value={contextLabel} />
            <Stat label="Format" value={`${pendingResult.startingScore} · FT${pendingResult.legsToWin}`} />
          </div>

          <button className="primary-button full" onClick={confirmPostMatchResult}>Confirm Result</button>
        </section>
      </main>
    );
  }

  function renderSeasonSummary() {
    if (!gameState.profile) return null;
    const position = getPlayerPosition(gameState.table);
    const playerRow = gameState.table.find((row) => row.id === PLAYER_ID);
    const prize = getLeaguePrize(gameState.currentLeagueIndex, position);
    const promoted = position <= 2 && gameState.currentLeagueIndex < LEAGUES.length - 1;
    const eliteFinish = position <= 2 && gameState.currentLeagueIndex === LEAGUES.length - 1;
    const relegated = position >= 9 && gameState.currentLeagueIndex > 0;
    const bottomSafe = position >= 9 && gameState.currentLeagueIndex === 0;
    const champion = position === 1;
    const movementClass = promoted || eliteFinish || champion ? 'promoted' : relegated ? 'relegated' : bottomSafe ? 'warning' : 'safe';
    const nextLeagueIndex = promoted ? gameState.currentLeagueIndex + 1 : relegated ? gameState.currentLeagueIndex - 1 : gameState.currentLeagueIndex;
    const nextLeague = LEAGUES[nextLeagueIndex] || currentLeague;
    const playerWins = playerRow?.wins || 0;
    const playerLosses = playerRow?.losses || 0;
    const playerPoints = playerRow?.points || 0;
    const playerLegDiff = (playerRow?.legsFor || 0) - (playerRow?.legsAgainst || 0);
    const seasonWinRate = Math.round((playerWins / Math.max(1, playerWins + playerLosses)) * 100);
    const placeText = `${position}${position === 1 ? 'st' : position === 2 ? 'nd' : position === 3 ? 'rd' : 'th'}`;
    const newTotalPrize = gameState.overallStats.prizeMoney + prize;
    const topFive = sortedTable.slice(0, 5);

    const outcomeTitle = promoted
      ? 'PROMOTED'
      : relegated
        ? 'RELEGATED'
        : eliteFinish
          ? 'ELITE FINISH'
          : champion
            ? 'LEAGUE CHAMPION'
            : bottomSafe
              ? 'REBUILD SEASON'
              : 'SEASON COMPLETE';

    const outcomeText = promoted
      ? `You finished ${placeText} and move up to ${nextLeague.name}.`
      : relegated
        ? `You finished ${placeText} and move down to ${nextLeague.name}.`
        : eliteFinish
          ? `You finished ${placeText} in the top league and stay among the best.`
          : champion
            ? `You finished 1st in ${currentLeague.name} and defend your league next season.`
            : bottomSafe
              ? `You finished ${placeText}, but there is no lower league. You stay in ${currentLeague.name}.`
              : `You finished ${placeText} and stay in ${currentLeague.name}.`;

    const zoneLabel = promoted
      ? 'Promotion earned'
      : relegated
        ? 'Relegation confirmed'
        : eliteFinish || champion
          ? 'Top finish'
          : bottomSafe
            ? 'No relegation below'
            : 'League place secured';

    return (
      <main className="page league-polish-page season-polish-page">
        <button className="ghost-button" onClick={() => setScreen('league')}>← League Mode</button>

        <section className={`season-summary-panel season-summary-polished ${movementClass}`}>
          <div className="season-outcome-hero">
            <div className="season-outcome-copy">
              <p className="eyebrow">Season {gameState.seasonNumber} Complete</p>
              <h2>{outcomeTitle}</h2>
              <p>{outcomeText}</p>
              <span className={`season-outcome-pill ${movementClass}`}>{zoneLabel}</span>
            </div>

            <div className="season-rank-card">
              <span>Final position</span>
              <strong>#{position}</strong>
              <small>{currentLeague.name}</small>
            </div>
          </div>

          <div className="season-summary-metric-grid">
            <div className="season-metric-card prize">
              <span>Prize money</span>
              <strong>£{prize}</strong>
              <small>Total after claim: £{newTotalPrize}</small>
            </div>
            <div className="season-metric-card">
              <span>Record</span>
              <strong>{playerWins}-{playerLosses}</strong>
              <small>{seasonWinRate}% win rate</small>
            </div>
            <div className="season-metric-card">
              <span>Points</span>
              <strong>{playerPoints}</strong>
              <small>2 points per win</small>
            </div>
            <div className="season-metric-card">
              <span>Leg difference</span>
              <strong>{playerLegDiff >= 0 ? `+${playerLegDiff}` : playerLegDiff}</strong>
              <small>{playerRow?.legsFor || 0} for · {playerRow?.legsAgainst || 0} against</small>
            </div>
          </div>

          <div className="season-next-card">
            <div>
              <span>Next season</span>
              <strong>{nextLeague.name}</strong>
              <small>Season {gameState.seasonNumber + 1} · Table resets, career stats continue</small>
            </div>
            <span className="season-next-badge">{promoted ? 'Up' : relegated ? 'Down' : 'Stay'}</span>
          </div>

          <div className="season-mini-table-card">
            <div className="section-row-header">
              <div>
                <p className="eyebrow">Final standings</p>
                <h3>Top 5</h3>
              </div>
              <span className="round-pill">You: #{position}</span>
            </div>
            <div className="season-mini-table">
              {topFive.map((row, index) => (
                <div key={row.id} className={row.id === PLAYER_ID ? 'you' : ''}>
                  <span>#{index + 1}</span>
                  <strong>{row.name}</strong>
                  <small>{row.points} pts</small>
                </div>
              ))}
            </div>
          </div>

          <button className="primary-button full season-start-button" onClick={startNextSeason}>Claim Prize & Start Next Season</button>
        </section>
      </main>
    );
  }

  function renderQuickSetup() {
    const currentLevelInfo = gameState.profile ? getAdaptiveCurrentLevel(gameState.profile, gameState.overallStats, gameState.leagueStats, gameState.matchHistory) : null;
    const base = currentLevelInfo?.currentLevel || gameState.profile?.startingAverage || 40;
    const previewAverage = getQuickBotAverage(quickBotLevel, base);
    const startingScoreNumber = Number(quickStartingScore);
    const legsToWinNumber = Number(quickLegsToWin);
    const validStartingScore = Number.isInteger(startingScoreNumber) && startingScoreNumber >= 101 && startingScoreNumber <= 1001;
    const validLegsToWin = Number.isInteger(legsToWinNumber) && legsToWinNumber >= 1 && legsToWinNumber <= 15;
    const canStartQuickMatch = validStartingScore && validLegsToWin;
    const botDescriptions: Record<QuickBotLevel, string> = {
      Beginner: 'Very forgiving. Best for warm-ups or confidence games.',
      Easy: 'Lower pressure. Good for rhythm and steady scoring.',
      Normal: 'Balanced around your current profile level.',
      Challenging: 'A step above your level without feeling unfair.',
      Hard: 'Sharper scoring and stronger finishing pressure.',
      Pro: 'High pressure. Strong scoring and clinical finishing.',
    };

    return (
      <main className="page quick-setup-page">
        <button className="ghost-button" onClick={() => setScreen('main')}>← Main Menu</button>

        <section className="quick-hero-card">
          <div>
            <p className="eyebrow">Quick Match</p>
            <h2>Build your match</h2>
            <p>Choose the format, pick a bot difficulty and start a clean 501-style match without affecting League Mode.</p>
          </div>
          <div className="quick-hero-preview">
            <span>Format</span>
            <strong>{quickStartingScore || '501'}</strong>
            <small>First to {quickLegsToWin || '3'} legs</small>
          </div>
        </section>

        <section className="quick-card">
          <div className="section-row-header compact">
            <div>
              <p className="eyebrow">Match format</p>
              <h3>Score & legs</h3>
            </div>
            <span className={canStartQuickMatch ? 'round-pill green' : 'round-pill warning'}>
              {canStartQuickMatch ? 'Ready' : 'Check setup'}
            </span>
          </div>

          <div className="quick-format-grid">
            <div className="quick-control-card">
              <label className="field-label">Starting points</label>
              <div className="quick-value-row">
                {[301, 501, 701].map((score) => (
                  <button
                    key={score}
                    type="button"
                    className={Number(quickStartingScore) === score ? 'quick-chip active' : 'quick-chip'}
                    onClick={() => setQuickStartingScore(String(score))}
                  >
                    {score}
                  </button>
                ))}
              </div>
              <input
                className="input quick-number-input"
                type="number"
                min="101"
                max="1001"
                step="1"
                value={quickStartingScore}
                onChange={(event) => setQuickStartingScore(event.target.value)}
                aria-label="Quick Match starting points"
              />
              {!validStartingScore && <small className="quick-error">Use a whole number from 101 to 1001.</small>}
            </div>

            <div className="quick-control-card">
              <label className="field-label">Legs to win</label>
              <div className="quick-value-row">
                {[1, 3, 5].map((legs) => (
                  <button
                    key={legs}
                    type="button"
                    className={Number(quickLegsToWin) === legs ? 'quick-chip active' : 'quick-chip'}
                    onClick={() => setQuickLegsToWin(String(legs))}
                  >
                    FT{legs}
                  </button>
                ))}
              </div>
              <input
                className="input quick-number-input"
                type="number"
                min="1"
                max="15"
                step="1"
                value={quickLegsToWin}
                onChange={(event) => setQuickLegsToWin(event.target.value)}
                aria-label="Quick Match legs to win"
              />
              {!validLegsToWin && <small className="quick-error">Use a whole number from 1 to 15.</small>}
            </div>
          </div>
        </section>

        <section className="quick-card">
          <div className="section-row-header compact">
            <div>
              <p className="eyebrow">Opponent</p>
              <h3>Bot difficulty</h3>
              <small className="adaptive-helper-text">Scaled from current level {base} avg</small>
            </div>
            <span className="round-pill">{previewAverage} avg</span>
          </div>

          <div className="quick-bot-grid">
            {QUICK_BOT_LEVELS.map((level) => (
              <button
                key={level}
                type="button"
                className={quickBotLevel === level ? 'quick-bot-card active' : 'quick-bot-card'}
                onClick={() => setQuickBotLevel(level)}
              >
                <strong>{level}</strong>
                <span>{getQuickBotAverage(level, base)} avg</span>
                <small>{botDescriptions[level]}</small>
              </button>
            ))}
          </div>
        </section>

        <section className="quick-start-card">
          <div className="quick-summary-row">
            <div>
              <span>Match preview</span>
              <strong>{quickStartingScore || '501'} · First to {quickLegsToWin || '3'} · {quickBotLevel} Bot</strong>
              <small>Quick Match updates Overall Stats only.</small>
            </div>
            <div className="quick-badge-score">
              <span>BOT AVG</span>
              <strong>{previewAverage}</strong>
            </div>
          </div>
          <button className="primary-button full quick-start-button" onClick={startQuickMatch} disabled={!canStartQuickMatch}>Start Quick Match</button>
        </section>
      </main>
    );
  }

  function renderTrophyRoom() {
    const completedSeasons = gameState.seasonHistory;
    const podiumFinishes = [...completedSeasons]
      .filter((season) => season.position >= 1 && season.position <= 3)
      .sort((a, b) => b.seasonNumber - a.seasonNumber);
    const eventCupWins = [...gameState.eventHistory]
      .filter((event) => event.placement === 'Winner')
      .sort((a, b) => b.seasonNumber - a.seasonNumber);

    const goldTrophies = podiumFinishes.filter((season) => season.position === 1);
    const silverTrophies = podiumFinishes.filter((season) => season.position === 2);
    const bronzeTrophies = podiumFinishes.filter((season) => season.position === 3);

    function getLeagueTrophyMeta(leagueName: string) {
      switch (leagueName) {
        case 'Pub League':
          return { trophyName: 'Pub Cup', badge: '🍺', leagueClass: 'league-pub' };
        case 'Town League':
          return { trophyName: 'Town Trophy', badge: '🏘️', leagueClass: 'league-town' };
        case 'County League':
          return { trophyName: 'County Shield Cup', badge: '🛡️', leagueClass: 'league-county' };
        case 'National League':
          return { trophyName: 'National Star Cup', badge: '⭐', leagueClass: 'league-national' };
        case 'Elite League':
          return { trophyName: 'Elite Crown Cup', badge: '👑', leagueClass: 'league-elite' };
        default:
          return { trophyName: leagueName, badge: '🏆', leagueClass: 'league-generic' };
      }
    }

    function getPlacementMeta(position: number) {
      if (position === 1) return { title: 'League Champion', cup: '🏆', placeClass: 'place-1', label: '1st Place' };
      if (position === 2) return { title: 'League Runner-up', cup: '🏆', placeClass: 'place-2', label: '2nd Place' };
      return { title: 'League 3rd Place', cup: '🏆', placeClass: 'place-3', label: '3rd Place' };
    }

    function getEventCupMeta(event: EventHistoryItem) {
      const fieldSize = event.fieldSize || 4;
      const formatClass = fieldSize === 32 ? 'cup-major' : fieldSize === 16 ? 'cup-classic' : fieldSize === 8 ? 'cup-open' : 'cup-small';
      const cupName = fieldSize === 32
        ? 'Major Event Cup'
        : fieldSize === 16
          ? 'Classic Cup'
          : fieldSize === 8
            ? 'Open Cup'
            : 'Mini Cup';
      const icon = fieldSize === 32 ? '👑' : fieldSize === 16 ? '🏆' : fieldSize === 8 ? '🥇' : '🏅';
      return { cupName, icon, formatClass };
    }

    return (
      <main className="page wide-page trophy-room-page trophy-room-v2 trophy-room-hierarchy-page">
        <button className="ghost-button" onClick={() => setScreen('league')}>← League Mode</button>

        <section className="trophy-hero-card trophy-hero-card-v2 trophy-hierarchy-hero">
          <div>
            <p className="eyebrow">Trophy Room</p>
            <h2>League cabinet</h2>
            <p>Your league podium trophies are the main collection. Event cups are stored separately underneath as side-event wins.</p>
          </div>
          <div className="league-cabinet-hero-cups">
            <div className="hero-mini-cup gold primary-cup-stat">
              <span>🏆</span>
              <strong>{goldTrophies.length}</strong>
              <small>Wins</small>
            </div>
            <div className="hero-mini-cup silver primary-cup-stat">
              <span>🏆</span>
              <strong>{silverTrophies.length}</strong>
              <small>2nd</small>
            </div>
            <div className="hero-mini-cup bronze primary-cup-stat">
              <span>🏆</span>
              <strong>{bronzeTrophies.length}</strong>
              <small>3rd</small>
            </div>
          </div>
        </section>

        <section className="trophy-summary-grid trophy-summary-grid-v2 league-trophy-summary-grid">
          <div className="trophy-summary-card gold">
            <span>League Wins</span>
            <strong>{goldTrophies.length}</strong>
            <small>1st-place finishes</small>
          </div>
          <div className="trophy-summary-card silver">
            <span>Runner-up</span>
            <strong>{silverTrophies.length}</strong>
            <small>2nd-place finishes</small>
          </div>
          <div className="trophy-summary-card bronze-lite">
            <span>3rd Places</span>
            <strong>{bronzeTrophies.length}</strong>
            <small>Third-place finishes</small>
          </div>
          <div className="trophy-summary-card league-total-card">
            <span>League Trophies</span>
            <strong>{podiumFinishes.length}</strong>
            <small>Total podiums</small>
          </div>
        </section>

        <section className="trophy-panel trophy-panel-v2 league-cabinet-panel">
          <div className="section-row-header">
            <div>
              <p className="eyebrow">Main Cabinet</p>
              <h3>League trophies</h3>
              <span className="section-subline">Only league podium finishes go here: gold for 1st, silver for 2nd, bronze for 3rd.</span>
            </div>
            <span className="round-pill">{podiumFinishes.length}</span>
          </div>
          {podiumFinishes.length === 0 ? (
            <p className="muted no-history-note">Finish 1st, 2nd or 3rd in a league season to earn your first league trophy.</p>
          ) : (
            <div className="placement-trophy-grid placement-trophy-grid-primary">
              {podiumFinishes.map((season) => {
                const leagueMeta = getLeagueTrophyMeta(season.leagueName);
                const placementMeta = getPlacementMeta(season.position);
                return (
                  <article
                    key={`${season.seasonNumber}-${season.leagueName}-${season.position}`}
                    className={`placement-trophy-card primary-league-trophy ${placementMeta.placeClass} ${leagueMeta.leagueClass}`}
                  >
                    <div className="placement-trophy-top">
                      <span className={`placement-cup ${placementMeta.placeClass}`}>{placementMeta.cup}</span>
                      <div className="placement-meta">
                        <small>{placementMeta.label}</small>
                        <strong>{placementMeta.title}</strong>
                      </div>
                    </div>
                    <div className="placement-league-chip">
                      <span>{leagueMeta.badge}</span>
                      <b>{leagueMeta.trophyName}</b>
                    </div>
                    <div className="placement-trophy-body">
                      <h4>{season.leagueName}</h4>
                      <p>Season {season.seasonNumber}</p>
                      <div className="placement-trophy-stats">
                        <span>{season.wins}-{season.losses}</span>
                        <span>{season.points} pts</span>
                        <span>{season.legDifference >= 0 ? '+' : ''}{season.legDifference} LD</span>
                      </div>
                      <small>Prize money £{season.prizeMoney}</small>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        <section className="trophy-panel trophy-panel-v2 event-trophy-panel secondary-event-cabinet">
          <div className="section-row-header">
            <div>
              <p className="eyebrow">Side Cabinet</p>
              <h3>Event trophies</h3>
              <span className="section-subline">Event cups are extra side-event wins. They are kept separate from league podium trophies.</span>
            </div>
            <span className="round-pill muted-pill">{eventCupWins.length}</span>
          </div>
          {eventCupWins.length === 0 ? (
            <p className="muted no-history-note">Win an optional event or cup to add your first event trophy here.</p>
          ) : (
            <div className="event-cup-trophy-grid event-cup-trophy-grid-secondary">
              {eventCupWins.map((event) => {
                const cupMeta = getEventCupMeta(event);
                return (
                  <article key={event.id} className={`event-cup-trophy-card secondary-event-cup ${cupMeta.formatClass}`}>
                    <div className="event-cup-icon">{cupMeta.icon}</div>
                    <div>
                      <small>Event trophy</small>
                      <strong>{event.eventName || cupMeta.cupName}</strong>
                      <span>{cupMeta.cupName} · {event.leagueName} · Season {event.seasonNumber}</span>
                      <div className="event-cup-trophy-meta">
                        <b>{event.fieldSize || 4} players</b>
                        <b>FT{event.legsToWin || 2}</b>
                        <b>£{event.prizeWon}</b>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        <section className="trophy-panel trophy-panel-v2 trophy-recent-panel">
          <div className="section-row-header">
            <div>
              <p className="eyebrow">Recent</p>
              <h3>Latest trophies</h3>
            </div>
          </div>
          {podiumFinishes.length === 0 && eventCupWins.length === 0 ? (
            <p className="muted no-history-note">Your latest league podiums and event wins will appear here.</p>
          ) : (
            <div className="trophy-season-list compact-list">
              {podiumFinishes.slice(0, 5).map((season) => {
                const placementMeta = getPlacementMeta(season.position);
                const leagueMeta = getLeagueTrophyMeta(season.leagueName);
                return (
                  <div
                    key={`recent-${season.seasonNumber}-${season.leagueName}-${season.position}`}
                    className={`trophy-season-row compact league-recent ${placementMeta.placeClass}`}
                  >
                    <div>
                      <strong>{placementMeta.label} · {season.leagueName}</strong>
                      <span>Season {season.seasonNumber} · {leagueMeta.trophyName} · £{season.prizeMoney}</span>
                    </div>
                    <small>{placementMeta.title}</small>
                  </div>
                );
              })}
              {eventCupWins.slice(0, 3).map((event) => {
                const cupMeta = getEventCupMeta(event);
                return (
                  <div key={`recent-event-${event.id}`} className="trophy-season-row compact event-win secondary-recent-event">
                    <div>
                      <strong>{event.eventName}</strong>
                      <span>{event.leagueName} · Season {event.seasonNumber} · {cupMeta.cupName}</span>
                    </div>
                    <small>{cupMeta.cupName}</small>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>
    );
  }


  function renderMatchHistory() {
    const history = gameState.matchHistory || [];
    const recent = history.slice(0, 60);
    const leagueCount = history.filter((item) => item.context === 'league').length;
    const eventCount = history.filter((item) => item.context === 'event').length;
    const quickCount = history.filter((item) => item.context === 'quick').length;

    return (
      <main className="page wide-page match-history-page">
        <button className="ghost-button" onClick={() => setScreen('league')}>← League Mode</button>

        <section className="history-hero-card">
          <div>
            <p className="eyebrow">Match History</p>
            <h2>Recent results</h2>
            <p className="muted">Your latest League Mode, Event and Quick Match results are stored here. League tables are not changed from this page.</p>
          </div>
          <div className="history-hero-badge">
            <strong>{history.length}</strong>
            <small>Saved matches</small>
          </div>
        </section>

        <section className="history-summary-grid">
          <div><span>League</span><strong>{leagueCount}</strong></div>
          <div><span>Events</span><strong>{eventCount}</strong></div>
          <div><span>Quick</span><strong>{quickCount}</strong></div>
        </section>

        <section className="history-list-panel">
          <div className="section-row-header">
            <div>
              <p className="eyebrow">Log</p>
              <h3>Latest matches</h3>
            </div>
            <span className="round-pill">Last {recent.length}</span>
          </div>

          {recent.length === 0 ? (
            <p className="muted no-history-note">Play and confirm a match to add it to your history.</p>
          ) : (
            <div className="match-history-list">
              {recent.map((item) => {
                const date = new Date(item.createdAt);
                const dateLabel = Number.isNaN(date.getTime())
                  ? 'Saved match'
                  : date.toLocaleDateString(undefined, { day: '2-digit', month: 'short' });
                const checkoutText = item.checkoutAttempts > 0
                  ? `${item.checkoutHits}/${item.checkoutAttempts}`
                  : '-';
                return (
                  <article key={item.id} className={`history-row-card ${item.playerWon ? 'won' : 'lost'} ${item.context}`}>
                    <div className="history-row-main">
                      <span className="history-context-pill">{getMatchHistoryContextLabel(item)}</span>
                      <h4>{item.playerWon ? 'Win' : 'Loss'} vs {item.opponentName}</h4>
                      <p>{item.roundLabel || `501 · FT${item.legsToWin}`} · Season {item.seasonNumber} · {dateLabel}</p>
                    </div>
                    <div className="history-score-block">
                      <strong>{item.playerLegs}-{item.opponentLegs}</strong>
                      <small>{item.playerAverage} avg</small>
                    </div>
                    <div className="history-stat-strip">
                      <span>Opp avg <b>{item.opponentAverage}</b></span>
                      <span>High <b>{item.highestScore}</b></span>
                      <span>CO <b>{checkoutText}</b></span>
                      <span>180s <b>{item.total180s}</b></span>
                      {item.prizeMoney > 0 && <span className="money-chip">£{item.prizeMoney}</span>}
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </main>
    );
  }

  function renderStats() {
    const stats = statsTab === 'overall' ? gameState.overallStats : gameState.leagueStats;
    const average = calculateAverage(stats.scoredTotal, stats.dartsThrown);
    const winPct = formatPercent(stats.wins, stats.matches);
    const checkoutPct = formatPercent(stats.checkoutHits, stats.checkoutAttempts);
    const legDiff = stats.legsWon - stats.legsLost;
    const profile = gameState.profile;
    const targetAverage = profile?.targetAverage ?? 0;
    const startingAverage = profile?.startingAverage ?? 0;
    const averageProgress = profile && targetAverage > startingAverage
      ? clamp(((average - startingAverage) / (targetAverage - startingAverage)) * 100, 0, 100)
      : 0;
    const recentSeasons = [...gameState.seasonHistory].reverse().slice(0, 3);
    const highestLeagueName = LEAGUES[gameState.leagueStats.highestLeagueIndex]?.name || '-';
    const currentLeagueName = currentLeague?.name || '-';
    const statsTitle = statsTab === 'overall' ? 'Overall Stats' : 'League Mode Stats';
    const statsDescription = statsTab === 'overall'
      ? 'All matches combined across Quick Match and League Mode.'
      : 'Only league matches, seasons, promotion and relegation.';

    return (
      <main className="page wide-page stats-polish-page">
        <button className="ghost-button" onClick={() => setScreen('main')}>← Main Menu</button>

        <section className="stats-hero-card">
          <div>
            <p className="eyebrow">Stats</p>
            <h2>{statsTitle}</h2>
            <p className="muted">{statsDescription}</p>
          </div>
          <div className="stats-hero-badge">
            <span>{stats.matches}</span>
            <small>Matches</small>
          </div>
        </section>

        <div className="stats-tabs-shell">
          <button className={statsTab === 'overall' ? 'active' : ''} onClick={() => setStatsTab('overall')}>
            <span>Overall</span>
            <small>All match types</small>
          </button>
          <button className={statsTab === 'league' ? 'active' : ''} onClick={() => setStatsTab('league')}>
            <span>League Mode</span>
            <small>League career only</small>
          </button>
        </div>

        <section className="stats-dashboard-grid">
          <div className="stats-main-card stat-accent-red">
            <span>Win rate</span>
            <strong>{winPct}</strong>
            <small>{stats.wins} wins · {stats.losses} losses</small>
          </div>
          <div className="stats-main-card stat-accent-yellow">
            <span>Average</span>
            <strong>{average}</strong>
            <small>Best match avg {stats.bestMatchAverage}</small>
          </div>
          <div className="stats-main-card stat-accent-green">
            <span>Checkout</span>
            <strong>{checkoutPct}</strong>
            <small>{stats.checkoutHits}/{stats.checkoutAttempts} checkouts</small>
          </div>
          <div className="stats-main-card">
            <span>Prize money</span>
            <strong>£{stats.prizeMoney}</strong>
            <small>Career earnings</small>
          </div>
        </section>

        <section className="stats-section-grid">
          <div className="stats-panel performance-panel">
            <div className="stats-panel-header">
              <div>
                <p className="eyebrow">Performance</p>
                <h3>Match numbers</h3>
              </div>
              <span className={legDiff >= 0 ? 'mini-pill positive' : 'mini-pill negative'}>{legDiff >= 0 ? '+' : ''}{legDiff} leg diff</span>
            </div>
            <div className="stat-grid stats-polish-grid">
              <Stat label="Matches" value={stats.matches} />
              <Stat label="Wins" value={stats.wins} />
              <Stat label="Losses" value={stats.losses} />
              <Stat label="Legs won" value={stats.legsWon} />
              <Stat label="Legs lost" value={stats.legsLost} />
              <Stat label="180s" value={stats.total180s} />
            </div>
          </div>

          <div className="stats-panel highs-panel">
            <div className="stats-panel-header">
              <div>
                <p className="eyebrow">Highs</p>
                <h3>Best moments</h3>
              </div>
            </div>
            <div className="stats-record-list">
              <div>
                <span>Highest score</span>
                <strong>{stats.highestScore}</strong>
              </div>
              <div>
                <span>Highest checkout</span>
                <strong>{stats.highestCheckout}</strong>
              </div>
              <div>
                <span>Best match average</span>
                <strong>{stats.bestMatchAverage}</strong>
              </div>
              <div>
                <span>Total 180s</span>
                <strong>{stats.total180s}</strong>
              </div>
            </div>
          </div>
        </section>

        <section className="stats-panel stats-progress-panel">
          <div className="stats-panel-header">
            <div>
              <p className="eyebrow">Development</p>
              <h3>Target average</h3>
            </div>
            <span className="mini-pill">{profile ? `${startingAverage} → ${targetAverage}` : 'No profile'}</span>
          </div>
          <div className="target-progress-row">
            <div>
              <span>Current average</span>
              <strong>{average}</strong>
            </div>
            <div>
              <span>Target</span>
              <strong>{profile ? targetAverage : '-'}</strong>
            </div>
            <div>
              <span>Progress</span>
              <strong>{profile ? `${Math.round(averageProgress)}%` : '-'}</strong>
            </div>
          </div>
          <div className="progress-track" aria-hidden="true">
            <div style={{ width: `${averageProgress}%` }} />
          </div>
        </section>

        {statsTab === 'league' && (
          <section className="stats-section-grid league-extra-grid">
            <div className="stats-panel league-career-panel">
              <div className="stats-panel-header">
                <div>
                  <p className="eyebrow">League Career</p>
                  <h3>Season record</h3>
                </div>
              </div>
              <div className="league-career-list">
                <div><span>Current league</span><strong>{currentLeagueName}</strong></div>
                <div><span>Highest league</span><strong>{highestLeagueName}</strong></div>
                <div><span>Seasons completed</span><strong>{gameState.leagueStats.seasonsCompleted}</strong></div>
                <div><span>Promotions</span><strong>{gameState.leagueStats.promotions}</strong></div>
                <div><span>Relegations</span><strong>{gameState.leagueStats.relegations}</strong></div>
                <div><span>League titles</span><strong>{gameState.leagueStats.leagueTitles}</strong></div>
                <div><span>Best position</span><strong>{gameState.leagueStats.bestPosition ?? '-'}</strong></div>
              </div>
            </div>

            <div className="stats-panel season-history-panel">
              <div className="stats-panel-header">
                <div>
                  <p className="eyebrow">Recent Seasons</p>
                  <h3>History</h3>
                </div>
              </div>
              {recentSeasons.length === 0 ? (
                <p className="muted no-history-note">Complete your first league season to see season history here.</p>
              ) : (
                <div className="season-history-list">
                  {recentSeasons.map((season) => (
                    <div key={`${season.seasonNumber}-${season.leagueName}`} className="season-history-row">
                      <div>
                        <strong>Season {season.seasonNumber}</strong>
                        <span>{season.leagueName} · #{season.position} · {season.points} pts</span>
                      </div>
                      <small className={season.movement === 'Promoted' ? 'positive' : season.movement === 'Relegated' ? 'negative' : ''}>{season.movement}</small>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        <section className="stats-panel history-link-panel">
          <div>
            <p className="eyebrow">History</p>
            <h3>Match History</h3>
            <p className="muted">Review your latest confirmed league, event and quick match results.</p>
          </div>
          <button className="secondary-button" onClick={() => setScreen('matchHistory')}>Open Match History</button>
        </section>

        <section className="card danger-zone stats-reset-card">
          <div>
            <h3>Local data</h3>
            <p className="muted">Data is saved in this browser only.</p>
          </div>
          <button className="danger-button" onClick={resetAllData}>Reset Local Data</button>
        </section>
      </main>
    );
  }

  const appTitle = screen === 'main'
    ? 'Dart League'
    : screen === 'league' || screen === 'leagueTable' || screen === 'leagueEvents' || screen === 'eventDetail' || screen === 'eventRecap' || screen === 'trophyRoom' || screen === 'matchHistory' || screen === 'seasonSummary'
      ? 'League Mode'
      : screen === 'quickSetup'
        ? 'Quick Match'
        : screen === 'stats'
          ? 'Stats'
          : 'Match';
  const appSubtitle = gameState.profile
    ? `${gameState.profile.name} · ${currentLeague.shortName} · Season ${gameState.seasonNumber}`
    : 'Local save · Simple league career';
  const activeNav = screen === 'league' || screen === 'leagueTable' || screen === 'leagueEvents' || screen === 'eventDetail' || screen === 'eventRecap' || screen === 'trophyRoom' || screen === 'matchHistory' || screen === 'seasonSummary'
    ? 'league'
    : screen === 'quickSetup'
      ? 'quick'
      : screen === 'stats'
        ? 'stats'
        : 'main';
  const showAppChrome = screen !== 'match' && screen !== 'postMatch';

  return (
    <div className="app-background">
      <style>{styles}</style>
      <div className={screen === 'match' ? 'phone-shell phone-shell-match' : 'phone-shell'}>
        {showAppChrome && (
          <header className="app-topbar">
            <div className="app-brand-mark">D</div>
            <div className="app-title-block">
              <strong>{appTitle}</strong>
              <span>{appSubtitle}</span>
            </div>
            <div className="app-save-pill">Local</div>
          </header>
        )}

        <div className={showAppChrome ? 'app-content' : 'app-content no-chrome'}>
          {screen === 'main' && renderMainMenu()}
          {screen === 'league' && renderLeagueOverview()}
          {screen === 'leagueTable' && renderLeagueTable()}
          {screen === 'leagueEvents' && renderLeagueEvents()}
          {screen === 'eventDetail' && renderEventDetail()}
          {screen === 'eventRecap' && renderEventRecap()}
          {screen === 'match' && renderMatch()}
          {screen === 'postMatch' && renderPostMatch()}
          {screen === 'seasonSummary' && renderSeasonSummary()}
          {screen === 'quickSetup' && renderQuickSetup()}
          {screen === 'stats' && renderStats()}
          {screen === 'matchHistory' && renderMatchHistory()}
          {screen === 'trophyRoom' && renderTrophyRoom()}
        </div>

        {showAppChrome && (
          <nav className="bottom-nav" aria-label="Main navigation">
            <button className={activeNav === 'league' ? 'active' : ''} onClick={() => setScreen('league')}>
              <span>🏆</span>
              <strong>League</strong>
            </button>
            <button className={activeNav === 'quick' ? 'active' : ''} onClick={() => setScreen('quickSetup')}>
              <span>🎯</span>
              <strong>Quick</strong>
            </button>
            <button className={activeNav === 'stats' ? 'active' : ''} onClick={() => setScreen('stats')}>
              <span>📊</span>
              <strong>Stats</strong>
            </button>
          </nav>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="stat-card">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

const styles = `
  :root {
    --bg: #0d0f12;
    --bg-deep: #07090c;
    --surface: #15191e;
    --surface-2: #1a2027;
    --card: #1d232a;
    --card-light: #252c34;
    --border: #35404a;
    --border-soft: rgba(255,255,255,0.08);
    --text: #f4f7fa;
    --muted: #aab4c0;
    --soft: #747f8c;
    --red: #d83a3a;
    --red-dark: #8f2424;
    --green: #2fb36d;
    --green-dark: #1f7a4a;
    --yellow: #f2b84b;
    --orange: #e8892e;
    --shadow: 0 18px 48px rgba(0,0,0,0.34);
    --radius: 18px;
  }

  * { box-sizing: border-box; }
  html { background: var(--bg); }
  body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    -webkit-font-smoothing: antialiased;
    text-rendering: geometricPrecision;
  }
  button, input { font: inherit; }
  button { cursor: pointer; -webkit-tap-highlight-color: transparent; }
  button:disabled { cursor: not-allowed; }
  button:focus-visible, input:focus-visible { outline: 3px solid rgba(242,184,75,0.38); outline-offset: 2px; }
  button:active { transform: translateY(1px); }

  .app-shell {
    min-height: 100vh;
    background:
      radial-gradient(circle at 16% 0%, rgba(216,58,58,0.22), transparent 28%),
      radial-gradient(circle at 84% 8%, rgba(47,179,109,0.12), transparent 26%),
      linear-gradient(180deg, #111419 0%, var(--bg) 40%, var(--bg-deep) 100%);
  }

  .page { width: min(760px, 100%); margin: 0 auto; padding: 22px 16px 42px; }
  .wide-page { width: min(980px, 100%); }
  .main-page { padding-top: 42px; }

  .hero-card, .card {
    background: linear-gradient(180deg, rgba(29,35,42,0.98), rgba(21,25,30,0.98));
    border: 1px solid var(--border-soft);
    border-radius: 22px;
    padding: 20px;
    box-shadow: var(--shadow);
  }
  .hero-card { position: relative; overflow: hidden; }
  .hero-card::before {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(216,58,58,0.16), transparent 48%, rgba(242,184,75,0.08));
    pointer-events: none;
  }
  .hero-card > * { position: relative; }
  .hero-card h1, .card h2, .card h3 { margin: 0 0 8px; letter-spacing: -0.03em; }
  .hero-card h1 { font-size: clamp(2rem, 9vw, 3.2rem); line-height: 0.94; }
  .card h2 { font-size: 1.55rem; }
  .card h3 { font-size: 1.08rem; }

  .eyebrow {
    color: var(--yellow);
    text-transform: uppercase;
    letter-spacing: 0.13em;
    font-size: 0.72rem;
    font-weight: 950;
    margin: 0 0 8px;
  }
  .muted { color: var(--muted); margin: 0 0 16px; line-height: 1.45; }
  .small-note { font-size: 0.84rem; margin-top: 12px; }
  .danger-text { color: #ffb4b4 !important; }

  .menu-grid { display: grid; gap: 12px; margin-top: 18px; }
  .menu-button {
    min-height: 92px;
    border: 1px solid var(--border-soft);
    background: linear-gradient(180deg, rgba(37,44,52,0.98), rgba(21,25,30,0.98));
    color: var(--text);
    border-radius: 20px;
    padding: 18px;
    text-align: left;
    display: flex;
    flex-direction: column;
    justify-content: center;
    box-shadow: 0 12px 30px rgba(0,0,0,0.22);
  }
  .menu-button span { font-size: 1.28rem; font-weight: 950; letter-spacing: -0.02em; }
  .menu-button small { color: var(--muted); margin-top: 6px; line-height: 1.25; }
  .menu-button.primary {
    background: linear-gradient(135deg, var(--red), var(--red-dark));
    border-color: rgba(216,58,58,0.64);
  }
  .menu-button.primary small { color: rgba(255,255,255,0.84); }

  .ghost-button {
    background: transparent;
    color: var(--muted);
    border: 0;
    margin: 0 0 14px;
    padding: 8px 0;
    font-weight: 850;
  }
  .ghost-button:hover { color: var(--text); }
  .primary-button, .secondary-button, .danger-button {
    border: 0;
    border-radius: 14px;
    padding: 13px 16px;
    font-weight: 950;
    color: var(--text);
    letter-spacing: -0.01em;
  }
  .primary-button { background: linear-gradient(135deg, var(--red), var(--red-dark)); box-shadow: 0 12px 26px rgba(216,58,58,0.18); }
  .secondary-button { background: var(--card); border: 1px solid var(--border); color: var(--text); }
  .danger-button { background: linear-gradient(135deg, #9f2525, #651919); }
  .full { width: 100%; margin-top: 12px; }

  .field-label { display: block; color: var(--muted); margin: 14px 0 6px; font-weight: 850; font-size: 0.9rem; }
  .input {
    width: 100%;
    background: #0f1318;
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 14px;
    outline: none;
  }
  .input:focus { border-color: rgba(216,58,58,0.62); box-shadow: 0 0 0 3px rgba(216,58,58,0.13); }

  .league-header { display: flex; align-items: center; justify-content: space-between; gap: 18px; margin-bottom: 14px; }
  .position-pill {
    min-width: 74px;
    height: 74px;
    border-radius: 22px;
    display: grid;
    place-items: center;
    background: linear-gradient(180deg, rgba(242,184,75,0.14), rgba(242,184,75,0.04));
    border: 1px solid rgba(242,184,75,0.36);
    color: var(--yellow);
    font-size: 1.48rem;
    font-weight: 1000;
  }
  .two-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 14px; }

  .table-wrap { overflow-x: auto; border-radius: 16px; border: 1px solid var(--border-soft); background: rgba(0,0,0,0.14); }
  table { width: 100%; border-collapse: collapse; min-width: 560px; }
  th, td { padding: 12px 10px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.065); }
  th { color: var(--muted); font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.08em; }
  tbody tr:last-child td { border-bottom: 0; }
  .promotion-row { background: rgba(47,179,109,0.075); }
  .relegation-row { background: rgba(216,58,58,0.06); }
  .player-row { outline: 1px solid rgba(242,184,75,0.44); outline-offset: -1px; background: rgba(242,184,75,0.11) !important; }
  .player-row td:first-child { color: var(--yellow); font-weight: 1000; }

  .match-page { width: min(640px, 100%); margin: 0 auto; padding: 10px 10px 22px; }
  .scoreboard { display: grid; grid-template-columns: 1fr; gap: 8px; }
  .score-card { background: var(--card); border: 1px solid var(--border-soft); border-radius: 18px; padding: 12px; display: grid; grid-template-columns: 1fr auto; gap: 4px; align-items: center; }
  .score-card span { font-weight: 900; }
  .score-card strong { grid-row: span 2; font-size: 2.85rem; line-height: 1; }
  .score-card small { color: var(--muted); }
  .active-player { border-color: rgba(216,58,58,0.55); }
  .match-status { margin: 8px 0; background: rgba(255,255,255,0.06); border: 1px solid var(--border-soft); border-radius: 16px; padding: 10px; }
  .match-status p { margin: 0 0 7px; color: var(--muted); }
  .match-format { color: var(--muted) !important; font-size: 0.86rem; margin-top: -2px !important; }

  .input-shell { border-radius: 14px; background: #0c1015; border: 1px solid var(--border-soft); padding: 7px 10px; display: grid; gap: 2px; }
  .input-label { color: var(--muted); font-size: 0.72rem; font-weight: 900; text-transform: uppercase; letter-spacing: 0.08em; }
  .input-display { min-height: 36px; display: grid; place-items: center; font-size: 1.85rem; line-height: 1; font-weight: 1000; color: var(--text); }
  .input-helper { color: var(--muted); font-size: 0.76rem; text-align: center; }

  .checkout-guide { margin: 8px 0; border-radius: 16px; padding: 9px 10px; border: 1px solid var(--border-soft); display: flex; justify-content: space-between; align-items: center; gap: 10px; }
  .checkout-guide span { display: block; color: var(--muted); font-size: 0.7rem; font-weight: 850; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 3px; }
  .checkout-guide strong { display: block; font-size: 0.92rem; color: var(--text); }
  .checkout-guide small { color: var(--muted); text-align: right; max-width: 145px; line-height: 1.18; font-size: 0.72rem; }
  .checkout-guide.available { background: rgba(47,179,109,0.10); border-color: rgba(47,179,109,0.32); }
  .checkout-guide.blocked { background: rgba(116,127,140,0.08); border-color: rgba(116,127,140,0.18); }

  .keypad-card { margin: 8px 0 0; background: var(--surface); border: 1px solid var(--border-soft); border-radius: 18px; padding: 8px; box-shadow: 0 14px 32px rgba(0,0,0,0.2); }
  .quick-score-panel { margin: 0 0 8px; background: rgba(255,255,255,0.045); border: 1px solid var(--border-soft); border-radius: 15px; padding: 8px; }
  .quick-score-header, .manual-entry-header { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; margin-bottom: 6px; }
  .quick-score-header span, .manual-entry-header span { font-weight: 950; color: var(--text); font-size: 0.92rem; }
  .quick-score-header small, .manual-entry-header small { color: var(--muted); font-size: 0.68rem; }
  .manual-entry-header { margin: 2px 2px 6px; }
  .quick-score-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 5px; }
  .quick-score-grid button { min-height: 34px; border-radius: 11px; border: 1px solid rgba(242,184,75,0.28); background: rgba(242,184,75,0.10); color: #ffe2a4; font-weight: 950; font-size: 0.82rem; padding: 4px; }
  .keypad { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
  .keypad button, .keypad-actions button, .cancel { min-height: 43px; border-radius: 12px; border: 1px solid var(--border-soft); color: var(--text); font-weight: 950; font-size: 0.95rem; padding: 6px 8px; }
  .number-key { background: linear-gradient(180deg, #2a323b, #14191f); box-shadow: inset 0 1px 0 rgba(255,255,255,0.06); }
  .soft-key { background: rgba(255,255,255,0.07); color: var(--muted) !important; }
  .enter { background: linear-gradient(135deg, var(--red), var(--red-dark)); }
  .danger { background: linear-gradient(135deg, #9f2525, #651919); }
  .checkout { background: linear-gradient(135deg, var(--green), var(--green-dark)); }
  .disabled { opacity: 0.38; cursor: not-allowed; }
  .keypad-actions { display: grid; grid-template-columns: 1fr 1.25fr 1fr; gap: 6px; margin-top: 7px; }
  .cancel { width: 100%; margin-top: 7px; background: rgba(255,255,255,0.055); color: var(--muted); min-height: 38px; }

  .result-card { text-align: center; }
  .post-match-card { position: relative; overflow: hidden; }
  .post-match-card::before { content: ""; position: absolute; inset: 0; pointer-events: none; background: radial-gradient(circle at top, rgba(47,179,109,0.16), transparent 43%); opacity: 0.95; }
  .post-match-card.lost::before { background: radial-gradient(circle at top, rgba(216,58,58,0.16), transparent 43%); }
  .post-match-card > * { position: relative; }
  .result-hero { margin-bottom: 16px; }
  .result-hero h2 { font-size: 2rem; margin-bottom: 6px; }
  .result-hero p:last-child { color: var(--muted); margin: 0; }
  .scoreline-panel { display: grid; grid-template-columns: 1fr auto 1fr; align-items: stretch; gap: 10px; margin: 16px 0; }
  .result-player-card { min-height: 124px; border-radius: 20px; background: rgba(13,15,18,0.68); border: 1px solid var(--border-soft); padding: 14px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; }
  .result-player-card.winner { border-color: rgba(47,179,109,0.52); background: rgba(47,179,109,0.12); }
  .result-player-card span { color: var(--muted); font-weight: 900; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .result-player-card strong { font-size: 3rem; line-height: 1; }
  .result-player-card small { color: var(--muted); font-weight: 800; }
  .score-divider { align-self: center; color: var(--soft); font-size: 0.8rem; font-weight: 1000; text-transform: uppercase; letter-spacing: 0.08em; }
  .match-note { text-align: left; background: rgba(255,255,255,0.055); border: 1px solid var(--border-soft); border-radius: 18px; padding: 14px; margin: 14px 0; }
  .match-note strong { display: block; margin-bottom: 5px; color: var(--text); }
  .match-note span { display: block; color: var(--muted); line-height: 1.4; }
  .highlight-grid { display: grid; grid-template-columns: 1fr; gap: 10px; margin: 14px 0; }
  .highlight-stat { text-align: left; border-radius: 18px; padding: 14px; background: rgba(242,184,75,0.10); border: 1px solid rgba(242,184,75,0.24); }
  .highlight-stat span { display: block; color: #ffe2a4; font-size: 0.75rem; font-weight: 950; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 5px; }
  .highlight-stat strong { display: block; font-size: 1.42rem; }
  .post-stat-grid { margin-top: 12px; }
  .result-line { color: var(--muted); font-size: 1.05rem; margin: 0 0 16px; }

  .stat-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-top: 14px; }
  .stat-card { background: rgba(255,255,255,0.055); border: 1px solid var(--border-soft); border-radius: 16px; padding: 14px; text-align: left; min-width: 0; }
  .stat-card span { display: block; color: var(--muted); font-size: 0.78rem; margin-bottom: 6px; font-weight: 820; }
  .stat-card strong { display: block; font-size: 1.16rem; overflow-wrap: anywhere; }

  .season-position { width: 112px; height: 112px; border-radius: 30px; background: rgba(242,184,75,0.12); border: 1px solid rgba(242,184,75,0.36); display: grid; place-items: center; margin: 18px auto; font-size: 1.55rem; font-weight: 1000; color: var(--yellow); }
  .setup-grid { display: grid; grid-template-columns: 1fr; gap: 12px; }
  .preset-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 8px; }
  .preset-row button { border: 1px solid var(--border-soft); background: rgba(255,255,255,0.06); color: var(--muted); border-radius: 12px; padding: 10px; font-weight: 900; }
  .level-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin: 8px 0 14px; }
  .level-option { min-height: 72px; border: 1px solid var(--border-soft); background: rgba(255,255,255,0.06); color: var(--text); border-radius: 16px; padding: 10px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; }
  .level-option span { color: var(--muted); font-size: 0.82rem; }
  .level-option.active { background: rgba(216,58,58,0.15); border-color: rgba(216,58,58,0.55); }
  .level-option.active span { color: #ffd3d3; }
  .quick-preview { margin-top: 14px; background: rgba(242,184,75,0.08); border: 1px solid rgba(242,184,75,0.22); border-radius: 16px; padding: 14px; }
  .quick-preview span { display: block; color: #ffe2a4; font-size: 0.8rem; margin-bottom: 6px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.08em; }
  .quick-preview strong { display: block; color: var(--text); }


  .quick-setup-page { display: grid; gap: 12px; }
  .quick-hero-card {
    position: relative;
    overflow: hidden;
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 14px;
    align-items: stretch;
    background:
      radial-gradient(circle at top left, rgba(216,58,58,0.22), transparent 38%),
      linear-gradient(135deg, rgba(29,35,42,0.98), rgba(9,12,16,0.98));
    border: 1px solid var(--border-soft);
    border-radius: 26px;
    padding: 18px;
    box-shadow: 0 18px 46px rgba(0,0,0,0.30);
  }
  .quick-hero-card h2 { margin: 0 0 8px; font-size: 1.62rem; letter-spacing: -0.035em; }
  .quick-hero-card p:not(.eyebrow) { margin: 0; color: var(--muted); line-height: 1.4; }
  .quick-hero-preview {
    min-width: 112px;
    border-radius: 22px;
    background: rgba(255,255,255,0.065);
    border: 1px solid rgba(255,255,255,0.09);
    display: grid;
    place-items: center;
    text-align: center;
    padding: 14px 12px;
  }
  .quick-hero-preview span, .quick-badge-score span, .quick-summary-row span {
    color: var(--muted);
    font-size: 0.68rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.08em;
  }
  .quick-hero-preview strong { font-size: 2rem; line-height: 1; margin: 5px 0; color: var(--text); }
  .quick-hero-preview small { color: var(--muted); font-weight: 850; }
  .quick-card, .quick-start-card {
    background: linear-gradient(180deg, rgba(29,35,42,0.98), rgba(18,22,27,0.98));
    border: 1px solid var(--border-soft);
    border-radius: 24px;
    padding: 16px;
    box-shadow: 0 16px 38px rgba(0,0,0,0.24);
  }
  .section-row-header.compact { margin-bottom: 12px; }
  .quick-format-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .quick-control-card {
    background: rgba(255,255,255,0.045);
    border: 1px solid rgba(255,255,255,0.075);
    border-radius: 20px;
    padding: 12px;
  }
  .quick-control-card .field-label { margin-top: 0; color: var(--text); }
  .quick-value-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 7px; margin-bottom: 9px; }
  .quick-chip {
    border: 1px solid rgba(255,255,255,0.09);
    background: rgba(255,255,255,0.055);
    color: var(--muted);
    border-radius: 13px;
    min-height: 38px;
    font-weight: 1000;
  }
  .quick-chip.active {
    background: rgba(242,184,75,0.16);
    border-color: rgba(242,184,75,0.42);
    color: #ffe4a8;
    box-shadow: 0 8px 20px rgba(242,184,75,0.08);
  }
  .quick-number-input {
    text-align: center;
    font-weight: 1000;
    font-size: 1.1rem;
    padding: 12px;
    background: rgba(7,9,12,0.74);
  }
  .quick-error { display: block; margin-top: 7px; color: #ffb4b4; font-weight: 820; line-height: 1.25; }
  .quick-bot-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
  .quick-bot-card {
    min-height: 128px;
    border: 1px solid rgba(255,255,255,0.085);
    background: rgba(255,255,255,0.045);
    color: var(--text);
    border-radius: 20px;
    padding: 12px 10px;
    text-align: left;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 8px;
  }
  .quick-bot-card strong { font-size: 1.05rem; }
  .quick-bot-card span { color: var(--yellow); font-size: 0.9rem; font-weight: 1000; }
  .quick-bot-card small { color: var(--muted); line-height: 1.24; font-weight: 760; }
  .quick-bot-card.active {
    background: linear-gradient(180deg, rgba(216,58,58,0.18), rgba(216,58,58,0.075));
    border-color: rgba(216,58,58,0.52);
    box-shadow: 0 12px 28px rgba(216,58,58,0.10);
  }
  .quick-start-card { background: linear-gradient(135deg, rgba(242,184,75,0.13), rgba(29,35,42,0.98) 45%, rgba(13,15,18,0.98)); }
  .quick-summary-row { display: grid; grid-template-columns: 1fr auto; gap: 12px; align-items: center; }
  .quick-summary-row strong { display: block; margin: 5px 0; font-size: 1.08rem; color: var(--text); }
  .quick-summary-row small { display: block; color: var(--muted); font-weight: 800; }
  .quick-badge-score {
    width: 72px;
    height: 72px;
    border-radius: 20px;
    display: grid;
    place-items: center;
    background: rgba(7,9,12,0.70);
    border: 1px solid rgba(242,184,75,0.22);
    text-align: center;
  }
  .quick-badge-score strong { color: var(--yellow); font-size: 1.42rem; line-height: 1; }
  .quick-start-button:disabled { opacity: 0.52; filter: grayscale(0.25); box-shadow: none; }
  .tabs { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin: 14px 0; padding: 6px; background: rgba(0,0,0,0.24); border-radius: 16px; }
  .tabs button { border: 0; color: var(--muted); background: transparent; border-radius: 12px; padding: 12px; font-weight: 950; }
  .tabs button.active { background: linear-gradient(135deg, var(--red), var(--red-dark)); color: var(--text); }
  .danger-zone { margin-top: 14px; }

  .pro-match-page { width: min(560px, 100%); padding: 8px 8px 18px; }
  .pro-match-header { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 8px; background: linear-gradient(135deg, rgba(29,35,42,0.98), rgba(9,12,16,0.98)); border: 1px solid var(--border-soft); border-radius: 18px; padding: 10px 12px; box-shadow: 0 14px 28px rgba(0,0,0,0.24); }
  .pro-match-header h2 { margin: 4px 0 2px; font-size: 1.1rem; line-height: 1; }
  .pro-match-header p { margin: 0; color: var(--muted); font-size: 0.76rem; font-weight: 760; }
  .pro-live-pill { display: inline-flex; align-items: center; border-radius: 999px; padding: 4px 8px; background: rgba(216,58,58,0.16); border: 1px solid rgba(216,58,58,0.30); color: #ffd3d3; font-size: 0.62rem; font-weight: 1000; text-transform: uppercase; letter-spacing: 0.08em; }
  .pro-cancel-top { border: 1px solid var(--border-soft); background: rgba(255,255,255,0.055); color: var(--muted); border-radius: 12px; padding: 8px 10px; font-size: 0.76rem; font-weight: 900; }
  .pro-scoreboard { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .pro-player-card { min-width: 0; background: linear-gradient(180deg, rgba(37,44,52,0.98), rgba(13,15,18,0.98)); border: 1px solid var(--border-soft); border-radius: 18px; padding: 10px; box-shadow: 0 12px 28px rgba(0,0,0,0.24); }
  .pro-player-card-active { border-color: rgba(216,58,58,0.56); box-shadow: 0 0 0 1px rgba(216,58,58,0.14), 0 12px 28px rgba(0,0,0,0.24); }
  .pro-player-topline { display: flex; align-items: center; justify-content: space-between; gap: 8px; min-width: 0; }
  .pro-player-topline span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 1000; font-size: 0.84rem; }
  .pro-player-topline small { flex: 0 0 auto; color: var(--muted); font-size: 0.58rem; font-weight: 1000; letter-spacing: 0.08em; }
  .pro-player-card strong { display: block; text-align: center; font-size: clamp(3.4rem, 15vw, 5.25rem); line-height: 0.88; margin: 9px 0 8px; letter-spacing: -0.08em; }
  .pro-player-card-active strong { color: var(--text); text-shadow: 0 0 22px rgba(216,58,58,0.18); }
  .pro-player-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; }
  .pro-player-meta span { min-width: 0; text-align: center; border-radius: 999px; padding: 4px 5px; background: rgba(255,255,255,0.055); color: var(--muted); font-size: 0.64rem; font-weight: 900; }
  .pro-leg-panel { display: grid; grid-template-columns: repeat(3, 1fr); gap: 7px; margin: 8px 0; }
  .pro-leg-panel div { border-radius: 14px; background: rgba(255,255,255,0.06); border: 1px solid var(--border-soft); padding: 7px; text-align: center; }
  .pro-leg-panel span { display: block; color: var(--muted); font-size: 0.62rem; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 900; }
  .pro-leg-panel strong { display: block; font-size: 1.25rem; line-height: 1.1; margin-top: 2px; }
  .pro-require-panel { display: grid; grid-template-columns: 0.78fr 1.22fr; gap: 8px; margin-bottom: 8px; }
  .pro-require-panel > div { border-radius: 16px; border: 1px solid rgba(47,179,109,0.28); background: rgba(47,179,109,0.09); padding: 9px 10px; }
  .pro-require-panel span { display: block; color: #bff4d5; font-size: 0.64rem; font-weight: 1000; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 2px; }
  .pro-require-panel strong { display: block; font-size: 1.38rem; line-height: 1.05; }
  .pro-route-box strong { font-size: 0.94rem; line-height: 1.15; color: var(--text); }
  .pro-message-panel { display: grid; grid-template-columns: 1fr 88px; gap: 8px; align-items: stretch; margin-bottom: 8px; }
  .pro-message-panel p { margin: 0; min-height: 54px; display: flex; align-items: center; border-radius: 15px; background: rgba(255,255,255,0.055); border: 1px solid var(--border-soft); color: var(--muted); padding: 8px 10px; font-size: 0.78rem; line-height: 1.25; }
  .pro-input-preview { border-radius: 15px; background: #090d12; border: 1px solid var(--border-soft); padding: 6px; text-align: center; }
  .pro-input-preview span { display: block; color: var(--muted); font-size: 0.58rem; font-weight: 1000; text-transform: uppercase; letter-spacing: 0.08em; }
  .pro-input-preview strong { display: block; font-size: 1.35rem; line-height: 1; margin: 2px 0; }
  .pro-input-preview small { color: var(--muted); font-size: 0.62rem; font-weight: 800; }
  .pro-keypad-card { background: linear-gradient(180deg, rgba(21,25,30,0.98), rgba(9,12,16,0.99)); border: 1px solid var(--border-soft); border-radius: 19px; padding: 8px; box-shadow: 0 16px 34px rgba(0,0,0,0.28); }
  .pro-quick-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 5px; margin-bottom: 7px; }
  .pro-quick-row button { min-height: 32px; border-radius: 10px; border: 1px solid rgba(242,184,75,0.28); background: rgba(242,184,75,0.10); color: #ffe2a4; font-size: 0.78rem; font-weight: 1000; padding: 3px; }
  .pro-keypad-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
  .pro-keypad-grid button, .pro-action-grid button { min-height: 40px; border-radius: 12px; border: 1px solid var(--border-soft); color: var(--text); font-weight: 1000; font-size: 0.92rem; padding: 5px; }
  .pro-number-key { background: linear-gradient(180deg, #2f3741, #151a20); box-shadow: inset 0 1px 0 rgba(255,255,255,0.08); }
  .pro-soft-key, .pro-soft-action { background: rgba(255,255,255,0.07); color: var(--muted) !important; }
  .pro-enter-key { background: linear-gradient(135deg, var(--red), var(--red-dark)); }
  .pro-action-grid { display: grid; grid-template-columns: 1fr 1fr 1.25fr; gap: 6px; margin-top: 7px; }
  .pro-danger-action { background: linear-gradient(135deg, #9f2525, #651919); }
  .pro-checkout-action { background: linear-gradient(135deg, var(--green), var(--green-dark)); }
  .pro-action-grid .disabled, .pro-keypad-grid .disabled { opacity: 0.36; cursor: not-allowed; }

  @media (min-width: 680px) {
    .setup-grid { grid-template-columns: 1fr 1fr; }
    .scoreboard { grid-template-columns: 1fr 1fr; }
    .stat-grid { grid-template-columns: repeat(4, 1fr); }
    .highlight-grid { grid-template-columns: repeat(3, 1fr); }
  }

  @media (max-width: 380px) {
    .page { padding-left: 12px; padding-right: 12px; }
    .hero-card, .card { padding: 16px; border-radius: 20px; }
    .pro-player-card strong { font-size: clamp(3rem, 14vw, 4.8rem); }
    .pro-scoreboard, .pro-leg-panel, .pro-require-panel, .pro-message-panel { gap: 6px; }
  }

  /* v0.2.2 — Fullscreen app shell, no mobile frame */
  html, body, #root { min-height: 100%; }
  body {
    background:
      radial-gradient(circle at 10% -10%, rgba(216,58,58,0.28), transparent 32%),
      radial-gradient(circle at 100% 0%, rgba(47,179,109,0.13), transparent 30%),
      linear-gradient(180deg, #05070a 0%, #0b0e12 46%, #05070a 100%);
    overscroll-behavior-y: none;
  }

  .app-background {
    min-height: 100vh;
    min-height: 100dvh;
    display: block;
    padding: 0;
    background:
      radial-gradient(circle at 10% -10%, rgba(216,58,58,0.22), transparent 32%),
      radial-gradient(circle at 100% 0%, rgba(47,179,109,0.12), transparent 30%),
      linear-gradient(180deg, #05070a 0%, #0b0e12 46%, #05070a 100%);
  }

  .phone-shell {
    width: 100%;
    min-height: 100vh;
    min-height: 100dvh;
    margin: 0;
    background:
      radial-gradient(circle at 18% 0%, rgba(216,58,58,0.18), transparent 24%),
      radial-gradient(circle at 92% 12%, rgba(242,184,75,0.10), transparent 26%),
      linear-gradient(180deg, #11161d 0%, #0b0e12 52%, #07090c 100%);
    color: var(--text);
    position: relative;
    overflow: hidden;
    box-shadow: none;
    border: 0;
    border-radius: 0;
  }

  .phone-shell-match {
    width: 100%;
    overflow-y: auto;
  }

  .app-topbar {
    height: 74px;
    display: grid;
    grid-template-columns: 42px minmax(0, 1fr) auto;
    gap: 10px;
    align-items: center;
    padding: 14px max(16px, env(safe-area-inset-right)) 12px max(16px, env(safe-area-inset-left));
    background: rgba(7,9,12,0.76);
    border-bottom: 1px solid rgba(255,255,255,0.075);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    position: sticky;
    top: 0;
    z-index: 20;
  }

  .app-brand-mark {
    width: 42px;
    height: 42px;
    border-radius: 14px;
    display: grid;
    place-items: center;
    background: linear-gradient(145deg, var(--red), #6f1f1f);
    color: white;
    font-weight: 1000;
    font-size: 1.08rem;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.20), 0 12px 28px rgba(216,58,58,0.22);
  }

  .app-title-block { min-width: 0; }
  .app-title-block strong {
    display: block;
    font-size: 1.02rem;
    line-height: 1.1;
    letter-spacing: -0.03em;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .app-title-block span {
    display: block;
    margin-top: 3px;
    color: var(--muted);
    font-size: 0.72rem;
    font-weight: 760;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .app-save-pill {
    border: 1px solid rgba(47,179,109,0.28);
    background: rgba(47,179,109,0.10);
    color: #bff4d5;
    border-radius: 999px;
    padding: 7px 10px;
    font-size: 0.68rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.08em;
  }

  .app-content {
    height: calc(100dvh - 74px - 74px);
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    padding-bottom: 12px;
  }
  .app-content::-webkit-scrollbar { display: none; }
  .app-content.no-chrome {
    height: 100dvh;
    padding-bottom: 0;
  }
  @media (min-width: 520px) {
    .app-content { height: calc(100dvh - 74px - 74px); }
    .app-content.no-chrome { height: 100dvh; }
  }

  .bottom-nav {
    height: 74px;
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 8px;
    padding: 8px max(12px, env(safe-area-inset-right)) 12px max(12px, env(safe-area-inset-left));
    background: rgba(7,9,12,0.82);
    border-top: 1px solid rgba(255,255,255,0.075);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    position: sticky;
    bottom: 0;
    z-index: 20;
  }
  .bottom-nav button {
    border: 1px solid transparent;
    border-radius: 18px;
    background: transparent;
    color: var(--soft);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
    min-height: 52px;
    transition: transform 120ms ease, background 120ms ease, border-color 120ms ease;
  }
  .bottom-nav button:active { transform: scale(0.97); }
  .bottom-nav button span { font-size: 1.05rem; line-height: 1; }
  .bottom-nav button strong { font-size: 0.72rem; font-weight: 950; }
  .bottom-nav button.active {
    background: rgba(216,58,58,0.15);
    border-color: rgba(216,58,58,0.42);
    color: var(--text);
    box-shadow: 0 10px 24px rgba(216,58,58,0.12);
  }

  .page {
    width: min(760px, 100%);
    max-width: 100%;
    margin: 0 auto;
    padding: 16px 14px 22px;
  }
  .wide-page { width: min(980px, 100%); max-width: 100%; margin: 0 auto; }
  .main-page { width: min(520px, 100%); padding-top: 16px; }
  .ghost-button {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    min-height: 36px;
    border-radius: 999px;
    padding: 8px 12px;
    margin: 0 0 12px;
    background: rgba(255,255,255,0.055);
    border: 1px solid rgba(255,255,255,0.08);
  }
  .hero-card, .card {
    border-radius: 24px;
    box-shadow: 0 18px 46px rgba(0,0,0,0.31);
  }
  .hero-card {
    min-height: 156px;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
  }
  .hero-card h1 { font-size: clamp(2.25rem, 11vw, 3.55rem); }

  .menu-grid { gap: 10px; }
  .menu-button {
    min-height: 86px;
    border-radius: 24px;
    position: relative;
    overflow: hidden;
  }
  .menu-button::after {
    content: "›";
    position: absolute;
    right: 18px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255,255,255,0.52);
    font-size: 1.9rem;
    font-weight: 500;
  }

  .primary-button, .secondary-button, .danger-button, .preset-row button, .level-option, .tabs button, .pro-keypad-card button, .pro-cancel-top {
    touch-action: manipulation;
  }
  .primary-button:active, .secondary-button:active, .danger-button:active, .menu-button:active, .level-option:active, .preset-row button:active,
  .pro-keypad-card button:active, .pro-cancel-top:active {
    transform: scale(0.985);
  }
  .primary-button, .secondary-button, .danger-button, .menu-button, .level-option, .preset-row button, .pro-keypad-card button, .pro-cancel-top {
    transition: transform 110ms ease, filter 110ms ease, background 110ms ease, border-color 110ms ease;
  }

  .league-header {
    border-radius: 26px;
    background: linear-gradient(135deg, rgba(29,35,42,0.98), rgba(13,15,18,0.96));
  }
  .position-pill {
    border-radius: 24px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.06);
  }

  .table-wrap {
    max-height: 54dvh;
    overflow: auto;
    -webkit-overflow-scrolling: touch;
  }
  table { min-width: 520px; }
  th { position: sticky; top: 0; z-index: 1; background: rgba(13,15,18,0.96); }

  .pro-match-page {
    min-height: 100dvh;
    width: min(560px, 100%);
    margin: 0 auto;
    padding: max(8px, env(safe-area-inset-top)) 8px max(18px, env(safe-area-inset-bottom));
    background:
      radial-gradient(circle at 18% -4%, rgba(216,58,58,0.22), transparent 24%),
      radial-gradient(circle at 86% 8%, rgba(47,179,109,0.10), transparent 25%);
  }
  .pro-match-header {
    position: sticky;
    top: 8px;
    z-index: 10;
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
  }
  .pro-player-card, .pro-keypad-card, .pro-require-panel > div, .pro-leg-panel div, .pro-message-panel p, .pro-input-preview {
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.055), 0 12px 26px rgba(0,0,0,0.20);
  }
  .pro-keypad-card {
    position: sticky;
    bottom: max(8px, env(safe-area-inset-bottom));
    z-index: 9;
  }
  .pro-number-key, .pro-enter-key, .pro-soft-key, .pro-soft-action, .pro-danger-action, .pro-checkout-action {
    user-select: none;
  }

  .stat-card {
    border-radius: 18px;
    background: linear-gradient(180deg, rgba(255,255,255,0.065), rgba(255,255,255,0.035));
  }

  @media (max-width: 390px) {
    .app-topbar { grid-template-columns: 38px 1fr auto; padding-left: 12px; padding-right: 12px; }
    .app-brand-mark { width: 38px; height: 38px; border-radius: 13px; }
    .app-save-pill { display: none; }
    .page { padding-left: 12px; padding-right: 12px; }
    .bottom-nav { padding-left: 10px; padding-right: 10px; }
  }


  /* v0.2.3 — Heading Typography Pass */
  :root {
    --heading-font: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  }

  h1, h2, h3, .menu-button span, .app-title-block strong, .result-hero h2, .pro-match-header h2 {
    font-family: var(--heading-font);
    text-wrap: balance;
  }

  .hero-card h1 {
    font-size: clamp(2rem, 8.2vw, 2.85rem);
    line-height: 1.02;
    letter-spacing: -0.035em;
    font-weight: 920;
    max-width: 10ch;
  }

  .card h2,
  .result-hero h2,
  .league-header h2 {
    font-size: clamp(1.35rem, 5.8vw, 1.75rem);
    line-height: 1.08;
    letter-spacing: -0.025em;
    font-weight: 900;
    margin-bottom: 7px;
  }

  .card h3 {
    font-size: clamp(1rem, 4.2vw, 1.16rem);
    line-height: 1.18;
    letter-spacing: -0.015em;
    font-weight: 860;
    margin-bottom: 7px;
  }

  .eyebrow {
    font-size: 0.66rem;
    letter-spacing: 0.115em;
    font-weight: 900;
    margin-bottom: 7px;
  }

  .muted {
    font-size: 0.91rem;
    line-height: 1.45;
  }

  .menu-button span {
    font-size: clamp(1.08rem, 4.8vw, 1.28rem);
    line-height: 1.12;
    letter-spacing: -0.02em;
    font-weight: 900;
  }

  .menu-button small {
    font-size: 0.84rem;
    line-height: 1.28;
  }

  .app-title-block strong {
    font-size: 0.96rem;
    line-height: 1.12;
    letter-spacing: -0.018em;
    font-weight: 880;
  }

  .app-title-block span {
    font-size: 0.69rem;
    line-height: 1.18;
    font-weight: 720;
  }

  .pro-match-header h2 {
    font-size: 1rem;
    line-height: 1.08;
    letter-spacing: -0.015em;
    font-weight: 880;
    margin: 2px 0 2px;
  }

  .result-hero h2 {
    font-size: clamp(1.55rem, 7.2vw, 2.05rem);
    line-height: 1.02;
    letter-spacing: -0.035em;
  }

  .field-label,
  .quick-score-header span,
  .manual-entry-header span,
  .stat-card span,
  .pro-leg-panel span,
  .pro-require-panel span,
  .pro-input-preview span {
    letter-spacing: 0.055em;
  }

  @media (max-width: 390px) {
    .hero-card h1 { font-size: clamp(1.85rem, 10vw, 2.42rem); }
    .card h2, .result-hero h2, .league-header h2 { font-size: 1.32rem; }
    .card h3 { font-size: 1rem; }
    .muted { font-size: 0.86rem; }
  }


  /* v0.2.4 — Readability / Contrast Pass */
  :root {
    --bg: #080A0D;
    --bg-deep: #050608;
    --surface: #171D24;
    --surface-2: #202833;
    --card: #222B35;
    --card-light: #2D3744;
    --border: #52606F;
    --border-soft: rgba(255,255,255,0.18);
    --text: #FFFFFF;
    --muted: #D7DEE8;
    --soft: #B9C4D0;
    --red: #F04444;
    --red-dark: #B92D2D;
    --green: #35C979;
    --green-dark: #238B55;
    --yellow: #FFD166;
    --orange: #F59E3D;
  }

  body,
  .phone-shell,
  .app-background {
    color: var(--text);
  }

  .hero-card,
  .card,
  .menu-button,
  .score-card,
  .pro-player-card,
  .pro-keypad-card,
  .result-player-card,
  .stat-card,
  .match-note,
  .quick-preview,
  .level-option,
  .preset-row button,
  .tabs,
  .table-wrap {
    border-color: var(--border-soft);
  }

  .hero-card,
  .card {
    background: linear-gradient(180deg, rgba(34,43,53,0.98), rgba(23,29,36,0.99));
  }

  .menu-button {
    background: linear-gradient(180deg, rgba(45,55,68,0.98), rgba(28,36,45,0.98));
  }

  .menu-button.primary,
  .primary-button,
  .tabs button.active,
  .pro-enter-key,
  .enter {
    background: linear-gradient(135deg, #F04444, #B92D2D);
    color: #FFFFFF !important;
    text-shadow: 0 1px 1px rgba(0,0,0,0.22);
  }

  .secondary-button,
  .ghost-button,
  .pro-cancel-top,
  .soft-key,
  .pro-soft-key,
  .pro-soft-action,
  .cancel {
    color: var(--muted) !important;
    background: rgba(255,255,255,0.09);
    border-color: var(--border-soft);
  }

  .danger-button,
  .danger,
  .pro-danger-action {
    background: linear-gradient(135deg, #C93636, #8E2222);
    color: #FFFFFF !important;
  }

  .checkout,
  .pro-checkout-action {
    background: linear-gradient(135deg, #35C979, #238B55);
    color: #FFFFFF !important;
  }

  .muted,
  .menu-button small,
  .field-label,
  .score-card small,
  .match-status p,
  .match-format,
  .input-label,
  .input-helper,
  .checkout-guide span,
  .checkout-guide small,
  .quick-score-header small,
  .manual-entry-header small,
  .result-hero p:last-child,
  .result-player-card span,
  .result-player-card small,
  .score-divider,
  .match-note span,
  .result-line,
  .stat-card span,
  .level-option span,
  .tabs button,
  .pro-match-header p,
  .pro-player-topline small,
  .pro-player-meta span,
  .pro-leg-panel span,
  .pro-message-panel p,
  .pro-input-preview span,
  .pro-input-preview small,
  .bottom-nav button,
  .app-title-block span {
    color: var(--muted) !important;
  }

  .bottom-nav button.active,
  .bottom-nav button.active strong,
  .bottom-nav button.active span {
    color: #FFFFFF !important;
  }

  .eyebrow,
  .position-pill,
  .player-row td:first-child,
  .quick-preview span,
  .highlight-stat span,
  .quick-score-grid button,
  .pro-quick-row button {
    color: var(--yellow) !important;
  }

  .app-save-pill,
  .pro-require-panel span,
  .checkout-guide.available span {
    color: #CFFFE3 !important;
  }

  .input,
  .input-shell,
  .pro-input-preview {
    background: #10161D;
    color: #FFFFFF;
    border-color: var(--border-soft);
  }

  .input::placeholder {
    color: #AEB8C5;
  }

  th {
    color: #E3EAF3;
    background: #151B22;
  }

  td {
    color: #FFFFFF;
  }

  .promotion-row {
    background: rgba(53,201,121,0.14);
  }

  .relegation-row {
    background: rgba(240,68,68,0.13);
  }

  .player-row {
    outline: 2px solid rgba(255,209,102,0.72);
    background: rgba(255,209,102,0.17) !important;
  }

  .quick-score-grid button,
  .pro-quick-row button {
    background: rgba(255,209,102,0.16);
    border-color: rgba(255,209,102,0.48);
  }

  .number-key,
  .pro-number-key {
    background: linear-gradient(180deg, #3A4654, #202833);
    color: #FFFFFF !important;
    border-color: rgba(255,255,255,0.20);
  }

  .pro-player-card {
    background: linear-gradient(180deg, rgba(45,55,68,0.98), rgba(18,24,31,0.99));
  }

  .pro-player-card strong,
  .score-card strong,
  .input-display,
  .pro-input-preview strong,
  .pro-require-panel strong,
  .stat-card strong,
  .result-player-card strong,
  .highlight-stat strong,
  .quick-preview strong,
  .app-title-block strong,
  .menu-button span,
  h1, h2, h3 {
    color: #FFFFFF !important;
  }

  .pro-require-panel > div,
  .checkout-guide.available {
    background: rgba(53,201,121,0.15);
    border-color: rgba(53,201,121,0.42);
  }

  .checkout-guide.blocked {
    background: rgba(255,255,255,0.08);
    border-color: var(--border-soft);
  }

  .pro-message-panel p,
  .match-status,
  .quick-score-panel,
  .stat-card,
  .pro-leg-panel div,
  .result-player-card,
  .match-note {
    background: rgba(255,255,255,0.085);
  }

  .disabled,
  .pro-action-grid .disabled,
  .pro-keypad-grid .disabled {
    opacity: 0.52;
    filter: grayscale(0.25);
  }

  .disabled,
  .disabled *,
  button:disabled,
  button:disabled * {
    color: #CED7E3 !important;
  }


  /* v0.2.5 — Clean UI Polish Pass
     Goal: calmer premium sports-app look, better spacing, stronger hierarchy, less prototype feel. */
  :root {
    --bg: #06090E;
    --bg-deep: #030508;
    --surface: #0E141B;
    --surface-2: #121A23;
    --card: #151F2A;
    --card-light: #1B2835;
    --border: #263747;
    --border-soft: rgba(183, 198, 215, 0.16);
    --text: #F8FAFC;
    --muted: #B8C5D3;
    --soft: #8291A5;
    --red: #E23B3B;
    --red-dark: #98272B;
    --green: #32C979;
    --green-dark: #1F8A52;
    --yellow: #F4B94A;
    --orange: #EA8B35;
    --shadow: 0 16px 40px rgba(0,0,0,0.30);
    --shadow-soft: 0 10px 26px rgba(0,0,0,0.22);
    --radius: 22px;
  }

  body {
    background:
      radial-gradient(circle at 0% -12%, rgba(226,59,59,0.18), transparent 30%),
      radial-gradient(circle at 100% 0%, rgba(244,185,74,0.10), transparent 26%),
      linear-gradient(180deg, #06090E 0%, #080C12 42%, #030508 100%);
  }

  .app-background {
    background:
      radial-gradient(circle at 12% -8%, rgba(226,59,59,0.16), transparent 30%),
      radial-gradient(circle at 88% 0%, rgba(50,201,121,0.08), transparent 28%),
      linear-gradient(180deg, #080C12 0%, #06090E 50%, #030508 100%);
  }

  .phone-shell {
    background:
      linear-gradient(180deg, rgba(13,19,27,0.98) 0%, rgba(7,11,17,0.99) 52%, #030508 100%);
  }

  .app-topbar {
    height: 70px;
    padding-top: max(12px, env(safe-area-inset-top));
    background: rgba(6, 9, 14, 0.88);
    border-bottom: 1px solid rgba(183,198,215,0.12);
    box-shadow: 0 12px 34px rgba(0,0,0,0.18);
  }

  .app-brand-mark {
    border-radius: 15px;
    background:
      radial-gradient(circle at 50% 50%, #F8FAFC 0 10%, transparent 11% 100%),
      conic-gradient(from 45deg, #E23B3B 0 25%, #111A23 0 50%, #32C979 0 75%, #111A23 0 100%);
    color: transparent;
    box-shadow: inset 0 0 0 2px rgba(248,250,252,0.08), 0 12px 30px rgba(0,0,0,0.32);
  }

  .app-title-block strong {
    font-size: 0.98rem;
    letter-spacing: -0.015em;
  }

  .app-title-block span {
    color: var(--soft) !important;
  }

  .app-save-pill {
    background: rgba(50,201,121,0.10);
    border-color: rgba(50,201,121,0.22);
    color: #BFF5D8 !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
  }

  .app-content {
    height: calc(100dvh - 70px - 74px);
    padding-bottom: 16px;
  }

  .page {
    padding: 18px 16px 26px;
  }

  .main-page {
    padding-top: 22px;
  }

  .hero-card,
  .card {
    background:
      linear-gradient(180deg, rgba(21,31,42,0.96), rgba(12,18,25,0.98));
    border: 1px solid rgba(183,198,215,0.13);
    border-radius: 24px;
    box-shadow: var(--shadow-soft);
  }

  .hero-card {
    padding: 24px 20px 22px;
    min-height: 172px;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
  }

  .hero-card::before {
    background:
      radial-gradient(circle at 18% 0%, rgba(226,59,59,0.25), transparent 34%),
      linear-gradient(135deg, rgba(244,185,74,0.10), transparent 44%);
  }

  .hero-card::after {
    content: "";
    position: absolute;
    right: 18px;
    top: 18px;
    width: 68px;
    height: 68px;
    border-radius: 50%;
    background:
      radial-gradient(circle at 50% 50%, rgba(248,250,252,0.82) 0 7%, transparent 8% 100%),
      conic-gradient(from 45deg, rgba(226,59,59,0.92) 0 25%, rgba(21,31,42,0.96) 0 50%, rgba(50,201,121,0.9) 0 75%, rgba(21,31,42,0.96) 0 100%);
    box-shadow: inset 0 0 0 7px rgba(6,9,14,0.58), inset 0 0 0 8px rgba(248,250,252,0.08), 0 18px 38px rgba(0,0,0,0.26);
    opacity: 0.9;
  }

  .hero-card h1 {
    max-width: 12ch;
    font-size: clamp(2.05rem, 8vw, 2.9rem);
    letter-spacing: -0.045em;
  }

  .hero-card .muted {
    max-width: 32ch;
    margin-bottom: 0;
  }

  .card {
    padding: 18px;
  }

  .card h2,
  .league-header h2,
  .result-hero h2 {
    font-weight: 900;
    letter-spacing: -0.028em;
  }

  .card h3 {
    color: #F8FAFC !important;
    font-weight: 850;
  }

  .eyebrow {
    color: var(--yellow) !important;
    letter-spacing: 0.105em;
    font-size: 0.64rem;
  }

  .muted,
  .small-note,
  .field-label,
  .stat-card span,
  .menu-button small {
    color: var(--muted) !important;
  }

  .menu-grid {
    gap: 14px;
    margin-top: 16px;
  }

  .menu-button {
    min-height: 104px;
    border-radius: 24px;
    padding: 18px 54px 18px 18px;
    background:
      linear-gradient(180deg, rgba(27,40,53,0.96), rgba(15,23,31,0.98));
    border: 1px solid rgba(183,198,215,0.13);
    box-shadow: var(--shadow-soft);
    overflow: hidden;
  }

  .menu-button::before {
    content: "";
    width: 4px;
    position: absolute;
    left: 0;
    top: 18px;
    bottom: 18px;
    border-radius: 0 999px 999px 0;
    background: rgba(244,185,74,0.8);
  }

  .menu-button.primary {
    background:
      radial-gradient(circle at 0% 0%, rgba(226,59,59,0.34), transparent 34%),
      linear-gradient(180deg, rgba(36,31,35,0.98), rgba(18,23,30,0.98));
    border-color: rgba(226,59,59,0.26);
  }

  .menu-button.primary::before {
    background: var(--red);
  }

  .menu-button:nth-child(2)::before { background: var(--green); }
  .menu-button:nth-child(3)::before { background: #6FA8FF; }

  .menu-button span {
    font-size: clamp(1.12rem, 4.7vw, 1.35rem);
  }

  .menu-button small {
    max-width: 30ch;
  }

  .primary-button,
  .secondary-button,
  .danger-button,
  .preset-row button,
  .level-option,
  .tabs button {
    border-radius: 16px;
  }

  .primary-button {
    background: linear-gradient(135deg, #E84B4B, #AA2D31);
    box-shadow: 0 14px 30px rgba(226,59,59,0.18);
  }

  .secondary-button {
    background: rgba(248,250,252,0.055);
    border: 1px solid rgba(183,198,215,0.16);
    color: #F8FAFC !important;
  }

  .ghost-button {
    color: var(--soft) !important;
    background: transparent;
    border: 0;
  }

  .field-label {
    margin-top: 16px;
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.07em;
  }

  .input {
    background: rgba(3,5,8,0.42);
    border-color: rgba(183,198,215,0.16);
    border-radius: 16px;
    min-height: 48px;
  }

  .league-header {
    background:
      radial-gradient(circle at 92% 0%, rgba(244,185,74,0.13), transparent 36%),
      linear-gradient(180deg, rgba(21,31,42,0.98), rgba(12,18,25,0.98));
    align-items: stretch;
  }

  .position-pill {
    min-width: 70px;
    height: auto;
    border-radius: 20px;
    background: rgba(244,185,74,0.10);
    border-color: rgba(244,185,74,0.25);
    font-size: 1.34rem;
  }

  .two-actions {
    gap: 10px;
  }

  .table-wrap {
    border-radius: 18px;
    background: rgba(3,5,8,0.24);
    border-color: rgba(183,198,215,0.13);
  }

  th {
    background: rgba(9,14,20,0.98);
    color: #C9D4E2;
    font-size: 0.72rem;
    padding: 11px 10px;
  }

  td {
    padding: 12px 10px;
    border-bottom-color: rgba(183,198,215,0.09);
  }

  tbody tr:nth-child(even):not(.player-row):not(.promotion-row):not(.relegation-row) {
    background: rgba(248,250,252,0.025);
  }

  .promotion-row {
    background: rgba(50,201,121,0.09);
  }

  .relegation-row {
    background: rgba(226,59,59,0.08);
  }

  .player-row {
    outline: 1px solid rgba(244,185,74,0.58);
    background: rgba(244,185,74,0.13) !important;
  }

  .quick-preview,
  .match-note {
    background: rgba(248,250,252,0.055);
    border-color: rgba(183,198,215,0.13);
    border-radius: 18px;
  }

  .level-option {
    background: rgba(248,250,252,0.045);
    border-color: rgba(183,198,215,0.13);
  }

  .level-option.active {
    background: rgba(226,59,59,0.13);
    border-color: rgba(226,59,59,0.34);
  }

  .tabs {
    background: rgba(3,5,8,0.30);
    border-color: rgba(183,198,215,0.13);
    border-radius: 18px;
    padding: 5px;
  }

  .tabs button {
    min-height: 40px;
  }

  .tabs button.active {
    background: linear-gradient(135deg, #E84B4B, #AA2D31);
  }

  .stat-grid {
    gap: 10px;
  }

  .stat-card {
    border: 1px solid rgba(183,198,215,0.12);
    background: linear-gradient(180deg, rgba(27,40,53,0.74), rgba(12,18,25,0.74));
    border-radius: 18px;
    padding: 14px;
  }

  .stat-card strong {
    font-size: 1.28rem;
    letter-spacing: -0.03em;
  }

  .bottom-nav {
    height: 74px;
    background: rgba(4,7,11,0.92);
    border-top-color: rgba(183,198,215,0.12);
    box-shadow: 0 -16px 34px rgba(0,0,0,0.22);
  }

  .bottom-nav button {
    border-radius: 18px;
    color: var(--soft) !important;
  }

  .bottom-nav button.active {
    background: rgba(226,59,59,0.14);
    border-color: rgba(226,59,59,0.28);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
  }

  .pro-match-page {
    width: min(560px, 100%);
    padding: max(8px, env(safe-area-inset-top)) 10px max(16px, env(safe-area-inset-bottom));
    background:
      radial-gradient(circle at 18% -4%, rgba(226,59,59,0.17), transparent 28%),
      radial-gradient(circle at 88% 6%, rgba(244,185,74,0.08), transparent 26%),
      linear-gradient(180deg, #080C12 0%, #030508 100%);
  }

  .pro-match-header {
    border-radius: 20px;
    background: rgba(8,12,18,0.88);
    border-color: rgba(183,198,215,0.14);
    box-shadow: 0 14px 30px rgba(0,0,0,0.24);
  }

  .pro-live-pill {
    background: rgba(226,59,59,0.12);
    border-color: rgba(226,59,59,0.28);
    color: #FFD1D1 !important;
  }

  .pro-scoreboard {
    gap: 9px;
  }

  .pro-player-card {
    border-radius: 22px;
    padding: 12px;
    background:
      linear-gradient(180deg, rgba(27,40,53,0.96), rgba(9,14,20,0.98));
    border-color: rgba(183,198,215,0.13);
    box-shadow: var(--shadow-soft);
  }

  .pro-player-card-active {
    border-color: rgba(226,59,59,0.42);
    box-shadow: 0 0 0 1px rgba(226,59,59,0.10), 0 18px 34px rgba(0,0,0,0.26);
  }

  .pro-player-card-active::before {
    content: "";
    display: block;
    height: 3px;
    border-radius: 999px;
    margin-bottom: 8px;
    background: linear-gradient(90deg, var(--red), rgba(226,59,59,0.15));
  }

  .pro-player-topline span {
    font-size: 0.82rem;
  }

  .pro-player-topline small {
    color: var(--soft) !important;
  }

  .pro-player-card strong {
    font-size: clamp(3.45rem, 15.5vw, 5.35rem);
    letter-spacing: -0.075em;
    margin: 8px 0 9px;
  }

  .pro-player-meta span,
  .pro-leg-panel div,
  .pro-message-panel p,
  .pro-input-preview,
  .pro-require-panel > div {
    background: rgba(248,250,252,0.055);
    border-color: rgba(183,198,215,0.12);
  }

  .pro-leg-panel {
    gap: 8px;
  }

  .pro-leg-panel div {
    border-radius: 16px;
    padding: 8px 6px;
  }

  .pro-require-panel {
    gap: 8px;
  }

  .pro-require-panel > div {
    border-radius: 18px;
  }

  .pro-require-panel strong {
    font-size: 1.36rem;
  }

  .pro-require-panel > div:first-child {
    background: rgba(50,201,121,0.10);
    border-color: rgba(50,201,121,0.24);
  }

  .pro-route-box {
    background: rgba(244,185,74,0.08) !important;
    border-color: rgba(244,185,74,0.19) !important;
  }

  .pro-keypad-card {
    border-radius: 24px;
    padding: 10px;
    background: rgba(8,12,18,0.94);
    border-color: rgba(183,198,215,0.13);
    box-shadow: 0 -2px 34px rgba(0,0,0,0.30);
  }

  .pro-quick-row {
    gap: 6px;
    margin-bottom: 9px;
  }

  .pro-quick-row button {
    min-height: 34px;
    border-radius: 12px;
    background: rgba(244,185,74,0.10);
    border-color: rgba(244,185,74,0.24);
    color: #F7C96C !important;
  }

  .pro-keypad-grid,
  .pro-action-grid {
    gap: 7px;
  }

  .pro-keypad-grid button,
  .pro-action-grid button {
    min-height: 43px;
    border-radius: 14px;
    font-size: 0.92rem;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.055);
  }

  .pro-number-key {
    background: linear-gradient(180deg, #243241, #121A23);
    border-color: rgba(183,198,215,0.14);
  }

  .pro-soft-key,
  .pro-soft-action,
  .pro-cancel-top {
    background: rgba(248,250,252,0.06);
    border-color: rgba(183,198,215,0.13);
    color: #C7D2DF !important;
  }

  .pro-enter-key {
    background: linear-gradient(135deg, #E84B4B, #AA2D31);
  }

  .pro-danger-action {
    background: linear-gradient(135deg, #A22C31, #6E1D22);
  }

  .pro-checkout-action {
    background: linear-gradient(135deg, #32C979, #1F8A52);
  }

  .result-card {
    text-align: left;
  }

  .result-hero {
    text-align: left;
    border-radius: 22px;
    padding: 16px;
    background: rgba(248,250,252,0.045);
    border: 1px solid rgba(183,198,215,0.12);
  }

  .result-hero h2 {
    font-size: clamp(1.75rem, 8vw, 2.35rem);
  }

  .result-line {
    color: var(--muted) !important;
  }

  .score-line {
    gap: 10px;
  }

  .result-player-card {
    border-radius: 20px;
    background: rgba(248,250,252,0.055);
    border-color: rgba(183,198,215,0.12);
  }

  .result-player-card.winner {
    background: rgba(50,201,121,0.10);
    border-color: rgba(50,201,121,0.28);
  }

  .highlight-stat {
    background: rgba(244,185,74,0.075);
    border-color: rgba(244,185,74,0.18);
  }

  .season-position {
    border-radius: 22px;
    background: rgba(244,185,74,0.10);
    border: 1px solid rgba(244,185,74,0.20);
    padding: 18px;
  }

  @media (min-width: 720px) {
    .page { padding-top: 24px; }
    .menu-grid { grid-template-columns: repeat(3, 1fr); }
    .menu-button { min-height: 140px; }
  }

  @media (max-width: 390px) {
    .page { padding-left: 12px; padding-right: 12px; }
    .card { padding: 16px; }
    .hero-card { min-height: 160px; }
    .hero-card::after { width: 58px; height: 58px; }
    .pro-player-card strong { font-size: clamp(3.1rem, 14.5vw, 4.8rem); }
  }


  /* v0.2.6 — Match Screen Polish */
  .polished-match-page {
    width: min(620px, 100%);
    padding: 10px 10px max(18px, env(safe-area-inset-bottom));
  }

  .match-command-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin: 0 0 10px;
    padding: 12px 13px;
    border-radius: 22px;
    background: linear-gradient(180deg, rgba(25,31,38,0.94), rgba(10,13,17,0.96));
    border: 1px solid rgba(183,198,215,0.12);
    box-shadow: 0 14px 32px rgba(0,0,0,0.24);
  }

  .match-command-left {
    display: flex;
    align-items: center;
    gap: 11px;
    min-width: 0;
  }

  .match-context-pill {
    flex: 0 0 auto;
    display: grid;
    place-items: center;
    min-width: 52px;
    min-height: 52px;
    border-radius: 18px;
    padding: 8px;
    background: linear-gradient(145deg, rgba(216,58,58,0.95), rgba(116,31,34,0.95));
    color: white;
    font-size: 0.64rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    text-align: center;
    line-height: 1.08;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.20), 0 12px 24px rgba(216,58,58,0.18);
  }

  .match-command-left h2 {
    margin: 0;
    font-size: 1.15rem;
    line-height: 1.05;
    letter-spacing: -0.035em;
  }

  .match-command-left p {
    margin: 4px 0 0;
    color: var(--muted);
    font-size: 0.78rem;
    font-weight: 780;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 230px;
  }

  .match-exit-button {
    flex: 0 0 auto;
    border: 1px solid rgba(183,198,215,0.12);
    background: rgba(255,255,255,0.055);
    color: #dce6f2;
    border-radius: 14px;
    padding: 10px 12px;
    font-size: 0.78rem;
    font-weight: 950;
  }

  .match-stage-card {
    border-radius: 26px;
    padding: 10px;
    background:
      radial-gradient(circle at 22% 8%, rgba(216,58,58,0.18), transparent 36%),
      radial-gradient(circle at 86% 0%, rgba(242,185,74,0.10), transparent 34%),
      linear-gradient(180deg, rgba(23,29,36,0.98), rgba(8,11,15,0.99));
    border: 1px solid rgba(183,198,215,0.13);
    box-shadow: 0 20px 46px rgba(0,0,0,0.30);
  }

  .score-hero-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 58px minmax(0, 1fr);
    gap: 8px;
    align-items: stretch;
  }

  .score-hero-player {
    min-width: 0;
    border-radius: 22px;
    padding: 12px 10px 10px;
    background: linear-gradient(180deg, rgba(33,40,49,0.92), rgba(13,17,22,0.94));
    border: 1px solid rgba(183,198,215,0.12);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.05);
  }

  .score-hero-player.active {
    border-color: rgba(216,58,58,0.52);
    background: linear-gradient(180deg, rgba(47,33,36,0.96), rgba(13,17,22,0.96));
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.05), 0 0 0 1px rgba(216,58,58,0.10);
  }

  .score-hero-topline {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    min-width: 0;
  }

  .score-hero-topline span {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: #f8fbff;
    font-size: 0.82rem;
    font-weight: 1000;
    letter-spacing: -0.025em;
  }

  .score-hero-topline small {
    flex: 0 0 auto;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    color: #cbd6e4;
    font-size: 0.58rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.07em;
  }

  .throw-dot {
    width: 6px;
    height: 6px;
    border-radius: 999px;
    background: #ff6a6a;
    box-shadow: 0 0 12px rgba(255,106,106,0.72);
  }

  .score-hero-player > strong {
    display: block;
    text-align: center;
    margin: 12px 0 8px;
    font-size: clamp(3.55rem, 16vw, 5.65rem);
    line-height: 0.82;
    letter-spacing: -0.09em;
    color: #ffffff;
    text-shadow: 0 14px 28px rgba(0,0,0,0.32);
  }

  .score-hero-player.active > strong {
    text-shadow: 0 0 24px rgba(216,58,58,0.18), 0 14px 28px rgba(0,0,0,0.32);
  }

  .score-hero-meta {
    display: grid;
    grid-template-columns: 1fr;
    gap: 5px;
  }

  .score-hero-meta span {
    min-width: 0;
    border-radius: 999px;
    padding: 5px 6px;
    background: rgba(255,255,255,0.06);
    color: #d5dfeb;
    text-align: center;
    font-size: 0.64rem;
    font-weight: 900;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .score-divider {
    align-self: center;
    display: flex;
    min-height: 130px;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    border-radius: 18px;
    background: rgba(0,0,0,0.18);
    border: 1px solid rgba(183,198,215,0.10);
  }

  .score-divider span,
  .score-divider small {
    color: #96a4b6;
    font-size: 0.58rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.10em;
  }

  .score-divider strong {
    color: var(--yellow);
    font-size: 1.16rem;
    line-height: 1;
    letter-spacing: -0.04em;
  }

  .leg-dots {
    display: flex;
    justify-content: center;
    gap: 5px;
    margin-top: 9px;
  }

  .leg-dots i {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: rgba(203,214,228,0.20);
    border: 1px solid rgba(203,214,228,0.12);
  }

  .leg-dots i.filled {
    background: var(--red);
    border-color: rgba(255,255,255,0.20);
    box-shadow: 0 0 10px rgba(216,58,58,0.42);
  }

  .leg-dots i.filled.bot {
    background: #9faabc;
    box-shadow: 0 0 10px rgba(159,170,188,0.24);
  }

  .play-control-panel {
    display: grid;
    grid-template-columns: 0.75fr 1.25fr 0.92fr;
    gap: 8px;
    margin: 10px 0 8px;
  }

  .require-major,
  .route-chip,
  .visit-panel,
  .match-feedback-strip {
    border-radius: 20px;
    border: 1px solid rgba(183,198,215,0.12);
    background: rgba(248,250,252,0.055);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.045);
  }

  .require-major {
    padding: 11px 10px;
    background: rgba(47,179,109,0.08);
    border-color: rgba(47,179,109,0.18);
  }

  .require-major.available {
    background: linear-gradient(180deg, rgba(50,201,121,0.16), rgba(31,138,82,0.08));
    border-color: rgba(50,201,121,0.34);
  }

  .require-major span,
  .route-chip span,
  .visit-panel span,
  .match-feedback-strip span {
    display: block;
    color: #b6c5d7;
    font-size: 0.60rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.09em;
    margin-bottom: 3px;
  }

  .require-major strong {
    display: block;
    color: #ffffff;
    font-size: 2.02rem;
    line-height: 0.95;
    letter-spacing: -0.06em;
  }

  .require-major small {
    display: block;
    margin-top: 5px;
    color: #c6f6d8;
    font-size: 0.66rem;
    font-weight: 850;
  }

  .route-chip {
    padding: 11px 12px;
  }

  .route-chip strong {
    display: block;
    color: #ffffff;
    font-size: 0.98rem;
    line-height: 1.17;
    letter-spacing: -0.025em;
  }

  .visit-panel {
    padding: 9px 10px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 6px;
    text-align: center;
  }

  .visit-panel strong {
    display: block;
    color: #ffffff;
    font-size: 1.62rem;
    line-height: 0.95;
    letter-spacing: -0.05em;
  }

  .visit-panel small {
    color: #cbd6e4;
    font-size: 0.68rem;
    font-weight: 900;
  }

  .match-feedback-strip {
    display: grid;
    grid-template-columns: auto minmax(0, 1fr);
    gap: 9px;
    align-items: center;
    padding: 10px 12px;
    margin-bottom: 8px;
    background: rgba(0,0,0,0.18);
  }

  .match-feedback-strip span {
    margin: 0;
    color: #8795a8;
  }

  .match-feedback-strip p {
    margin: 0;
    min-width: 0;
    color: #d3deeb;
    font-size: 0.78rem;
    font-weight: 760;
    line-height: 1.24;
  }

  .polished-keypad-card {
    border-radius: 26px;
    padding: 10px;
    background: linear-gradient(180deg, rgba(22,28,35,0.98), rgba(7,10,14,0.99));
    border-color: rgba(183,198,215,0.13);
    box-shadow: 0 20px 46px rgba(0,0,0,0.32);
  }

  .keypad-section-title {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 8px;
    padding: 2px 4px 7px;
  }

  .keypad-section-title span {
    color: #f8fbff;
    font-size: 0.85rem;
    font-weight: 1000;
    letter-spacing: -0.02em;
  }

  .keypad-section-title small {
    color: #8f9daf;
    font-size: 0.66rem;
    font-weight: 820;
  }

  .manual-title {
    padding-top: 9px;
  }

  .polished-quick-row {
    gap: 6px;
    margin-bottom: 0;
  }

  .polished-quick-row button {
    min-height: 38px;
    border-radius: 14px;
    background: linear-gradient(180deg, rgba(244,185,74,0.18), rgba(166,116,31,0.10));
    border-color: rgba(244,185,74,0.22);
    color: #ffe3a6;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.06);
  }

  .polished-number-grid {
    gap: 7px;
  }

  .polished-number-grid button,
  .polished-action-grid button {
    min-height: 44px;
    border-radius: 15px;
    font-size: 0.96rem;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.055);
  }

  .polished-number-grid .pro-number-key {
    background: linear-gradient(180deg, #303944, #151b22);
  }

  .polished-action-grid {
    grid-template-columns: 0.95fr 0.95fr 1.35fr;
    gap: 7px;
    margin-top: 8px;
  }

  .polished-action-grid .pro-checkout-action {
    font-size: 1rem;
  }

  @media (max-width: 430px) {
    .polished-match-page { padding-left: 8px; padding-right: 8px; }
    .score-hero-row { grid-template-columns: minmax(0, 1fr) 46px minmax(0, 1fr); gap: 6px; }
    .score-divider { min-height: 118px; border-radius: 16px; }
    .score-hero-player { border-radius: 20px; padding: 10px 8px 9px; }
    .score-hero-player > strong { font-size: clamp(3.15rem, 15vw, 4.9rem); }
    .score-hero-topline span { font-size: 0.76rem; }
    .score-hero-topline small { font-size: 0.53rem; }
    .play-control-panel { grid-template-columns: 0.82fr 1.18fr; }
    .visit-panel { grid-column: 1 / -1; flex-direction: row; align-items: center; text-align: left; }
    .visit-panel > div { flex: 1; }
    .visit-panel strong { font-size: 1.38rem; }
    .polished-quick-row button { min-height: 34px; font-size: 0.76rem; }
    .polished-number-grid button,
    .polished-action-grid button { min-height: 41px; }
  }

  @media (max-width: 350px) {
    .score-hero-row { grid-template-columns: 1fr; }
    .score-divider { min-height: auto; flex-direction: row; padding: 8px; }
    .play-control-panel { grid-template-columns: 1fr; }
  }



  /* v0.2.7 — League Mode Polish */
  .league-polish-page {
    width: min(720px, 100%);
    padding-top: 14px;
  }

  .league-dashboard-hero,
  .league-next-card,
  .league-progress-card,
  .league-table-shell,
  .season-summary-panel {
    border: 1px solid rgba(190,205,224,0.11);
    background:
      radial-gradient(circle at 16% 0%, rgba(216,58,58,0.14), transparent 34%),
      linear-gradient(180deg, rgba(23,30,38,0.98), rgba(10,13,18,0.98));
    border-radius: 26px;
    box-shadow: 0 20px 48px rgba(0,0,0,0.28);
  }

  .league-dashboard-hero {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 14px;
    align-items: stretch;
    padding: 18px;
    overflow: hidden;
    position: relative;
  }

  .league-dashboard-hero::after {
    content: "";
    position: absolute;
    right: -42px;
    top: -48px;
    width: 142px;
    height: 142px;
    border-radius: 999px;
    border: 1px solid rgba(242,184,75,0.10);
    background: rgba(242,184,75,0.04);
    pointer-events: none;
  }

  .league-hero-copy { position: relative; z-index: 1; min-width: 0; }
  .league-hero-copy h2 {
    margin: 0 0 6px;
    font-size: clamp(1.65rem, 7vw, 2.3rem);
    line-height: 0.98;
    letter-spacing: -0.045em;
    font-weight: 940;
  }
  .league-hero-copy p:last-child {
    margin: 0;
    color: #c4cfdd;
    font-size: 0.86rem;
    line-height: 1.35;
    font-weight: 760;
  }

  .league-zone-badge {
    width: 104px;
    min-height: 112px;
    border-radius: 24px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 12px;
    border: 1px solid rgba(255,255,255,0.10);
    background: rgba(255,255,255,0.055);
    position: relative;
    z-index: 1;
  }
  .league-zone-badge span {
    color: #c9d4e3;
    font-size: 0.66rem;
    font-weight: 950;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    line-height: 1.1;
  }
  .league-zone-badge strong {
    color: #fff;
    font-size: 2.15rem;
    line-height: 0.9;
    letter-spacing: -0.08em;
  }
  .league-zone-badge.promotion { background: rgba(47,179,109,0.13); border-color: rgba(47,179,109,0.34); }
  .league-zone-badge.safe { background: rgba(242,184,75,0.10); border-color: rgba(242,184,75,0.25); }
  .league-zone-badge.danger { background: rgba(216,58,58,0.12); border-color: rgba(216,58,58,0.32); }

  .league-focus-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 9px;
    margin: 10px 0;
  }
  .league-focus-card {
    min-height: 96px;
    border-radius: 22px;
    padding: 13px 12px;
    background: rgba(248,250,252,0.055);
    border: 1px solid rgba(190,205,224,0.10);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.045);
  }
  .league-focus-card.primary {
    background: linear-gradient(180deg, rgba(216,58,58,0.20), rgba(216,58,58,0.08));
    border-color: rgba(216,58,58,0.28);
  }
  .league-focus-card span,
  .league-progress-card span,
  .table-status-strip span,
  .season-rank-medal span {
    display: block;
    color: #aebbd0;
    font-size: 0.64rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.085em;
    margin-bottom: 6px;
  }
  .league-focus-card strong {
    display: block;
    color: #fff;
    font-size: 1.38rem;
    line-height: 1;
    letter-spacing: -0.04em;
  }
  .league-focus-card small {
    display: block;
    margin-top: 7px;
    color: #c0ccda;
    font-size: 0.72rem;
    line-height: 1.18;
    font-weight: 760;
  }

  .league-progress-card {
    padding: 14px;
    margin-bottom: 10px;
    display: grid;
    gap: 10px;
  }
  .league-progress-card strong { color: #fff; font-size: 0.98rem; }
  .progress-track {
    height: 10px;
    border-radius: 999px;
    overflow: hidden;
    background: rgba(255,255,255,0.075);
    border: 1px solid rgba(255,255,255,0.06);
  }
  .progress-track i {
    display: block;
    height: 100%;
    border-radius: 999px;
    background: linear-gradient(90deg, var(--red), var(--yellow));
    box-shadow: 0 0 18px rgba(242,184,75,0.22);
  }

  .league-next-card {
    padding: 16px;
  }
  .section-row-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 13px;
  }
  .section-row-header h3,
  .section-row-header h2 { margin: 0; }
  .round-pill {
    border-radius: 999px;
    padding: 8px 10px;
    background: rgba(242,184,75,0.10);
    border: 1px solid rgba(242,184,75,0.24);
    color: #ffe2a4;
    font-size: 0.72rem;
    font-weight: 1000;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    white-space: nowrap;
  }
  .round-pill.done {
    background: rgba(47,179,109,0.12);
    border-color: rgba(47,179,109,0.30);
    color: #baf6d2;
  }
  .next-match-versus {
    display: grid;
    grid-template-columns: minmax(0,1fr) 44px minmax(0,1fr);
    gap: 8px;
    align-items: stretch;
  }
  .next-match-versus > div {
    min-width: 0;
    border-radius: 20px;
    padding: 13px;
    background: rgba(255,255,255,0.055);
    border: 1px solid rgba(190,205,224,0.10);
  }
  .next-match-versus span {
    display: block;
    color: #aebbd0;
    font-size: 0.64rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.085em;
    margin-bottom: 7px;
  }
  .next-match-versus strong {
    display: block;
    color: #fff;
    font-size: 1.02rem;
    line-height: 1.12;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .next-match-versus small {
    display: block;
    margin-top: 6px;
    color: #c0ccda;
    font-size: 0.74rem;
    font-weight: 760;
  }
  .next-match-versus b {
    align-self: center;
    justify-self: center;
    width: 44px;
    height: 44px;
    border-radius: 16px;
    display: grid;
    place-items: center;
    background: rgba(0,0,0,0.20);
    border: 1px solid rgba(255,255,255,0.07);
    color: #8f9daf;
    font-size: 0.70rem;
    letter-spacing: 0.08em;
  }
  .league-action-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-top: 10px;
  }

  .league-table-shell {
    padding: 16px;
  }
  .table-title-row { align-items: center; }
  .mini-table-summary {
    min-width: 66px;
    border-radius: 18px;
    padding: 10px 9px;
    text-align: center;
    background: rgba(255,255,255,0.055);
    border: 1px solid rgba(190,205,224,0.10);
  }
  .mini-table-summary span { display: block; color: #fff; font-size: 1.1rem; font-weight: 1000; line-height: 1; }
  .mini-table-summary small { display: block; margin-top: 4px; color: #aebbd0; font-size: 0.62rem; font-weight: 900; text-transform: uppercase; letter-spacing: 0.08em; }
  .table-status-strip {
    display: grid;
    grid-template-columns: repeat(3, minmax(0,1fr));
    gap: 8px;
    margin: 12px 0;
  }
  .table-status-strip div {
    border-radius: 18px;
    padding: 11px;
    background: rgba(255,255,255,0.050);
    border: 1px solid rgba(190,205,224,0.095);
  }
  .table-status-strip strong { color: #fff; font-size: 1.18rem; line-height: 1; }
  .league-zone-legend {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin: 0 0 10px;
  }
  .league-zone-legend span {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    border-radius: 999px;
    padding: 7px 10px;
    background: rgba(255,255,255,0.050);
    border: 1px solid rgba(190,205,224,0.09);
    color: #c4cfdd;
    font-size: 0.72rem;
    font-weight: 850;
  }
  .legend-dot { width: 8px; height: 8px; border-radius: 999px; display: inline-block; }
  .legend-dot.promote { background: var(--green); box-shadow: 0 0 10px rgba(47,179,109,0.38); }
  .legend-dot.danger { background: var(--red); box-shadow: 0 0 10px rgba(216,58,58,0.32); }
  .polished-league-table-wrap {
    border-radius: 20px;
    border-color: rgba(190,205,224,0.10);
    background: rgba(0,0,0,0.18);
  }
  .polished-league-table { min-width: 620px; }
  .polished-league-table th {
    color: #aebbd0;
    font-size: 0.66rem;
    letter-spacing: 0.10em;
    background: rgba(8,10,13,0.98);
  }
  .polished-league-table td {
    padding-top: 10px;
    padding-bottom: 10px;
  }
  .table-rank {
    display: inline-grid;
    place-items: center;
    width: 28px;
    height: 28px;
    border-radius: 10px;
    background: rgba(255,255,255,0.055);
    color: #fff;
    font-weight: 1000;
  }
  .table-player-cell { display: grid; gap: 3px; min-width: 0; }
  .table-player-cell strong { color: #fff; font-size: 0.91rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .table-player-cell small { color: #9eacbf; font-size: 0.68rem; font-weight: 820; }
  .polished-league-table .promotion-row { background: rgba(47,179,109,0.075); }
  .polished-league-table .relegation-row { background: rgba(216,58,58,0.062); }
  .polished-league-table .player-row {
    outline: 1px solid rgba(242,184,75,0.42);
    outline-offset: -1px;
    background: rgba(242,184,75,0.105) !important;
  }
  .polished-league-table .player-row .table-rank { background: rgba(242,184,75,0.18); color: #ffe2a4; }

  .season-summary-panel {
    padding: 20px;
    text-align: center;
    overflow: hidden;
    position: relative;
  }
  .season-summary-panel::before {
    content: "";
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at top, rgba(242,184,75,0.14), transparent 46%);
    pointer-events: none;
  }
  .season-summary-panel.promoted::before { background: radial-gradient(circle at top, rgba(47,179,109,0.20), transparent 48%); }
  .season-summary-panel.relegated::before { background: radial-gradient(circle at top, rgba(216,58,58,0.18), transparent 48%); }
  .season-summary-panel > * { position: relative; }
  .season-summary-panel h2 {
    margin: 0 0 6px;
    font-size: clamp(1.75rem, 8vw, 2.5rem);
    line-height: 0.98;
    letter-spacing: -0.045em;
  }
  .season-summary-panel p:not(.eyebrow) {
    color: #c7d2e1;
    margin: 0 auto 16px;
    max-width: 34ch;
    line-height: 1.42;
    font-weight: 760;
  }
  .season-rank-medal {
    width: 138px;
    height: 138px;
    border-radius: 38px;
    margin: 16px auto;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: rgba(242,184,75,0.11);
    border: 1px solid rgba(242,184,75,0.28);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.06), 0 18px 42px rgba(0,0,0,0.20);
  }
  .season-rank-medal strong {
    color: #fff;
    font-size: 3.4rem;
    line-height: 0.92;
    letter-spacing: -0.08em;
  }
  .season-rank-medal small {
    margin-top: 6px;
    color: #ffe2a4;
    font-size: 0.78rem;
    font-weight: 900;
  }
  .season-summary-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0,1fr));
    gap: 10px;
    margin: 16px 0 2px;
  }

  @media (max-width: 430px) {
    .league-dashboard-hero { grid-template-columns: 1fr; }
    .league-zone-badge { width: 100%; min-height: auto; flex-direction: row; align-items: center; }
    .league-zone-badge strong { font-size: 1.82rem; }
    .league-focus-grid { grid-template-columns: 1fr; }
    .league-focus-card { min-height: auto; }
    .next-match-versus { grid-template-columns: 1fr; }
    .next-match-versus b { width: 100%; height: 34px; }
    .table-status-strip { grid-template-columns: 1fr; }
    .season-summary-grid { grid-template-columns: 1fr 1fr; }
  }


  /* v0.2.8 — Stats Polish */
  .stats-polish-page {
    width: min(940px, 100%);
  }

  .stats-hero-card {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 16px;
    align-items: center;
    border-radius: 28px;
    padding: 18px;
    background:
      radial-gradient(circle at 88% 0%, rgba(244,185,74,0.16), transparent 32%),
      linear-gradient(135deg, rgba(28,36,45,0.98), rgba(9,13,18,0.98));
    border: 1px solid rgba(183,198,215,0.13);
    box-shadow: 0 18px 42px rgba(0,0,0,0.28);
  }

  .stats-hero-card h2 {
    margin: 0 0 6px;
    font-size: clamp(1.65rem, 6vw, 2.35rem);
    line-height: 1;
    letter-spacing: -0.04em;
  }

  .stats-hero-card .muted {
    margin: 0;
    max-width: 34rem;
  }

  .stats-hero-badge {
    width: 88px;
    height: 88px;
    border-radius: 28px;
    display: grid;
    place-items: center;
    align-content: center;
    background: rgba(244,185,74,0.10);
    border: 1px solid rgba(244,185,74,0.22);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.08);
  }

  .stats-hero-badge span {
    color: #fff;
    font-size: 2rem;
    line-height: 0.95;
    font-weight: 1000;
    letter-spacing: -0.06em;
  }

  .stats-hero-badge small {
    color: #F7C96C;
    font-size: 0.68rem;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.08em;
  }

  .stats-tabs-shell {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin: 12px 0;
    padding: 6px;
    border-radius: 22px;
    background: rgba(5,8,12,0.62);
    border: 1px solid rgba(183,198,215,0.10);
  }

  .stats-tabs-shell button {
    border: 0;
    border-radius: 17px;
    min-height: 58px;
    padding: 10px 12px;
    color: var(--muted);
    background: transparent;
    text-align: left;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 2px;
  }

  .stats-tabs-shell button span {
    color: inherit;
    font-weight: 1000;
    font-size: 0.95rem;
  }

  .stats-tabs-shell button small {
    color: var(--soft);
    font-size: 0.72rem;
    font-weight: 760;
  }

  .stats-tabs-shell button.active {
    background: linear-gradient(135deg, rgba(232,75,75,0.94), rgba(170,45,49,0.94));
    color: #fff;
    box-shadow: 0 12px 24px rgba(226,59,59,0.16), inset 0 1px 0 rgba(255,255,255,0.08);
  }

  .stats-tabs-shell button.active small {
    color: rgba(255,255,255,0.78);
  }

  .stats-dashboard-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0,1fr));
    gap: 10px;
    margin-bottom: 12px;
  }

  .stats-main-card {
    min-height: 124px;
    border-radius: 24px;
    padding: 15px;
    background: linear-gradient(180deg, rgba(27,40,53,0.86), rgba(10,15,21,0.92));
    border: 1px solid rgba(183,198,215,0.12);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.06), 0 14px 28px rgba(0,0,0,0.18);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: hidden;
    position: relative;
  }

  .stats-main-card::before {
    content: "";
    position: absolute;
    left: 14px;
    right: 14px;
    top: 0;
    height: 3px;
    border-radius: 999px;
    background: rgba(183,198,215,0.20);
  }

  .stats-main-card.stat-accent-red::before { background: linear-gradient(90deg, #E84B4B, rgba(232,75,75,0.14)); }
  .stats-main-card.stat-accent-yellow::before { background: linear-gradient(90deg, #F7C96C, rgba(247,201,108,0.14)); }
  .stats-main-card.stat-accent-green::before { background: linear-gradient(90deg, #32C979, rgba(50,201,121,0.14)); }

  .stats-main-card span {
    color: var(--muted);
    font-size: 0.74rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 950;
  }

  .stats-main-card strong {
    margin-top: 8px;
    display: block;
    color: #fff;
    font-size: clamp(1.7rem, 7vw, 2.25rem);
    line-height: 0.96;
    letter-spacing: -0.065em;
    overflow-wrap: anywhere;
  }

  .stats-main-card small {
    margin-top: 10px;
    color: var(--soft);
    font-size: 0.77rem;
    font-weight: 760;
    line-height: 1.2;
  }

  .stats-section-grid {
    display: grid;
    grid-template-columns: 1.18fr 0.82fr;
    gap: 12px;
    margin-bottom: 12px;
  }

  .stats-panel {
    border-radius: 26px;
    padding: 16px;
    background: linear-gradient(180deg, rgba(28,36,45,0.93), rgba(11,16,22,0.96));
    border: 1px solid rgba(183,198,215,0.12);
    box-shadow: 0 14px 32px rgba(0,0,0,0.22);
  }

  .stats-panel-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 12px;
  }

  .stats-panel-header h3 {
    margin: 0;
    font-size: 1.12rem;
    line-height: 1.05;
    letter-spacing: -0.025em;
  }

  .stats-panel-header .eyebrow {
    margin-bottom: 5px;
  }

  .mini-pill {
    flex: 0 0 auto;
    border-radius: 999px;
    padding: 7px 10px;
    background: rgba(248,250,252,0.06);
    border: 1px solid rgba(183,198,215,0.12);
    color: var(--muted);
    font-size: 0.74rem;
    font-weight: 950;
    white-space: nowrap;
  }

  .mini-pill.positive, .positive { color: #99F0BD !important; }
  .mini-pill.negative, .negative { color: #FFB3B3 !important; }

  .stats-polish-grid {
    grid-template-columns: repeat(3, minmax(0,1fr));
    margin-top: 0;
  }

  .stats-polish-grid .stat-card {
    min-height: 84px;
    padding: 12px;
    border-radius: 18px;
    background: rgba(248,250,252,0.045);
    border-color: rgba(183,198,215,0.10);
  }

  .stats-polish-grid .stat-card span {
    color: var(--soft);
    font-size: 0.72rem;
  }

  .stats-polish-grid .stat-card strong {
    color: #fff;
    font-size: 1.38rem;
    line-height: 1;
  }

  .stats-record-list,
  .league-career-list {
    display: grid;
    gap: 8px;
  }

  .stats-record-list div,
  .league-career-list div {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 11px 12px;
    border-radius: 16px;
    background: rgba(248,250,252,0.045);
    border: 1px solid rgba(183,198,215,0.10);
  }

  .stats-record-list span,
  .league-career-list span {
    color: var(--muted);
    font-size: 0.82rem;
    font-weight: 800;
  }

  .stats-record-list strong,
  .league-career-list strong {
    color: #fff;
    font-size: 1rem;
    font-weight: 1000;
    text-align: right;
    overflow-wrap: anywhere;
  }

  .stats-progress-panel {
    margin-bottom: 12px;
  }

  .target-progress-row {
    display: grid;
    grid-template-columns: repeat(3, minmax(0,1fr));
    gap: 8px;
    margin-bottom: 12px;
  }

  .target-progress-row div {
    border-radius: 18px;
    padding: 12px;
    background: rgba(248,250,252,0.045);
    border: 1px solid rgba(183,198,215,0.10);
  }

  .target-progress-row span {
    display: block;
    color: var(--soft);
    font-size: 0.72rem;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.065em;
    margin-bottom: 6px;
  }

  .target-progress-row strong {
    display: block;
    color: #fff;
    font-size: 1.46rem;
    line-height: 1;
    letter-spacing: -0.05em;
  }

  .progress-track {
    height: 12px;
    border-radius: 999px;
    background: rgba(248,250,252,0.07);
    overflow: hidden;
    border: 1px solid rgba(183,198,215,0.10);
  }

  .progress-track div {
    height: 100%;
    border-radius: 999px;
    background: linear-gradient(90deg, #E84B4B, #F7C96C, #32C979);
    box-shadow: 0 0 18px rgba(50,201,121,0.16);
  }

  .league-extra-grid {
    grid-template-columns: 0.9fr 1.1fr;
  }

  .season-history-list {
    display: grid;
    gap: 8px;
  }

  .season-history-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 12px;
    border-radius: 17px;
    background: rgba(248,250,252,0.045);
    border: 1px solid rgba(183,198,215,0.10);
  }

  .season-history-row strong {
    display: block;
    color: #fff;
    font-size: 0.92rem;
    line-height: 1.15;
  }

  .season-history-row span {
    display: block;
    color: var(--muted);
    font-size: 0.78rem;
    line-height: 1.25;
    margin-top: 2px;
  }

  .season-history-row small {
    flex: 0 0 auto;
    border-radius: 999px;
    padding: 7px 9px;
    background: rgba(248,250,252,0.055);
    color: var(--muted);
    font-size: 0.72rem;
    font-weight: 1000;
  }

  .no-history-note {
    margin: 0;
    padding: 14px;
    border-radius: 18px;
    background: rgba(248,250,252,0.045);
    border: 1px solid rgba(183,198,215,0.10);
  }

  .stats-reset-card {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 14px;
    margin-top: 0;
  }

  .stats-reset-card h3,
  .stats-reset-card .muted {
    margin-bottom: 0;
  }

  .stats-reset-card .danger-button {
    flex: 0 0 auto;
  }

  @media (max-width: 760px) {
    .stats-dashboard-grid,
    .stats-section-grid,
    .league-extra-grid {
      grid-template-columns: 1fr;
    }
    .stats-dashboard-grid {
      grid-template-columns: repeat(2, minmax(0,1fr));
    }
    .stats-polish-grid {
      grid-template-columns: repeat(2, minmax(0,1fr));
    }
  }

  @media (max-width: 430px) {
    .stats-hero-card {
      grid-template-columns: 1fr;
    }
    .stats-hero-badge {
      width: 100%;
      height: 72px;
      border-radius: 22px;
    }
    .stats-dashboard-grid,
    .target-progress-row {
      grid-template-columns: 1fr;
    }
    .stats-tabs-shell button {
      min-height: 54px;
      padding: 9px 10px;
    }
    .stats-tabs-shell button small {
      display: none;
    }
    .stats-reset-card {
      align-items: stretch;
      flex-direction: column;
    }
    .stats-reset-card .danger-button {
      width: 100%;
    }
  }



  /* v0.2.9 — Main Menu Polish */
  .main-polish-page {
    padding-top: 18px;
    padding-bottom: 28px;
    display: grid;
    gap: 14px;
  }

  .home-hero-panel {
    position: relative;
    overflow: hidden;
    display: grid;
    grid-template-columns: minmax(0, 1fr) 104px;
    gap: 16px;
    align-items: stretch;
    border-radius: 30px;
    padding: 20px;
    background:
      radial-gradient(circle at 14% 0%, rgba(216,58,58,0.26), transparent 38%),
      radial-gradient(circle at 92% 18%, rgba(242,184,75,0.14), transparent 34%),
      linear-gradient(150deg, rgba(31,37,46,0.98), rgba(10,13,18,0.99));
    border: 1px solid rgba(255,255,255,0.10);
    box-shadow: 0 22px 52px rgba(0,0,0,0.32);
  }

  .home-hero-panel::after {
    content: "";
    position: absolute;
    inset: auto -40px -92px auto;
    width: 210px;
    height: 210px;
    border-radius: 50%;
    border: 30px solid rgba(255,255,255,0.035);
    pointer-events: none;
  }

  .home-hero-copy,
  .home-hero-badge {
    position: relative;
    z-index: 1;
  }

  .home-kicker-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
    margin-bottom: 18px;
  }

  .home-version-pill,
  .home-save-dot {
    display: inline-flex;
    align-items: center;
    min-height: 25px;
    border-radius: 999px;
    padding: 6px 9px;
    font-size: 0.66rem;
    font-weight: 1000;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .home-version-pill {
    color: #ffd2d2;
    background: rgba(216,58,58,0.16);
    border: 1px solid rgba(216,58,58,0.30);
  }

  .home-save-dot {
    color: #c9f5dc;
    background: rgba(47,179,109,0.12);
    border: 1px solid rgba(47,179,109,0.26);
  }

  .home-hero-copy h1 {
    margin: 0;
    font-size: clamp(2.6rem, 12vw, 4.5rem);
    line-height: 0.86;
    letter-spacing: -0.095em;
  }

  .home-hero-copy p {
    margin: 12px 0 0;
    max-width: 410px;
    color: rgba(244,247,250,0.78);
    font-size: 0.95rem;
    line-height: 1.42;
    font-weight: 650;
  }

  .home-hero-badge {
    align-self: end;
    min-height: 142px;
    border-radius: 26px;
    padding: 14px;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    background: linear-gradient(180deg, rgba(248,250,252,0.10), rgba(248,250,252,0.045));
    border: 1px solid rgba(248,250,252,0.13);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.08);
  }

  .home-hero-badge span,
  .home-hero-badge small {
    color: var(--muted);
    font-size: 0.68rem;
    font-weight: 950;
    text-transform: uppercase;
    letter-spacing: 0.08em;
  }

  .home-hero-badge strong {
    display: block;
    margin: 5px 0;
    color: var(--text);
    font-size: 1.45rem;
    line-height: 1;
    letter-spacing: -0.055em;
  }

  .home-status-card,
  .home-progress-card,
  .home-menu-card {
    border: 1px solid rgba(255,255,255,0.09);
    box-shadow: 0 14px 36px rgba(0,0,0,0.24);
  }

  .home-status-card {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 12px;
    align-items: center;
    padding: 14px;
    border-radius: 24px;
    background: linear-gradient(180deg, rgba(29,35,42,0.98), rgba(15,19,25,0.98));
  }

  .home-status-main span,
  .home-progress-header span,
  .home-mini-stats span {
    display: block;
    color: var(--muted);
    font-size: 0.68rem;
    font-weight: 1000;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .home-status-main strong {
    display: block;
    margin: 4px 0 3px;
    font-size: 1.05rem;
    line-height: 1.15;
    letter-spacing: -0.035em;
  }

  .home-status-main small {
    color: var(--muted);
    font-size: 0.78rem;
    font-weight: 700;
  }

  .home-primary-action {
    min-height: 48px;
    border: 0;
    border-radius: 16px;
    padding: 0 15px;
    color: white;
    font-size: 0.86rem;
    font-weight: 1000;
    background: linear-gradient(135deg, var(--red), var(--red-dark));
    box-shadow: 0 14px 28px rgba(216,58,58,0.22);
    white-space: nowrap;
  }

  .home-progress-card {
    padding: 15px;
    border-radius: 24px;
    background: linear-gradient(180deg, rgba(20,25,31,0.98), rgba(10,13,18,0.98));
  }

  .home-progress-header {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 14px;
    margin-bottom: 10px;
  }

  .home-progress-header strong {
    display: block;
    margin-top: 4px;
    font-size: 1rem;
    letter-spacing: -0.03em;
  }

  .home-progress-header b {
    color: var(--yellow);
    font-size: 1.28rem;
    line-height: 1;
  }

  .home-progress-track {
    height: 9px;
    border-radius: 999px;
    overflow: hidden;
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.06);
  }

  .home-progress-track i {
    display: block;
    height: 100%;
    border-radius: inherit;
    background: linear-gradient(90deg, var(--red), var(--yellow));
  }

  .home-mini-stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0,1fr));
    gap: 8px;
    margin-top: 12px;
  }

  .home-mini-stats div {
    min-width: 0;
    padding: 10px 8px;
    border-radius: 17px;
    background: rgba(255,255,255,0.055);
    border: 1px solid rgba(255,255,255,0.07);
  }

  .home-mini-stats strong {
    display: block;
    margin-top: 4px;
    font-size: 1.06rem;
    letter-spacing: -0.035em;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .home-menu-stack {
    display: grid;
    gap: 10px;
  }

  .home-menu-card {
    width: 100%;
    min-height: 82px;
    border-radius: 24px;
    padding: 14px;
    display: grid;
    grid-template-columns: 50px minmax(0, 1fr) auto;
    gap: 13px;
    align-items: center;
    text-align: left;
    color: var(--text);
    background: linear-gradient(180deg, rgba(29,35,42,0.96), rgba(13,16,21,0.98));
  }

  .home-menu-card-league {
    background:
      radial-gradient(circle at 0% 0%, rgba(216,58,58,0.18), transparent 38%),
      linear-gradient(180deg, rgba(35,41,49,0.98), rgba(13,16,21,0.98));
  }

  .home-menu-icon {
    width: 50px;
    height: 50px;
    border-radius: 18px;
    display: grid;
    place-items: center;
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.08);
    font-size: 1.24rem;
  }

  .home-menu-card span {
    display: block;
    font-size: 1.04rem;
    font-weight: 1000;
    letter-spacing: -0.035em;
  }

  .home-menu-card small {
    display: block;
    margin-top: 4px;
    color: var(--muted);
    font-size: 0.8rem;
    font-weight: 720;
    line-height: 1.25;
  }

  .home-menu-card b {
    align-self: center;
    color: #ffe2a4;
    font-size: 0.74rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    border-radius: 999px;
    padding: 7px 9px;
    background: rgba(242,184,75,0.10);
    border: 1px solid rgba(242,184,75,0.16);
  }

  .home-menu-card:active,
  .home-primary-action:active {
    transform: translateY(1px) scale(0.995);
  }

  @media (max-width: 430px) {
    .home-hero-panel {
      grid-template-columns: 1fr;
      padding: 18px;
      border-radius: 26px;
    }
    .home-hero-badge {
      min-height: auto;
      display: grid;
      grid-template-columns: auto 1fr auto;
      align-items: center;
      gap: 8px;
    }
    .home-hero-badge strong {
      margin: 0;
      font-size: 1.25rem;
    }
    .home-status-card {
      grid-template-columns: 1fr;
    }
    .home-primary-action {
      width: 100%;
    }
    .home-mini-stats {
      grid-template-columns: repeat(2, minmax(0,1fr));
    }
    .home-menu-card {
      grid-template-columns: 46px minmax(0, 1fr);
    }
    .home-menu-card b {
      grid-column: 2;
      width: max-content;
      margin-top: 2px;
    }
  }



  /* v0.3.2 — Season Summary Polish */
  .season-polish-page {
    width: min(760px, 100%);
  }

  .season-summary-polished {
    display: grid;
    gap: 14px;
    padding: 16px;
    text-align: left;
  }

  .season-outcome-hero {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 124px;
    gap: 14px;
    align-items: stretch;
  }

  .season-outcome-copy {
    min-width: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 8px;
  }

  .season-summary-polished .season-outcome-copy h2 {
    margin: 0;
    font-size: clamp(2.05rem, 9vw, 3.25rem);
    line-height: 0.92;
    letter-spacing: -0.065em;
    color: #ffffff;
  }

  .season-summary-polished .season-outcome-copy p:not(.eyebrow) {
    margin: 0;
    max-width: 42ch;
    color: #d9e3ef;
    font-size: 0.95rem;
    line-height: 1.45;
    font-weight: 720;
  }

  .season-outcome-pill {
    width: max-content;
    max-width: 100%;
    display: inline-flex;
    align-items: center;
    border-radius: 999px;
    padding: 7px 10px;
    color: #f8fbff;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.13);
    font-size: 0.72rem;
    font-weight: 950;
    letter-spacing: 0.05em;
    text-transform: uppercase;
  }

  .season-outcome-pill.promoted { background: rgba(47,179,109,0.16); border-color: rgba(47,179,109,0.34); color: #b9ffd7; }
  .season-outcome-pill.relegated { background: rgba(216,58,58,0.16); border-color: rgba(216,58,58,0.34); color: #ffd0d0; }
  .season-outcome-pill.warning { background: rgba(242,184,75,0.16); border-color: rgba(242,184,75,0.34); color: #ffe4aa; }

  .season-rank-card {
    border-radius: 26px;
    background:
      radial-gradient(circle at top, rgba(242,184,75,0.24), transparent 62%),
      rgba(255,255,255,0.055);
    border: 1px solid rgba(242,184,75,0.26);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.06), 0 18px 36px rgba(0,0,0,0.20);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    min-height: 132px;
    padding: 12px;
    text-align: center;
  }

  .season-rank-card span,
  .season-metric-card span,
  .season-next-card span:first-child {
    color: #afbed0;
    font-size: 0.7rem;
    font-weight: 900;
    letter-spacing: 0.06em;
    text-transform: uppercase;
  }

  .season-rank-card strong {
    color: #fff;
    font-size: 3.1rem;
    line-height: 0.9;
    letter-spacing: -0.09em;
  }

  .season-rank-card small {
    color: #ffe0a0;
    font-size: 0.76rem;
    font-weight: 950;
    margin-top: 6px;
  }

  .season-summary-metric-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
  }

  .season-metric-card {
    min-height: 104px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 8px;
    padding: 12px;
    border-radius: 20px;
    background: rgba(255,255,255,0.055);
    border: 1px solid rgba(190,205,224,0.12);
  }

  .season-metric-card.prize {
    background: linear-gradient(180deg, rgba(242,184,75,0.13), rgba(255,255,255,0.05));
    border-color: rgba(242,184,75,0.24);
  }

  .season-metric-card strong {
    color: #fff;
    font-size: 1.6rem;
    line-height: 1;
    letter-spacing: -0.04em;
  }

  .season-metric-card small {
    color: #aebbc9;
    font-size: 0.72rem;
    line-height: 1.25;
    font-weight: 800;
  }

  .season-next-card {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 12px;
    align-items: center;
    padding: 14px;
    border-radius: 22px;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(190,205,224,0.13);
  }

  .season-next-card strong {
    display: block;
    color: #fff;
    font-size: 1.2rem;
    margin-top: 4px;
  }

  .season-next-card small {
    color: #b6c4d4;
    display: block;
    margin-top: 3px;
    font-size: 0.78rem;
    font-weight: 760;
  }

  .season-next-badge {
    min-width: 58px;
    min-height: 58px;
    border-radius: 20px;
    display: grid;
    place-items: center;
    color: #fff !important;
    background: rgba(216,58,58,0.18);
    border: 1px solid rgba(216,58,58,0.28);
    font-weight: 1000 !important;
    letter-spacing: 0.02em !important;
    text-transform: uppercase;
  }

  .season-mini-table-card {
    padding: 14px;
    border-radius: 22px;
    background: rgba(255,255,255,0.045);
    border: 1px solid rgba(190,205,224,0.12);
  }

  .season-mini-table {
    display: grid;
    gap: 7px;
    margin-top: 12px;
  }

  .season-mini-table div {
    display: grid;
    grid-template-columns: 42px minmax(0, 1fr) auto;
    align-items: center;
    gap: 9px;
    padding: 10px 11px;
    border-radius: 15px;
    background: rgba(255,255,255,0.045);
    border: 1px solid rgba(190,205,224,0.08);
  }

  .season-mini-table div.you {
    background: rgba(242,184,75,0.13);
    border-color: rgba(242,184,75,0.28);
  }

  .season-mini-table span {
    color: #ffe0a0;
    font-size: 0.78rem;
    font-weight: 1000;
  }

  .season-mini-table strong {
    color: #fff;
    font-size: 0.88rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .season-mini-table small {
    color: #b7c4d4;
    font-size: 0.75rem;
    font-weight: 900;
  }

  .season-start-button {
    margin-top: 2px;
  }

  @media (max-width: 560px) {
    .season-outcome-hero {
      grid-template-columns: 1fr;
    }
    .season-rank-card {
      min-height: 106px;
      flex-direction: row;
      justify-content: space-between;
      text-align: left;
    }
    .season-rank-card strong {
      font-size: 2.55rem;
    }
    .season-rank-card small {
      margin-top: 0;
      max-width: 90px;
      text-align: right;
    }
    .season-summary-metric-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }

  @media (max-width: 360px) {
    .season-summary-metric-grid {
      grid-template-columns: 1fr;
    }
    .season-next-card {
      grid-template-columns: 1fr;
    }
    .season-next-badge {
      width: 100%;
      min-height: 42px;
    }
  }


  @media (max-width: 560px) {
    .quick-hero-card { grid-template-columns: 1fr; }
    .quick-hero-preview { min-width: 0; grid-template-columns: repeat(3, 1fr); text-align: left; place-items: center stretch; }
    .quick-hero-preview strong { margin: 0; text-align: center; }
    .quick-hero-preview small { text-align: right; }
    .quick-format-grid, .quick-bot-grid { grid-template-columns: 1fr; }
    .quick-bot-card { min-height: 96px; }
  }


  /* v0.3.5 — League Bot Polish */
  .opponent-scout-card {
    margin-top: 12px;
    padding: 12px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.045);
  }

  .opponent-scout-card span,
  .opponent-scout-card small { display: block; color: var(--text-soft); }
  .opponent-scout-card strong { display: block; color: var(--text); margin-top: 2px; }
  .opponent-scout-card b {
    border-radius: 999px;
    padding: 7px 10px;
    font-size: 0.74rem;
    white-space: nowrap;
    color: var(--text);
    background: rgba(255,255,255,0.08);
  }

  .opponent-scout-card.easy { border-color: rgba(47, 179, 109, 0.22); background: rgba(47, 179, 109, 0.075); }
  .opponent-scout-card.balanced { border-color: rgba(242, 184, 75, 0.22); background: rgba(242, 184, 75, 0.075); }
  .opponent-scout-card.test { border-color: rgba(232, 137, 46, 0.24); background: rgba(232, 137, 46, 0.075); }
  .opponent-scout-card.hard,
  .opponent-scout-card.elite { border-color: rgba(216, 58, 58, 0.24); background: rgba(216, 58, 58, 0.08); }

  .league-bot-status-strip { grid-template-columns: repeat(4, minmax(0, 1fr)); }
  .league-bot-status-strip strong { font-size: 0.92rem; }

  .avg-level-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 42px;
    padding: 5px 8px;
    border-radius: 999px;
    font-weight: 900;
    color: var(--text);
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.08);
  }

  .avg-level-pill.player { color: #ffe5ac; border-color: rgba(242,184,75,0.35); background: rgba(242,184,75,0.13); }
  .avg-level-pill.easy { color: #b8f7d3; border-color: rgba(47,179,109,0.22); background: rgba(47,179,109,0.1); }
  .avg-level-pill.balanced { color: #ffe5ac; border-color: rgba(242,184,75,0.2); background: rgba(242,184,75,0.09); }
  .avg-level-pill.test { color: #ffd0a3; border-color: rgba(232,137,46,0.22); background: rgba(232,137,46,0.09); }
  .avg-level-pill.hard,
  .avg-level-pill.elite { color: #ffc2c2; border-color: rgba(216,58,58,0.25); background: rgba(216,58,58,0.1); }

  @media (max-width: 420px) {
    .league-bot-status-strip { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .polished-league-table { min-width: 620px; }
  }


  /* v0.3.6 — League Table Polish */
  .league-table-polish-shell {
    overflow: hidden;
  }

  .league-table-polish-title h2 {
    margin-bottom: 4px;
  }

  .compact-muted {
    margin: 0;
    max-width: 520px;
    font-size: 0.88rem;
  }

  .season-round-pill {
    background: linear-gradient(180deg, rgba(242,184,75,0.15), rgba(242,184,75,0.06));
    border-color: rgba(242,184,75,0.22);
  }

  .league-table-player-dashboard {
    display: grid;
    grid-template-columns: 1.2fr repeat(3, 1fr);
    gap: 10px;
    margin: 16px 0 10px;
  }

  .player-position-card,
  .table-mini-metric {
    border-radius: 20px;
    padding: 14px;
    border: 1px solid rgba(190,205,224,0.10);
    background: linear-gradient(180deg, rgba(255,255,255,0.065), rgba(255,255,255,0.028));
  }

  .player-position-card {
    background: linear-gradient(135deg, rgba(242,184,75,0.16), rgba(216,58,58,0.10));
    border-color: rgba(242,184,75,0.24);
  }

  .player-position-card span,
  .table-mini-metric span,
  .race-card span {
    display: block;
    color: #aebbd0;
    font-size: 0.68rem;
    font-weight: 900;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .player-position-card strong {
    display: block;
    margin-top: 6px;
    font-size: 2.15rem;
    line-height: 0.95;
    letter-spacing: -0.06em;
    color: #fff2ca;
  }

  .player-position-card small,
  .table-mini-metric small {
    display: block;
    color: #c9d3df;
    margin-top: 6px;
    font-size: 0.78rem;
    font-weight: 750;
  }

  .table-mini-metric strong {
    display: block;
    margin-top: 7px;
    color: #ffffff;
    font-size: 1.35rem;
    line-height: 1;
    letter-spacing: -0.03em;
  }

  .table-mini-metric.prize strong { color: #ffe2a4; }
  .table-mini-metric.range strong { font-size: 1.02rem; color: #d7e2ee; }

  .league-table-race-strip {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin: 10px 0 12px;
  }

  .race-card {
    padding: 12px 13px;
    border-radius: 18px;
    border: 1px solid rgba(190,205,224,0.10);
    background: rgba(255,255,255,0.044);
  }

  .race-card strong {
    display: block;
    margin-top: 5px;
    color: #f5f8fb;
    font-size: 0.91rem;
    line-height: 1.25;
  }

  .race-card.promotion {
    background: rgba(47,179,109,0.075);
    border-color: rgba(47,179,109,0.20);
  }

  .race-card.safe {
    background: rgba(242,184,75,0.065);
    border-color: rgba(242,184,75,0.18);
  }

  .race-card.danger {
    background: rgba(216,58,58,0.075);
    border-color: rgba(216,58,58,0.20);
  }

  .polished-zone-legend {
    margin-top: 4px;
    margin-bottom: 12px;
  }

  .legend-dot.neutral { background: #8794a6; box-shadow: 0 0 10px rgba(135,148,166,0.22); }
  .legend-dot.player { background: var(--yellow); box-shadow: 0 0 10px rgba(242,184,75,0.40); }

  .league-table-card-list {
    display: grid;
    gap: 8px;
    margin: 10px 0 14px;
  }

  .league-row-card {
    display: grid;
    grid-template-columns: 54px minmax(0, 1fr) 74px;
    align-items: center;
    gap: 10px;
    padding: 10px;
    border-radius: 18px;
    border: 1px solid rgba(190,205,224,0.10);
    background: rgba(255,255,255,0.045);
  }

  .league-row-card.promotion {
    border-color: rgba(47,179,109,0.19);
    background: linear-gradient(90deg, rgba(47,179,109,0.105), rgba(255,255,255,0.035));
  }

  .league-row-card.danger {
    border-color: rgba(216,58,58,0.18);
    background: linear-gradient(90deg, rgba(216,58,58,0.092), rgba(255,255,255,0.035));
  }

  .league-row-card.is-player {
    border-color: rgba(242,184,75,0.42);
    background: linear-gradient(90deg, rgba(242,184,75,0.15), rgba(216,58,58,0.07));
    box-shadow: 0 0 0 1px rgba(242,184,75,0.16) inset;
  }

  .league-row-rank-block {
    width: 48px;
    height: 48px;
    border-radius: 16px;
    display: grid;
    place-items: center;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.07);
  }

  .league-row-rank-block span {
    color: #fff;
    font-weight: 1000;
    line-height: 1;
  }

  .league-row-rank-block small {
    color: #aebbd0;
    font-size: 0.54rem;
    font-weight: 1000;
    letter-spacing: 0.08em;
  }

  .league-row-main {
    min-width: 0;
  }

  .league-row-main strong {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: #fff;
    font-size: 0.94rem;
    letter-spacing: -0.02em;
  }

  .league-row-main small {
    display: block;
    margin-top: 3px;
    color: #aebbd0;
    font-size: 0.72rem;
    font-weight: 800;
  }

  .league-row-record {
    text-align: right;
  }

  .league-row-record strong {
    display: block;
    color: #fff;
    font-size: 1.3rem;
    line-height: 1;
  }

  .league-row-record small {
    display: block;
    margin-top: 4px;
    color: #aebbd0;
    font-size: 0.66rem;
    font-weight: 850;
  }

  .league-table-desktop-wrap {
    margin-top: 6px;
  }

  .upgraded-league-table { min-width: 760px; }
  .upgraded-league-table th { position: sticky; top: 0; z-index: 1; }
  .upgraded-league-table tbody tr.safe-row { background: rgba(255,255,255,0.018); }
  .upgraded-league-table tbody tr:hover { background: rgba(255,255,255,0.075); }

  .table-level-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 999px;
    padding: 5px 8px;
    min-width: 74px;
    font-size: 0.66rem;
    font-weight: 950;
    color: #d8e2ee;
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.07);
  }

  .table-level-badge.player { color: #ffe5ac; border-color: rgba(242,184,75,0.32); background: rgba(242,184,75,0.12); }
  .table-level-badge.easy { color: #b8f7d3; border-color: rgba(47,179,109,0.20); background: rgba(47,179,109,0.095); }
  .table-level-badge.balanced { color: #ffe5ac; border-color: rgba(242,184,75,0.18); background: rgba(242,184,75,0.085); }
  .table-level-badge.test { color: #ffd0a3; border-color: rgba(232,137,46,0.20); background: rgba(232,137,46,0.085); }
  .table-level-badge.hard,
  .table-level-badge.elite { color: #ffc2c2; border-color: rgba(216,58,58,0.22); background: rgba(216,58,58,0.095); }

  .positive-diff { color: #b8f7d3; font-weight: 950; }
  .negative-diff { color: #ffc2c2; font-weight: 950; }
  .points-total { color: #ffffff; font-size: 1.05rem; }

  @media (min-width: 760px) {
    .league-table-card-list { display: none; }
  }

  @media (max-width: 759px) {
    .league-table-desktop-wrap { display: none; }
    .league-table-player-dashboard { grid-template-columns: 1fr 1fr; }
    .player-position-card { grid-column: span 2; }
    .league-table-race-strip { grid-template-columns: 1fr; }
  }

  @media (max-width: 420px) {
    .league-table-player-dashboard { grid-template-columns: 1fr; }
    .player-position-card { grid-column: auto; }
    .league-row-card { grid-template-columns: 48px minmax(0, 1fr) 66px; }
    .league-row-rank-block { width: 44px; height: 44px; border-radius: 14px; }
  }


  .trophy-room-page { display: grid; gap: 14px; }
  .trophy-hero-card {
    position: relative;
    overflow: hidden;
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 16px;
    align-items: stretch;
    background:
      radial-gradient(circle at top right, rgba(242,184,75,0.22), transparent 34%),
      radial-gradient(circle at bottom left, rgba(216,58,58,0.16), transparent 38%),
      linear-gradient(135deg, rgba(29,35,42,0.98), rgba(8,10,14,0.98));
    border: 1px solid rgba(242,184,75,0.18);
    border-radius: 26px;
    padding: 18px;
    box-shadow: 0 18px 46px rgba(0,0,0,0.30);
  }
  .trophy-hero-card h2 { margin: 0 0 8px; font-size: 1.75rem; letter-spacing: -0.04em; }
  .trophy-hero-card p:not(.eyebrow) { margin: 0; color: var(--muted); line-height: 1.4; }
  .trophy-hero-cup {
    min-width: 116px;
    border-radius: 24px;
    background: rgba(242,184,75,0.12);
    border: 1px solid rgba(242,184,75,0.28);
    display: grid;
    place-items: center;
    text-align: center;
    padding: 14px 12px;
  }
  .trophy-hero-cup span, .trophy-summary-card span {
    color: var(--muted);
    font-size: 0.68rem;
    font-weight: 1000;
    text-transform: uppercase;
    letter-spacing: 0.08em;
  }
  .trophy-hero-cup strong { font-size: 2.3rem; line-height: 1; color: var(--yellow); margin: 4px 0; }
  .trophy-hero-cup small { color: var(--muted); font-weight: 850; max-width: 112px; }
  .trophy-summary-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }
  .trophy-summary-card {
    background: linear-gradient(180deg, rgba(29,35,42,0.98), rgba(18,22,27,0.98));
    border: 1px solid var(--border-soft);
    border-radius: 20px;
    padding: 14px;
    min-height: 104px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  .trophy-summary-card strong { display: block; font-size: 2rem; line-height: 1; color: var(--text); }
  .trophy-summary-card small { color: var(--muted); font-weight: 800; }
  .trophy-summary-card.gold { border-color: rgba(242,184,75,0.28); background: rgba(242,184,75,0.09); }
  .trophy-summary-card.silver { border-color: rgba(170,180,192,0.26); background: rgba(170,180,192,0.08); }
  .trophy-summary-card.danger-lite { border-color: rgba(216,58,58,0.20); background: rgba(216,58,58,0.07); }
  .trophy-panel {
    background: linear-gradient(180deg, rgba(29,35,42,0.98), rgba(18,22,27,0.98));
    border: 1px solid var(--border-soft);
    border-radius: 24px;
    padding: 16px;
    box-shadow: 0 16px 38px rgba(0,0,0,0.22);
  }
  .trophy-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
  .trophy-card {
    min-height: 152px;
    border-radius: 22px;
    padding: 14px;
    border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.045);
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .trophy-card.unlocked.gold, .trophy-list-row.gold { border-color: rgba(242,184,75,0.34); background: rgba(242,184,75,0.10); }
  .trophy-card.unlocked.silver, .trophy-list-row.silver { border-color: rgba(170,180,192,0.28); background: rgba(170,180,192,0.09); }
  .trophy-card.unlocked.bronze { border-color: rgba(232,137,46,0.30); background: rgba(232,137,46,0.08); }
  .trophy-card.unlocked.elite { border-color: rgba(216,58,58,0.36); background: linear-gradient(135deg, rgba(216,58,58,0.12), rgba(242,184,75,0.08)); }
  .trophy-card.locked { opacity: 0.66; filter: grayscale(0.35); }
  .trophy-icon {
    width: 48px;
    height: 48px;
    border-radius: 16px;
    display: grid;
    place-items: center;
    background: rgba(255,255,255,0.065);
    border: 1px solid rgba(255,255,255,0.08);
    font-size: 1.5rem;
  }
  .trophy-card strong { display: block; color: var(--text); font-size: 1.04rem; letter-spacing: -0.02em; margin-bottom: 4px; }
  .trophy-card span { display: block; color: var(--muted); line-height: 1.25; font-size: 0.86rem; margin-bottom: 8px; }
  .trophy-card small { display: block; color: var(--soft); line-height: 1.3; font-weight: 760; }
  .trophy-section-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  .trophy-list, .trophy-season-list { display: grid; gap: 9px; }
  .trophy-list-row, .trophy-season-row {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 12px;
    align-items: center;
    border-radius: 18px;
    padding: 12px;
    border: 1px solid rgba(255,255,255,0.075);
    background: rgba(255,255,255,0.045);
  }
  .trophy-list-row > span {
    width: 38px;
    height: 38px;
    border-radius: 14px;
    display: grid;
    place-items: center;
    background: rgba(255,255,255,0.06);
  }
  .trophy-list-row strong, .trophy-season-row strong { display: block; color: var(--text); }
  .trophy-list-row small, .trophy-season-row span { color: var(--muted); line-height: 1.25; }
  .trophy-season-row { grid-template-columns: 1fr auto; }
  .trophy-season-row small { font-weight: 950; color: var(--muted); }
  .trophy-season-row small.positive { color: var(--green); }
  .trophy-season-row small.negative { color: #ff9f9f; }

  @media (max-width: 680px) {
    .trophy-hero-card { grid-template-columns: 1fr; }
    .trophy-hero-cup { min-width: 0; }
    .trophy-summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .trophy-grid { grid-template-columns: 1fr; }
    .trophy-section-grid { grid-template-columns: 1fr; }
  }


  /* v0.3.8 — Trophy Room Placement Trophies */
  .trophy-room-v2 .trophy-hero-card-v2 {
    align-items: center;
    gap: 16px;
  }
  .trophy-hero-cups-row {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 10px;
    width: 100%;
    max-width: 280px;
  }
  .hero-mini-cup {
    border-radius: 18px;
    padding: 12px 10px;
    border: 1px solid var(--line);
    background: rgba(255,255,255,0.04);
    text-align: center;
    display: grid;
    gap: 4px;
  }
  .hero-mini-cup span { font-size: 1.8rem; line-height: 1; }
  .hero-mini-cup strong { font-size: 1.35rem; line-height: 1; color: var(--text); }
  .hero-mini-cup small { color: var(--muted); font-weight: 800; }
  .hero-mini-cup.gold span, .placement-cup.place-1 { color: #f2b84b; }
  .hero-mini-cup.silver span, .placement-cup.place-2 { color: #d7dee7; }
  .hero-mini-cup.bronze span, .placement-cup.place-3 { color: #d68a47; }
  .trophy-summary-grid-v2 .bronze-lite {
    border-color: rgba(214,138,71,0.28);
    background: rgba(214,138,71,0.10);
  }
  .placement-trophy-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
  }
  .placement-trophy-card {
    border-radius: 22px;
    padding: 14px;
    border: 1px solid var(--line);
    background: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02));
    display: grid;
    gap: 12px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
  }
  .placement-trophy-card.place-1 { border-color: rgba(242,184,75,0.34); }
  .placement-trophy-card.place-2 { border-color: rgba(215,222,231,0.28); }
  .placement-trophy-card.place-3 { border-color: rgba(214,138,71,0.30); }
  .placement-trophy-card.league-pub { background-image: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02)), linear-gradient(135deg, rgba(120,81,45,0.16), transparent 55%); }
  .placement-trophy-card.league-town { background-image: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02)), linear-gradient(135deg, rgba(61,123,213,0.16), transparent 55%); }
  .placement-trophy-card.league-county { background-image: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02)), linear-gradient(135deg, rgba(47,179,109,0.16), transparent 55%); }
  .placement-trophy-card.league-national { background-image: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02)), linear-gradient(135deg, rgba(216,58,58,0.16), transparent 55%); }
  .placement-trophy-card.league-elite { background-image: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02)), linear-gradient(135deg, rgba(242,184,75,0.15), rgba(216,58,58,0.09) 55%, transparent 80%); }
  .placement-trophy-top {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 12px;
    align-items: center;
  }
  .placement-cup {
    font-size: 3rem;
    line-height: 1;
    filter: drop-shadow(0 6px 14px rgba(0,0,0,0.18));
  }
  .placement-meta small {
    display: block;
    color: var(--muted);
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 2px;
  }
  .placement-meta strong {
    color: var(--text);
    font-size: 1.1rem;
    letter-spacing: -0.02em;
  }
  .placement-league-chip {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    width: fit-content;
    padding: 8px 10px;
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.05);
  }
  .placement-league-chip span { font-size: 1rem; }
  .placement-league-chip b { color: var(--text); font-size: 0.88rem; }
  .placement-trophy-body h4 {
    margin: 0 0 2px;
    color: var(--text);
    font-size: 1.05rem;
    letter-spacing: -0.02em;
  }
  .placement-trophy-body p {
    margin: 0 0 10px;
    color: var(--muted);
    font-weight: 780;
  }
  .placement-trophy-stats {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 8px;
  }
  .placement-trophy-stats span {
    padding: 6px 9px;
    border-radius: 999px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.06);
    color: var(--text);
    font-size: 0.8rem;
    font-weight: 850;
  }
  .placement-trophy-body small {
    display: block;
    color: var(--yellow);
    font-weight: 900;
  }
  .compact-list { gap: 10px; }
  .trophy-season-row.compact { grid-template-columns: 1fr auto; }
  .trophy-season-row.compact.place-1 { border-color: rgba(242,184,75,0.24); background: rgba(242,184,75,0.08); }
  .trophy-season-row.compact.place-2 { border-color: rgba(215,222,231,0.18); background: rgba(215,222,231,0.06); }
  .trophy-season-row.compact.place-3 { border-color: rgba(214,138,71,0.22); background: rgba(214,138,71,0.06); }

  @media (max-width: 720px) {
    .placement-trophy-grid { grid-template-columns: 1fr; }
  }

  @media (max-width: 640px) {
    .trophy-hero-cups-row, .trophy-summary-grid-v2 { grid-template-columns: 1fr 1fr; max-width: none; }
    .trophy-hero-cups-row .hero-mini-cup:last-child,
    .trophy-summary-grid-v2 > :last-child { grid-column: span 2; }
  }



  /* v0.3.9 — League Events */
  .league-events-page { display: grid; gap: 14px; }
  .events-hero-card {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 14px;
    align-items: center;
    border: 1px solid var(--border-soft);
    border-radius: 24px;
    padding: 18px;
    background:
      radial-gradient(circle at 12% 0%, rgba(216,58,58,0.18), transparent 36%),
      linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.025));
    box-shadow: var(--shadow);
  }
  .events-hero-card h2 { margin: 0 0 6px; color: var(--text); font-size: 1.6rem; letter-spacing: -0.04em; }
  .events-hero-card p:not(.eyebrow) { margin: 0; color: var(--muted); line-height: 1.42; }
  .events-hero-summary {
    min-width: 128px;
    border-radius: 20px;
    padding: 14px;
    text-align: center;
    border: 1px solid rgba(242,184,75,0.24);
    background: rgba(242,184,75,0.08);
  }
  .events-hero-summary span, .events-hero-summary small { display: block; color: var(--muted); font-size: 0.78rem; font-weight: 850; }
  .events-hero-summary strong { display: block; color: var(--yellow); font-size: 2rem; line-height: 1; margin: 5px 0; }
  .events-summary-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
  .event-summary-card {
    border-radius: 18px;
    padding: 13px;
    border: 1px solid var(--border-soft);
    background: rgba(255,255,255,0.04);
  }
  .event-summary-card.gold { border-color: rgba(242,184,75,0.22); background: rgba(242,184,75,0.08); }
  .event-summary-card span { display: block; color: var(--muted); font-size: 0.78rem; font-weight: 850; text-transform: uppercase; letter-spacing: 0.06em; }
  .event-summary-card strong { display: block; color: var(--text); font-size: 1.1rem; margin: 4px 0; }
  .event-summary-card small { color: var(--soft); font-weight: 780; }
  .event-card-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
  .league-event-card {
    border-radius: 22px;
    padding: 14px;
    border: 1px solid var(--border-soft);
    background: linear-gradient(180deg, rgba(255,255,255,0.055), rgba(255,255,255,0.025));
    display: grid;
    gap: 12px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
  }
  .league-event-card.easy { border-color: rgba(47,179,109,0.18); }
  .league-event-card.balanced { border-color: rgba(242,184,75,0.22); }
  .league-event-card.hard { border-color: rgba(216,58,58,0.22); }
  .league-event-card.completed { opacity: 0.78; }
  .event-card-topline { display: flex; justify-content: space-between; gap: 10px; align-items: center; }
  .event-card-topline small { color: var(--muted); font-weight: 850; }
  .event-difficulty {
    display: inline-flex;
    align-items: center;
    border-radius: 999px;
    padding: 6px 10px;
    font-size: 0.74rem;
    font-weight: 950;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    border: 1px solid var(--border-soft);
  }
  .event-difficulty.easy { color: #c7f7dc; background: rgba(47,179,109,0.14); border-color: rgba(47,179,109,0.24); }
  .event-difficulty.balanced { color: #ffe3a6; background: rgba(242,184,75,0.13); border-color: rgba(242,184,75,0.24); }
  .event-difficulty.hard { color: #ffb6b6; background: rgba(216,58,58,0.13); border-color: rgba(216,58,58,0.24); }
  .league-event-card h3 { margin: 0; color: var(--text); font-size: 1.1rem; letter-spacing: -0.03em; }
  .league-event-card p { margin: -6px 0 0; color: var(--muted); line-height: 1.35; font-size: 0.9rem; }
  .event-opponent-box {
    border-radius: 16px;
    padding: 12px;
    background: rgba(0,0,0,0.16);
    border: 1px solid rgba(255,255,255,0.06);
  }
  .event-opponent-box span, .event-prize-row span { display: block; color: var(--muted); font-size: 0.74rem; font-weight: 850; text-transform: uppercase; letter-spacing: 0.06em; }
  .event-opponent-box strong { display: block; color: var(--text); margin: 3px 0; }
  .event-opponent-box small { color: var(--soft); font-weight: 780; }
  .event-prize-row { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .event-prize-row div {
    border-radius: 14px;
    padding: 10px;
    background: rgba(242,184,75,0.07);
    border: 1px solid rgba(242,184,75,0.12);
  }
  .event-prize-row strong { color: var(--yellow); display: block; margin-top: 3px; font-size: 1.05rem; }
  .events-history-panel {
    border-radius: 22px;
    padding: 14px;
    border: 1px solid var(--border-soft);
    background: rgba(255,255,255,0.04);
  }
  .event-history-list { display: grid; gap: 9px; }
  .event-history-row {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 10px;
    align-items: center;
    border-radius: 16px;
    padding: 11px;
    border: 1px solid rgba(255,255,255,0.06);
    background: rgba(0,0,0,0.12);
  }
  .event-history-row strong { display: block; color: var(--text); }
  .event-history-row span { color: var(--muted); font-size: 0.86rem; }
  .event-history-row small { color: var(--yellow); font-weight: 950; }
  @media (max-width: 860px) {
    .event-card-grid { grid-template-columns: 1fr; }
    .events-summary-grid { grid-template-columns: 1fr; }
  }
  @media (max-width: 640px) {
    .events-hero-card { grid-template-columns: 1fr; }
    .events-hero-summary { min-width: 0; }
  }


  /* v0.4.0 — Expanded League Events */
  .expanded-events-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .event-progress-track {
    width: 100%;
    height: 8px;
    border-radius: 999px;
    overflow: hidden;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.06);
    margin-top: -2px;
  }
  .event-progress-track span {
    display: block;
    height: 100%;
    border-radius: inherit;
    background: linear-gradient(90deg, var(--red), var(--yellow));
  }
  .event-prize-row-v2 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
  .event-prize-row-v2 div:last-child strong { color: var(--text); font-size: 0.9rem; }
  @media (min-width: 1040px) {
    .expanded-events-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
  }
  @media (max-width: 760px) {
    .expanded-events-grid { grid-template-columns: 1fr; }
    .event-prize-row-v2 { grid-template-columns: 1fr; }
  }


  /* v0.4.2 — Event Detail Pages */
  .compact-events-page { gap: 12px; }
  .compact-events-hero { padding: 16px; }
  .compact-events-hero h2 { font-size: 1.48rem; }
  .events-compact-summary {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 9px;
  }
  .events-compact-summary > div {
    border: 1px solid var(--border-soft);
    background: rgba(255,255,255,0.045);
    border-radius: 18px;
    padding: 12px;
  }
  .events-compact-summary span,
  .event-compact-side span,
  .event-compact-main small,
  .event-venue-badge span,
  .event-next-opponent-card span {
    display: block;
    color: var(--muted);
    font-size: 0.72rem;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.07em;
  }
  .events-compact-summary strong { color: var(--text); display: block; margin-top: 4px; }
  .event-compact-list { display: grid; gap: 9px; }
  .event-compact-row {
    width: 100%;
    text-align: left;
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 12px;
    align-items: center;
    border-radius: 18px;
    border: 1px solid var(--border-soft);
    color: var(--text);
    padding: 12px;
    background:
      linear-gradient(90deg, rgba(255,255,255,0.055), rgba(255,255,255,0.025));
    position: relative;
    overflow: hidden;
  }
  .event-compact-row::before {
    content: "";
    position: absolute;
    inset: 0 auto 0 0;
    width: 5px;
    background: var(--event-accent, var(--red));
  }
  .event-compact-row.completed { opacity: 0.74; }
  .event-compact-main, .event-compact-side { position: relative; min-width: 0; }
  .event-compact-main strong {
    display: block;
    margin: 6px 0 4px;
    font-size: 1rem;
    letter-spacing: -0.02em;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .event-compact-side { text-align: right; min-width: 96px; }
  .event-compact-side strong { display: block; margin: 4px 0; font-size: 1.05rem; }
  .theme-red { --event-accent: #d83a3a; }
  .theme-gold { --event-accent: #f2b84b; }
  .theme-green { --event-accent: #2fb36d; }
  .theme-blue { --event-accent: #4e8cff; }
  .theme-purple { --event-accent: #9b6cff; }
  .theme-orange { --event-accent: #e8892e; }
  .event-detail-page { display: grid; gap: 12px; }
  .event-detail-hero {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 14px;
    align-items: stretch;
    border-radius: 26px;
    border: 1px solid color-mix(in srgb, var(--event-accent) 34%, var(--border-soft));
    background:
      radial-gradient(circle at top left, color-mix(in srgb, var(--event-accent) 28%, transparent), transparent 42%),
      linear-gradient(135deg, rgba(29,35,42,0.98), rgba(9,12,16,0.98));
    padding: 18px;
    box-shadow: 0 18px 48px rgba(0,0,0,0.28);
  }
  .event-detail-hero h2 { margin: 0 0 6px; font-size: 1.55rem; letter-spacing: -0.04em; }
  .event-detail-hero p:not(.eyebrow) { margin: 0 0 12px; color: var(--muted); line-height: 1.35; }
  .event-detail-chip-row { display: flex; flex-wrap: wrap; gap: 7px; }
  .event-detail-chip-row span {
    border-radius: 999px;
    padding: 7px 10px;
    border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.06);
    color: var(--text);
    font-weight: 850;
    font-size: 0.8rem;
  }
  .event-venue-badge {
    min-width: 150px;
    border-radius: 22px;
    background: rgba(255,255,255,0.065);
    border: 1px solid rgba(255,255,255,0.09);
    padding: 14px;
    display: grid;
    align-content: center;
    gap: 5px;
  }
  .event-venue-badge strong { color: var(--text); line-height: 1.1; }
  .event-venue-badge small { color: var(--muted); font-weight: 850; }
  .event-detail-status-card,
  .event-detail-panel {
    border: 1px solid var(--border-soft);
    background: linear-gradient(180deg, rgba(29,35,42,0.98), rgba(18,22,27,0.98));
    border-radius: 24px;
    padding: 16px;
  }
  .event-detail-progress {
    height: 9px;
    border-radius: 999px;
    background: rgba(255,255,255,0.07);
    overflow: hidden;
    margin: 10px 0 14px;
  }
  .event-detail-progress span {
    display: block;
    height: 100%;
    border-radius: inherit;
    background: linear-gradient(90deg, var(--event-accent), color-mix(in srgb, var(--event-accent) 60%, white));
  }
  .event-next-opponent-card {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 12px;
    align-items: center;
    border-radius: 18px;
    padding: 12px;
    background: rgba(255,255,255,0.045);
    border: 1px solid rgba(255,255,255,0.075);
    margin-bottom: 12px;
  }
  .event-next-opponent-card strong { display: block; color: var(--text); margin: 4px 0; }
  .event-next-opponent-card small { display: block; color: var(--muted); font-weight: 780; }
  .event-next-opponent-card > div:last-child { text-align: right; min-width: 112px; }
  .event-detail-grid {
    display: grid;
    grid-template-columns: minmax(250px, 0.9fr) minmax(320px, 1.1fr);
    gap: 12px;
  }
  .event-participant-list { display: grid; gap: 7px; max-height: 460px; overflow: auto; padding-right: 4px; }
  .event-participant-row {
    display: grid;
    grid-template-columns: 42px 1fr auto;
    gap: 9px;
    align-items: center;
    border-radius: 14px;
    padding: 9px 10px;
    border: 1px solid rgba(255,255,255,0.065);
    background: rgba(255,255,255,0.04);
  }
  .event-participant-row.you {
    border-color: rgba(242,184,75,0.40);
    background: rgba(242,184,75,0.10);
  }
  .event-participant-row span { color: var(--muted); font-weight: 950; }
  .event-participant-row strong {
    color: var(--text);
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .event-participant-row small { color: var(--muted); font-weight: 800; }
  .event-bracket-tree {
    display: flex;
    gap: 10px;
    overflow-x: auto;
    padding-bottom: 4px;
  }
  .event-bracket-round {
    min-width: 220px;
    border-radius: 18px;
    padding: 10px;
    border: 1px solid rgba(255,255,255,0.075);
    background: rgba(255,255,255,0.035);
  }
  .event-bracket-round.active {
    border-color: color-mix(in srgb, var(--event-accent) 50%, var(--border-soft));
    background: color-mix(in srgb, var(--event-accent) 11%, rgba(255,255,255,0.035));
  }
  .event-bracket-round.passed { opacity: 0.78; }
  .event-bracket-round-title {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    align-items: baseline;
    margin-bottom: 8px;
  }
  .event-bracket-round-title strong { color: var(--text); }
  .event-bracket-round-title small { color: var(--muted); font-weight: 820; }
  .event-bracket-match-list { display: grid; gap: 7px; }
  .event-bracket-match {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    gap: 7px;
    align-items: center;
    border-radius: 12px;
    padding: 8px;
    background: rgba(0,0,0,0.18);
    border: 1px solid rgba(255,255,255,0.06);
  }
  .event-bracket-match.player-path {
    border-color: rgba(242,184,75,0.30);
    background: rgba(242,184,75,0.08);
  }
  .event-bracket-match span {
    color: var(--text);
    font-size: 0.82rem;
    font-weight: 850;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .event-bracket-match small { color: var(--muted); font-weight: 900; text-transform: uppercase; font-size: 0.65rem; }
  .event-bracket-more {
    text-align: center;
    color: var(--muted);
    border-radius: 12px;
    padding: 8px;
    background: rgba(255,255,255,0.035);
    font-weight: 850;
  }
  @media (max-width: 760px) {
    .event-detail-hero { grid-template-columns: 1fr; }
    .event-venue-badge { min-width: 0; }
    .event-detail-grid { grid-template-columns: 1fr; }
    .events-compact-summary { grid-template-columns: 1fr; }
  }
  @media (max-width: 560px) {
    .event-compact-row { grid-template-columns: 1fr; }
    .event-compact-side { text-align: left; display: grid; grid-template-columns: 1fr auto; gap: 4px 10px; align-items: baseline; }
    .event-compact-side small { grid-column: 1 / -1; }
    .event-next-opponent-card { grid-template-columns: 1fr; }
    .event-next-opponent-card > div:last-child { text-align: left; }
  }


  /* v0.4.3 — Event trophies + compact tournament path */
  .trophy-hero-cups-row-wide {
    grid-template-columns: repeat(4, minmax(0, 1fr));
    max-width: 380px;
  }
  .hero-mini-cup.event-cup {
    border-color: rgba(138, 111, 255, 0.26);
    background: rgba(138, 111, 255, 0.08);
  }
  .hero-mini-cup.event-cup span { color: #b7a8ff; }
  .trophy-summary-grid-v3 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .trophy-summary-card.event-lite {
    border-color: rgba(138, 111, 255, 0.26);
    background: rgba(138, 111, 255, 0.08);
  }
  .event-cup-trophy-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
  }
  .event-cup-trophy-card {
    border: 1px solid var(--line);
    border-radius: 22px;
    padding: 14px;
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 12px;
    align-items: start;
    background: linear-gradient(145deg, rgba(255,255,255,0.055), rgba(255,255,255,0.025));
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
  }
  .event-cup-trophy-card.cup-small { border-color: rgba(47,179,109,0.25); background-image: linear-gradient(145deg, rgba(47,179,109,0.11), rgba(255,255,255,0.025)); }
  .event-cup-trophy-card.cup-open { border-color: rgba(58,123,213,0.25); background-image: linear-gradient(145deg, rgba(58,123,213,0.11), rgba(255,255,255,0.025)); }
  .event-cup-trophy-card.cup-classic { border-color: rgba(242,184,75,0.28); background-image: linear-gradient(145deg, rgba(242,184,75,0.11), rgba(255,255,255,0.025)); }
  .event-cup-trophy-card.cup-major { border-color: rgba(216,58,58,0.30); background-image: linear-gradient(145deg, rgba(216,58,58,0.13), rgba(138,111,255,0.08)); }
  .event-cup-icon {
    width: 48px;
    height: 48px;
    border-radius: 16px;
    display: grid;
    place-items: center;
    font-size: 1.75rem;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.08);
  }
  .event-cup-trophy-card small {
    display: block;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 900;
    font-size: 0.68rem;
    margin-bottom: 4px;
  }
  .event-cup-trophy-card strong {
    display: block;
    color: var(--text);
    font-size: 1rem;
    letter-spacing: -0.02em;
    margin-bottom: 4px;
  }
  .event-cup-trophy-card span {
    display: block;
    color: var(--muted);
    font-weight: 780;
    margin-bottom: 9px;
  }
  .event-cup-trophy-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 7px;
  }
  .event-cup-trophy-meta b {
    color: var(--text);
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.07);
    padding: 5px 8px;
    border-radius: 999px;
    font-size: 0.75rem;
  }
  .trophy-season-row.compact.event-win {
    border-color: rgba(138,111,255,0.22);
    background: rgba(138,111,255,0.07);
  }
  .compact-bracket-panel {
    min-width: 0;
    overflow: hidden;
  }
  .event-compact-bracket {
    display: grid;
    gap: 9px;
    min-width: 0;
  }
  .event-compact-round {
    border: 1px solid rgba(255,255,255,0.075);
    border-radius: 18px;
    padding: 11px;
    background: rgba(255,255,255,0.035);
    min-width: 0;
  }
  .event-compact-round.active {
    border-color: rgba(242,184,75,0.34);
    background: rgba(242,184,75,0.08);
  }
  .event-compact-round.passed {
    opacity: 0.72;
  }
  .compact-round-head {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    align-items: flex-start;
    margin-bottom: 9px;
  }
  .compact-round-head strong {
    display: block;
    color: var(--text);
    font-size: 0.95rem;
  }
  .compact-round-head small {
    display: block;
    color: var(--muted);
    font-weight: 780;
    margin-top: 1px;
  }
  .compact-round-head > span {
    flex: 0 0 auto;
    color: var(--text);
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 999px;
    padding: 5px 8px;
    font-size: 0.7rem;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  .compact-player-path {
    display: grid;
    grid-template-columns: minmax(0,1fr) auto minmax(0,1fr);
    gap: 8px;
    align-items: center;
    padding: 9px;
    border-radius: 14px;
    background: rgba(0,0,0,0.18);
    border: 1px solid rgba(255,255,255,0.06);
    min-width: 0;
  }
  .compact-player-path.highlight {
    border-color: rgba(216,58,58,0.34);
    background: rgba(216,58,58,0.08);
  }
  .compact-player-path span {
    color: var(--text);
    font-weight: 850;
    font-size: 0.82rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .compact-player-path em {
    color: var(--muted);
    font-style: normal;
    font-size: 0.68rem;
    font-weight: 950;
    text-transform: uppercase;
  }
  .compact-bracket-note {
    margin-top: 7px;
    color: var(--muted);
    font-size: 0.76rem;
    font-weight: 780;
  }
  @media (max-width: 760px) {
    .trophy-hero-cups-row-wide,
    .trophy-summary-grid-v3,
    .event-cup-trophy-grid {
      grid-template-columns: 1fr 1fr;
      max-width: none;
    }
  }
  @media (max-width: 560px) {
    .trophy-hero-cups-row-wide,
    .trophy-summary-grid-v3,
    .event-cup-trophy-grid {
      grid-template-columns: 1fr;
    }
    .compact-player-path {
      grid-template-columns: 1fr;
      gap: 5px;
      text-align: left;
    }
    .compact-player-path em { text-align: left; }
  }



  /* v0.4.6 — Event Flow Stabilization */
  .event-flow-note {
    display: grid;
    gap: 4px;
    padding: 12px 14px;
    border-radius: 18px;
    border: 1px solid rgba(242,184,75,0.16);
    background: rgba(242,184,75,0.07);
  }
  .event-flow-note strong {
    color: var(--text);
    font-size: 0.92rem;
    letter-spacing: -0.01em;
  }
  .event-flow-note span {
    color: var(--muted);
    font-size: 0.84rem;
    line-height: 1.35;
    font-weight: 760;
  }



  /* v0.4.6 — Event Polish + Event Recap */
  .compact-events-page .events-hero-card,
  .event-detail-page .event-detail-hero {
    box-shadow: 0 18px 44px rgba(0,0,0,0.28);
  }
  .event-compact-row {
    position: relative;
    overflow: hidden;
  }
  .event-compact-row::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 5px;
    background: var(--yellow);
    opacity: 0.78;
  }
  .event-compact-row.theme-red::before { background: var(--red); }
  .event-compact-row.theme-gold::before { background: var(--yellow); }
  .event-compact-row.theme-green::before { background: var(--green); }
  .event-compact-row.theme-blue::before { background: #6ba7ff; }
  .event-compact-row.theme-purple::before { background: #b68cff; }
  .event-compact-row.theme-orange::before { background: var(--orange); }
  .event-compact-row.completed {
    opacity: 0.88;
  }
  .event-detail-status-card,
  .event-detail-panel {
    box-shadow: 0 12px 32px rgba(0,0,0,0.20);
  }
  .event-compact-round {
    border-radius: 18px;
  }
  .event-compact-round.active {
    box-shadow: 0 0 0 1px rgba(242,184,75,0.22), 0 16px 34px rgba(0,0,0,0.22);
  }
  .event-recap-page {
    display: grid;
    gap: 14px;
  }
  .event-recap-hero {
    border: 1px solid var(--border-soft);
    border-radius: 26px;
    padding: 22px;
    background:
      radial-gradient(circle at 12% 0%, rgba(242,184,75,0.18), transparent 30%),
      linear-gradient(180deg, rgba(29,35,42,0.98), rgba(21,25,30,0.98));
    box-shadow: var(--shadow);
    overflow: hidden;
  }
  .event-recap-hero.winner {
    border-color: rgba(242,184,75,0.32);
    background:
      radial-gradient(circle at 12% 0%, rgba(242,184,75,0.28), transparent 34%),
      radial-gradient(circle at 90% 10%, rgba(47,179,109,0.16), transparent 28%),
      linear-gradient(180deg, rgba(29,35,42,0.98), rgba(21,25,30,0.98));
  }
  .event-recap-hero.exit {
    border-color: rgba(216,58,58,0.20);
  }
  .event-recap-hero h2 {
    margin: 0 0 8px;
    font-size: clamp(2rem, 9vw, 3.2rem);
    letter-spacing: -0.06em;
    line-height: 0.92;
  }
  .event-recap-hero p:not(.eyebrow) {
    color: var(--muted);
    margin: 0;
    max-width: 680px;
    line-height: 1.45;
  }
  .event-recap-chip-row {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 16px;
  }
  .event-recap-chip-row span {
    border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.05);
    color: var(--text);
    padding: 8px 10px;
    border-radius: 999px;
    font-weight: 850;
    font-size: 0.84rem;
  }
  .event-recap-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
  }
  .event-recap-card {
    border: 1px solid var(--border-soft);
    border-radius: 20px;
    padding: 14px;
    background: linear-gradient(180deg, rgba(37,44,52,0.96), rgba(21,25,30,0.96));
    box-shadow: 0 12px 30px rgba(0,0,0,0.18);
  }
  .event-recap-card.big-result {
    border-color: rgba(242,184,75,0.25);
    background:
      linear-gradient(180deg, rgba(242,184,75,0.10), rgba(21,25,30,0.96));
  }
  .event-recap-card span {
    display: block;
    color: var(--muted);
    font-weight: 850;
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 8px;
  }
  .event-recap-card strong {
    display: block;
    color: var(--text);
    font-size: 1.35rem;
    line-height: 1.05;
    letter-spacing: -0.04em;
    margin-bottom: 6px;
  }
  .event-recap-card small {
    color: var(--muted);
    line-height: 1.3;
    font-weight: 760;
  }
  .event-recap-actions h3 {
    margin: 0 0 8px;
  }
  .event-recap-button-row {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }
  .event-recap-button-row button {
    flex: 1 1 180px;
  }
  @media (max-width: 760px) {
    .event-recap-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  }
  @media (max-width: 520px) {
    .event-recap-grid { grid-template-columns: 1fr; }
    .event-recap-hero { padding: 18px; }
  }


  /* v0.4.7 — Match History v1 */
  .match-history-page { display: grid; gap: 14px; }
  .history-hero-card {
    background: linear-gradient(135deg, rgba(216,58,58,0.13), rgba(29,35,42,0.98) 46%, rgba(242,184,75,0.08));
    border: 1px solid var(--border-soft);
    border-radius: 24px;
    padding: 18px;
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 14px;
    align-items: center;
    box-shadow: var(--shadow);
  }
  .history-hero-card h2 { margin: 0 0 8px; font-size: 1.7rem; letter-spacing: -0.04em; }
  .history-hero-badge {
    min-width: 112px;
    border-radius: 20px;
    padding: 14px;
    text-align: center;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.08);
  }
  .history-hero-badge strong { display: block; color: var(--text); font-size: 2rem; line-height: 1; }
  .history-hero-badge small { color: var(--muted); font-weight: 850; }
  .history-summary-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 10px;
  }
  .history-summary-grid > div,
  .history-list-panel,
  .history-link-panel {
    background: linear-gradient(180deg, rgba(29,35,42,0.98), rgba(18,22,27,0.98));
    border: 1px solid var(--border-soft);
    border-radius: 20px;
    padding: 14px;
    box-shadow: 0 14px 30px rgba(0,0,0,0.18);
  }
  .history-summary-grid span { display: block; color: var(--muted); font-weight: 850; font-size: 0.8rem; }
  .history-summary-grid strong { display: block; color: var(--text); font-size: 1.7rem; line-height: 1.1; margin-top: 4px; }
  .match-history-list { display: grid; gap: 10px; }
  .history-row-card {
    border-radius: 18px;
    border: 1px solid rgba(183,198,215,0.12);
    background: rgba(255,255,255,0.035);
    padding: 13px;
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 10px;
  }
  .history-row-card.won { border-color: rgba(47,179,109,0.24); background: linear-gradient(135deg, rgba(47,179,109,0.08), rgba(255,255,255,0.03)); }
  .history-row-card.lost { border-color: rgba(216,58,58,0.22); background: linear-gradient(135deg, rgba(216,58,58,0.07), rgba(255,255,255,0.025)); }
  .history-row-main h4 { margin: 5px 0 4px; color: var(--text); font-size: 1rem; letter-spacing: -0.02em; }
  .history-row-main p { margin: 0; color: var(--muted); font-size: 0.84rem; font-weight: 760; }
  .history-context-pill {
    display: inline-flex;
    padding: 5px 8px;
    border-radius: 999px;
    background: rgba(242,184,75,0.10);
    border: 1px solid rgba(242,184,75,0.18);
    color: var(--yellow);
    font-size: 0.72rem;
    font-weight: 950;
  }
  .history-score-block { text-align: right; }
  .history-score-block strong { display: block; color: var(--text); font-size: 1.65rem; line-height: 1; }
  .history-score-block small { color: var(--muted); font-weight: 850; }
  .history-stat-strip {
    grid-column: 1 / -1;
    display: flex;
    flex-wrap: wrap;
    gap: 7px;
    border-top: 1px solid rgba(255,255,255,0.06);
    padding-top: 9px;
  }
  .history-stat-strip span {
    border-radius: 999px;
    padding: 6px 8px;
    background: rgba(255,255,255,0.045);
    color: var(--muted);
    font-size: 0.76rem;
    font-weight: 820;
  }
  .history-stat-strip b { color: var(--text); }
  .history-stat-strip .money-chip { color: var(--yellow); background: rgba(242,184,75,0.10); border: 1px solid rgba(242,184,75,0.14); }
  .history-link-panel { display: flex; justify-content: space-between; align-items: center; gap: 14px; }
  .history-link-panel h3 { margin: 0 0 5px; }
  @media (max-width: 640px) {
    .history-hero-card { grid-template-columns: 1fr; }
    .history-hero-badge { text-align: left; }
    .history-summary-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
    .history-link-panel { display: grid; }
  }

  /* v0.5.0 — Core UX Tightening */
  .core-next-action-card {
    border-color: rgba(216,58,58,0.24);
    background:
      radial-gradient(circle at top right, rgba(216,58,58,0.13), transparent 42%),
      linear-gradient(180deg, rgba(255,255,255,0.055), rgba(255,255,255,0.025));
    box-shadow: 0 18px 46px rgba(0,0,0,0.22), inset 0 1px 0 rgba(255,255,255,0.05);
  }
  .core-action-note {
    margin: 10px 0 0;
    color: var(--muted);
    font-weight: 820;
    font-size: 0.84rem;
    text-align: center;
  }
  .league-tools-panel {
    border: 1px solid var(--line);
    background: rgba(255,255,255,0.025);
    border-radius: 22px;
    padding: 14px;
    display: grid;
    gap: 12px;
  }
  .tightened-tools-grid {
    gap: 10px;
  }
  .tightened-tools-grid .secondary-button {
    display: grid;
    gap: 4px;
    text-align: left;
    align-content: center;
    min-height: 64px;
  }
  .tightened-tools-grid .secondary-button span {
    color: var(--text);
    font-weight: 900;
    letter-spacing: -0.01em;
  }
  .tightened-tools-grid .secondary-button small {
    color: var(--muted);
    font-weight: 760;
    line-height: 1.2;
  }
  .tightened-tools-grid .tool-priority {
    border-color: rgba(242,184,75,0.22);
    background: rgba(242,184,75,0.065);
  }
  .tightened-tools-grid .tool-secondary {
    opacity: 0.94;
  }
  .compact-events-hero {
    border-color: rgba(61,123,213,0.18);
  }
  .event-flow-note {
    background: rgba(255,255,255,0.035);
    border-color: rgba(255,255,255,0.07);
  }
  .compact-bracket-panel .section-row-header h3 {
    letter-spacing: -0.02em;
  }
  .event-compact-bracket {
    overflow: visible;
  }
  .compact-bracket-note {
    color: var(--muted);
    font-weight: 780;
  }
  @media (max-width: 680px) {
    .tightened-tools-grid .secondary-button {
      min-height: 58px;
    }
  }


/* v0.5.0 — Event Unlocking */
  .event-compact-row.locked {
    opacity: 0.58;
    filter: grayscale(0.22);
  }
  .event-compact-row.locked:hover {
    transform: none;
  }
  .event-compact-row.locked .event-difficulty {
    background: rgba(255,255,255,0.08);
    color: var(--muted);
    border-color: rgba(255,255,255,0.08);
  }
  .event-lock-notice {
    border: 1px solid rgba(242,184,75,0.24);
    background: rgba(242,184,75,0.08);
    border-radius: 16px;
    padding: 12px;
    display: grid;
    gap: 4px;
    margin: 10px 0;
  }
  .event-lock-notice strong {
    color: var(--yellow);
    font-size: 0.92rem;
  }
  .event-lock-notice span {
    color: var(--muted);
    line-height: 1.35;
    font-weight: 750;
  }


  /* v0.8.0 — Next Action UX */
  .core-next-action-card {
    position: relative;
    overflow: hidden;
    border-color: rgba(216,58,58,0.34);
    background:
      radial-gradient(circle at 88% 2%, rgba(216,58,58,0.22), transparent 34%),
      radial-gradient(circle at 0% 100%, rgba(242,184,75,0.10), transparent 38%),
      linear-gradient(180deg, rgba(29,35,42,0.98), rgba(10,13,18,0.98));
  }
  .core-next-action-card::before {
    content: "MAIN ACTION";
    position: absolute;
    right: 14px;
    top: 14px;
    border: 1px solid rgba(216,58,58,0.24);
    background: rgba(216,58,58,0.14);
    color: #ffd7d7;
    border-radius: 999px;
    padding: 5px 9px;
    font-size: 0.68rem;
    font-weight: 950;
    letter-spacing: 0.08em;
  }
  .core-next-action-card .section-row-header {
    padding-right: 92px;
  }
  .next-action-main-button {
    margin-top: 12px;
    min-height: 54px;
    font-size: 1rem;
    box-shadow: 0 14px 34px rgba(216,58,58,0.24);
  }
  .next-action-benefits {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 7px;
    margin-top: 10px;
  }
  .next-action-benefits span {
    border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.045);
    color: var(--muted);
    border-radius: 999px;
    padding: 6px 9px;
    font-size: 0.75rem;
    font-weight: 850;
  }
  .next-action-tools-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .next-action-tools-grid .secondary-button {
    min-height: 58px;
    border-color: rgba(255,255,255,0.075);
    background: rgba(255,255,255,0.03);
  }
  .next-action-tools-grid .secondary-button:hover {
    border-color: rgba(242,184,75,0.18);
  }
  .next-action-tools-grid .subtle-tool {
    opacity: 0.76;
  }
  @media (max-width: 640px) {
    .core-next-action-card::before {
      position: static;
      display: inline-flex;
      width: fit-content;
      margin-bottom: 8px;
    }
    .core-next-action-card .section-row-header {
      padding-right: 0;
    }
    .next-action-tools-grid {
      grid-template-columns: 1fr;
    }
  }


  /* v0.8.0 — Adaptive Current Level */
  .adaptive-level-card {
    border-color: rgba(242,184,75,0.22);
    background: linear-gradient(180deg, rgba(242,184,75,0.09), rgba(255,255,255,0.025));
  }
  .adaptive-helper-text {
    display: block;
    color: var(--muted);
    font-size: 0.78rem;
    font-weight: 800;
    margin-top: 3px;
  }

  /* v0.8.1 — Trophy Room Hierarchy */
  .trophy-room-hierarchy-page { gap: 16px; }
  .trophy-hierarchy-hero {
    border-color: rgba(242,184,75,0.22);
    background:
      radial-gradient(circle at 20% 0%, rgba(242,184,75,0.12), transparent 36%),
      linear-gradient(180deg, rgba(255,255,255,0.055), rgba(255,255,255,0.025));
  }
  .league-cabinet-hero-cups {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 10px;
    width: 100%;
    max-width: 320px;
  }
  .primary-cup-stat {
    min-height: 112px;
    justify-content: center;
    border-width: 1px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.06), 0 10px 24px rgba(0,0,0,0.14);
  }
  .primary-cup-stat span { font-size: 2.15rem; }
  .primary-cup-stat strong { font-size: 1.7rem; }
  .league-trophy-summary-grid {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .league-total-card {
    border-color: rgba(255,255,255,0.10);
    background: rgba(255,255,255,0.045);
  }
  .league-cabinet-panel {
    border-color: rgba(242,184,75,0.20);
    background:
      linear-gradient(180deg, rgba(242,184,75,0.045), rgba(255,255,255,0.025));
  }
  .section-subline {
    display: block;
    color: var(--muted);
    font-weight: 760;
    line-height: 1.35;
    margin-top: 4px;
    max-width: 520px;
  }
  .placement-trophy-grid-primary {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
  }
  .primary-league-trophy {
    min-height: 245px;
    padding: 16px;
    box-shadow: 0 18px 34px rgba(0,0,0,0.16), inset 0 1px 0 rgba(255,255,255,0.06);
  }
  .primary-league-trophy .placement-cup {
    font-size: 3.6rem;
  }
  .primary-league-trophy .placement-meta strong {
    font-size: 1.25rem;
  }
  .primary-league-trophy .placement-trophy-body h4 {
    font-size: 1.12rem;
  }
  .secondary-event-cabinet {
    border-color: rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.025);
  }
  .secondary-event-cabinet .section-row-header h3 {
    color: var(--muted-strong, var(--text));
  }
  .muted-pill {
    opacity: 0.78;
  }
  .event-cup-trophy-grid-secondary {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
  }
  .secondary-event-cup {
    padding: 12px;
    opacity: 0.9;
    border-color: rgba(255,255,255,0.09);
    background: rgba(255,255,255,0.035);
  }
  .secondary-event-cup .event-cup-icon {
    width: 44px;
    height: 44px;
    font-size: 1.55rem;
  }
  .secondary-event-cup strong {
    font-size: 0.96rem;
  }
  .secondary-event-cup span,
  .secondary-event-cup small {
    color: var(--muted);
  }
  .secondary-recent-event {
    opacity: 0.82;
    border-style: dashed;
  }
  .league-recent {
    border-color: rgba(242,184,75,0.18);
  }
  @media (max-width: 740px) {
    .league-trophy-summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .placement-trophy-grid-primary { grid-template-columns: 1fr; }
    .event-cup-trophy-grid-secondary { grid-template-columns: 1fr; }
  }
  @media (max-width: 560px) {
    .league-cabinet-hero-cups { grid-template-columns: repeat(3, minmax(0, 1fr)); max-width: none; }
    .primary-cup-stat { min-height: 96px; padding-left: 6px; padding-right: 6px; }
    .primary-cup-stat span { font-size: 1.75rem; }
    .primary-cup-stat strong { font-size: 1.35rem; }
  }
`;

export default App;
